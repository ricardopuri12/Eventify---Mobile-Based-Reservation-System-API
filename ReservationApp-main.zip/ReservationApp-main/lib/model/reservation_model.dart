// To parse this JSON data, do
//
//     final reservation = reservationFromJson(jsonString);

import 'dart:convert';

List<Reservation> reservationFromJson(String str) => List<Reservation>.from(json.decode(str).map((x) => Reservation.fromJson(x)));

String reservationToJson(List<Reservation> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Reservation {
  String establishmentImage;
  String establishmentDescriptionEnglish;
  String establishmentDescriptionFrench;
  String establishmentDescriptionSpanish;
  String establishmentName;
  double reservationPrice;
  double reservationDownpayment;
  int establishmentPax;
  int customerPax;
  int establishmentSlot;
  String paymentStatus;
  DateTime datecreated;
  String establishmentCategory;
  String userName;
  String userId;
  String userImage;
  String reservationId;
  DateTime from;
  DateTime to;
  double establishmentPrice;
  String status;
  String establishmentId;
  String id;
  String remarks;
  String contactno;

  Reservation({
    required this.reservationDownpayment,
    required this.establishmentPax,
    required this.paymentStatus,
    required this.establishmentImage,
    required this.establishmentSlot,
    required this.customerPax,
    required this.establishmentDescriptionEnglish,
    required this.establishmentDescriptionFrench,
    required this.establishmentDescriptionSpanish,
    required this.establishmentName,
    required this.reservationPrice,
    required this.datecreated,
    required this.establishmentCategory,
    required this.userName,
    required this.userId,
    required this.userImage,
    required this.reservationId,
    required this.from,
    required this.to,
    required this.establishmentPrice,
    required this.status,
    required this.establishmentId,
    required this.contactno,
    required this.id,
    required this.remarks,
  });

  factory Reservation.fromJson(Map<String, dynamic> json) => Reservation(
        establishmentSlot: json["establishmentSlot"],
        customerPax: json["customerPax"],
        reservationDownpayment: json["reservationDownpayment"],
        establishmentPax: json["establishmentPax"],
        paymentStatus: json["paymentStatus"],
        establishmentImage: json["establishmentImage"],
        establishmentDescriptionEnglish: json["establishmentDescriptionEnglish"],
        establishmentDescriptionFrench: json["establishmentDescriptionFrench"],
        establishmentDescriptionSpanish: json["establishmentDescriptionSpanish"],
        establishmentName: json["establishmentName"],
        reservationPrice: json["reservationPrice"]?.toDouble(),
        datecreated: DateTime.parse(json["datecreated"]),
        establishmentCategory: json["establishmentCategory"],
        userName: json["userName"],
        userId: json["userID"],
        contactno: json["contactno"],
        userImage: json["userImage"],
        remarks: json["remarks"],
        reservationId: json["reservationID"],
        from: DateTime.parse(json["from"]),
        to: DateTime.parse(json["to"]),
        establishmentPrice: json["establishmentPrice"]?.toDouble(),
        status: json["status"],
        establishmentId: json["establishmentID"],
        id: json["id"],
      );

  Map<String, dynamic> toJson() => {
        "customerPax": customerPax,
        "establishmentSlot": establishmentSlot,
        "reservationDownpayment": reservationDownpayment,
        "establishmentPax": establishmentPax,
        "paymentStatus": paymentStatus,
        "establishmentImage": establishmentImage,
        "establishmentDescription": establishmentDescriptionEnglish,
        "establishmentDescriptionFrench": establishmentDescriptionFrench,
        "establishmentDescriptionSpanish": establishmentDescriptionSpanish,
        "establishmentName": establishmentName,
        "reservationPrice": reservationPrice,
        "datecreated": datecreated.toIso8601String(),
        "establishmentCategory": establishmentCategory,
        "userName": userName,
        "contactno": contactno,
        "userID": userId,
        "userImage": userImage,
        "reservationID": reservationId,
        "from": from.toIso8601String(),
        "to": to.toIso8601String(),
        "establishmentPrice": establishmentPrice,
        "status": status,
        "establishmentID": establishmentId,
        "id": id,
        "remarks": remarks,
      };
}
