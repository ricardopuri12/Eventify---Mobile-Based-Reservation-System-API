// To parse this JSON data, do
//
//     final chatBotModel = chatBotModelFromJson(jsonString);

import 'dart:convert';

List<ChatBotModel> chatBotModelFromJson(String str) => List<ChatBotModel>.from(
    json.decode(str).map((x) => ChatBotModel.fromJson(x)));

String chatBotModelToJson(List<ChatBotModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class ChatBotModel {
  String message;
  DateTime datecreated;
  String sender;

  ChatBotModel({
    required this.message,
    required this.datecreated,
    required this.sender,
  });

  factory ChatBotModel.fromJson(Map<String, dynamic> json) => ChatBotModel(
        message: json["message"],
        datecreated: DateTime.parse(json["datecreated"]),
        sender: json["sender"],
      );

  Map<String, dynamic> toJson() => {
        "message": message,
        "datecreated": datecreated.toIso8601String(),
        "sender": sender,
      };
}
