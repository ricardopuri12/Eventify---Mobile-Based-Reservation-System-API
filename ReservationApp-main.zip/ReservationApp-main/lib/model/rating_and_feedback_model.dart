// To parse this JSON data, do
//
//     final ratingAndFeedback = ratingAndFeedbackFromJson(jsonString);

import 'dart:convert';

List<RatingAndFeedback> ratingAndFeedbackFromJson(String str) => List<RatingAndFeedback>.from(json.decode(str).map((x) => RatingAndFeedback.fromJson(x)));

String ratingAndFeedbackToJson(List<RatingAndFeedback> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class RatingAndFeedback {
  String feedback;
  String profilePicture;
  String firstname;
  double rating;
  DateTime datecreated;
  String userid;
  String lastname;
  String id;

  RatingAndFeedback({
    required this.feedback,
    required this.profilePicture,
    required this.firstname,
    required this.rating,
    required this.datecreated,
    required this.userid,
    required this.lastname,
    required this.id,
  });

  factory RatingAndFeedback.fromJson(Map<String, dynamic> json) => RatingAndFeedback(
        feedback: json["feedback"],
        profilePicture: json["profilePicture"],
        firstname: json["firstname"],
        rating: double.parse(json["rating"].toString()),
        datecreated: DateTime.parse(json["datecreated"]),
        userid: json["userid"],
        lastname: json["lastname"],
        id: json["id"],
      );

  Map<String, dynamic> toJson() => {
        "feedback": feedback,
        "profilePicture": profilePicture,
        "firstname": firstname,
        "rating": rating,
        "datecreated": datecreated.toIso8601String(),
        "userid": userid,
        "lastname": lastname,
        "id": id,
      };
}
