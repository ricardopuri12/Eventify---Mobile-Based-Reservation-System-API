// To parse this JSON data, do
//
//     final establishments = establishmentsFromJson(jsonString);

import 'dart:convert';

List<Establishments> establishmentsFromJson(String str) => List<Establishments>.from(json.decode(str).map((x) => Establishments.fromJson(x)));

String establishmentsToJson(List<Establishments> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Establishments {
  String image;
  String name;
  String descriptionEnglish;
  String descriptionFrench;
  String descriptionSpanish;
  DateTime datecreated;
  String category;
  double price;
  String id;
  int pax;
  int slot;

  double? rating;

  Establishments({
    required this.image,
    required this.name,
    required this.descriptionEnglish,
    required this.descriptionFrench,
    required this.descriptionSpanish,
    required this.datecreated,
    required this.category,
    required this.price,
    required this.id,
    required this.pax,
    required this.slot,
    this.rating,
  });

  factory Establishments.fromJson(Map<String, dynamic> json) => Establishments(
        image: json["image"],
        name: json["name"],
        descriptionEnglish: json["descriptionEnglish"],
        descriptionFrench: json["descriptionFrench"],
        descriptionSpanish: json["descriptionSpanish"],
        datecreated: DateTime.parse(json["datecreated"]),
        category: json["category"],
        pax: json["pax"],
        slot: json["slot"],
        rating: json["rating"] != null ? double.parse(json["rating"].toString()) : null,
        price: double.parse(json["price"].toString()),
        id: json["id"],
      );

  Map<String, dynamic> toJson() => {
        "image": image,
        "name": name,
        "pax": pax,
        "slot": slot,
        "descriptionEnglish": descriptionEnglish,
        "descriptionFrench": descriptionFrench,
        "descriptionSpanish": descriptionSpanish,
        "datecreated": datecreated.toIso8601String(),
        "category": category,
        "price": price,
        "rating": rating,
        "id": id,
      };
}
