import 'package:flutter/material.dart';

class AppColors {
  // #411785 dark purple
  // #5c37a4 purple
  // #5694ed light blue
  // #8054d6 light purple
  // #f4f4f6 white

  static const darkBlue = Color(0xFF022b60);
  static const lightBlue = Color(0xFF022b60);
  static const darkGrey = Color(0xff60838A);

  static const dark = Colors.black54;
  static const red = Colors.red;

  static const light = Color(0xfff4f4f6);
  static const black = Color.fromARGB(255, 46, 46, 46);
  static const grey = Color(0xff7E8A8C);
  static const backgroundfill = Color(0xffEBEDED);

  static Map<int, Color> mainMaterialColor = {
    50: const Color(0xFF17C6ED),
    100: const Color(0xFF17C6ED),
    200: const Color(0xFF17C6ED),
    300: const Color(0xFF17C6ED),
    400: const Color(0xFF17C6ED),
    500: const Color(0xFF17C6ED),
    600: const Color(0xFF17C6ED),
    700: const Color(0xFF17C6ED),
    800: const Color(0xFF17C6ED),
    900: const Color(0xFF17C6ED),
    1000: const Color(0xFF17C6ED),
  };
}
