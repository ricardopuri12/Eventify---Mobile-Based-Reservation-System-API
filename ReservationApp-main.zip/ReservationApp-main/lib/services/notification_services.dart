import 'dart:convert';
import 'dart:math';
import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:get/get.dart';
import 'package:googleapis_auth/auth_io.dart';
import 'package:http/http.dart' as http;

class NotificationServices extends GetxService {
  FirebaseMessaging messaging = FirebaseMessaging.instance;
  String? token;

  @override
  Future<void> onInit() async {
    await checkNotificationPermission();
    super.onInit();
  }

  Future<String> getAccessToken() async {
    var serviceAccountJson = {
      "type": "service_account",
      "project_id": "hotelreservation-8f21f",
      "private_key_id": "c1bc4fb84d89f57172cf7f904dc18356a8cf1d66",
      "private_key":
          "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDKrbZ6J8JLHVnh\nTGEkEsdNt5ztHgHKFB34jrzTtKsynQaQP9y9hR/788lOhC4mRXRIkgIEPkATjfsr\ntLJ2kfF9/XmbXQZd5LUpONvbZ8EQV7vlaRVKDyh55bGn0JTk4o4G7EVyud+Nu6Oc\nkFGellNYpicjhy13wthwbAyWbbJwyLyAl0pai5FMmz38ncVaEObJzZjblx0KwX5y\n7X6yeoQI5GjJH0JkwhA3B08gTZY++KQqwgyJOHuZMqHI9TJwC/TeEBxYwK/Y2dDK\n1GLdFOcsPnflOhpk+NzzdZpMlZp9gXXg8g4+Wlm/vOrS3zGp4FrGEPPSZVIwA3kF\n9uHYn+8fAgMBAAECggEABQp5BWTDwlaCi8X4jIsjBd3RO1yJstr5O9tg+ur9bw7U\nwPW1qckL2JphoWBMPYtwrvVis3RQ56uaWaXu4mAS341UXvbbV65+iv3tCfH0rVFh\nTP1mGCd0XEPIPWJEscSov6dUutvAoafPE+/K9+TJQeUwCAQur1HbTECDt6IW1BM+\nrLtOHpKgslgpEcRTcqg/xfOl40M0FR7sRp+zqM9ZBU3zaWPfuTUwFIOIbUIOTefg\nNIboN/5wSWFHoOB+4b6CBDpBZ4Y6CIOxKCw+8MKxV7zQ34uS/PY8jmMk46uKW6pN\n5w2Pd963y1oo+QcQ0F62j37217/J6aIdgNBBVvlnkQKBgQD5DM+f6pVglm9rAeWM\n1lvDLBRKfiHUDxMNOwYU1Jcp3dNNST+rXh50529c0G89gGATPgJ7oi7BfIj5xngK\nihr05iGbPvwAnovm9geq/A8fCL5LUcVwrW0KVhrx9qLARzZEvS/YOUW2mket07Th\nA7hAoMEDlLSSJUasvdOitF5LmwKBgQDQVaDlgmB5brvHXmM4XC1gNTdKI32OCVgo\nGhElT3AZrFPmhLJ/TDp91NZOiUZizVSzaedXR13dUiEsiipEwjqKD8Lml8jWYApu\naDYVo9Qi2ViAEpmk689uoSunlGOdFdYYvXFnHEuoyg8Z8acKsOkiR5/7wELdWFGC\nAYAzAyhszQKBgEBsgPT0IMoIgC/lILVK6hfVujX+5M9PSvVcNFmFGMlauYM/lHnG\n8gf5qkQPIwd8wt2XZ9sFfCTPCzvZjEnlqc16Dm1zYIrkeHo5YIhphZvYjik7sOBR\n7GgFGBlJXJZylWY4rjy3rAHtbOdZYWvno20MaIF9oSxA+kRLIojvMYlLAoGAR+Cz\nMVwJEvxcdw2ep+xNj3rsx3x1LhMVQki0D65Xm9Pz4n135CmVqKJNCi2chiwXhAsO\n0PMDdH+IiIhmyvBEKCwF728A0M2z66Gyv0aVwyw/t3gzYE4ndCDRIfE1aRYGluSN\ngqilheeozCeunSaqWLRjgwUzTJDTFkqUQ4VcZiUCgYBv0pVuGXLvkUUJ4iOhj/7W\nmW8YqM1r+csIIc6La3fTPTu5tqQjCR606Jwp/9HCnmYs2IRIcaDp3zYUtUGllnit\nakeMlN6kv1To1UAMgFYpAznHdFpKULBFAG3uazkIwK98CZFr1U1eomQPWRWT7j0O\nkTQre4t+BAsOhWcvz3TazA==\n-----END PRIVATE KEY-----\n",
      "client_email": "firebase-adminsdk-g4f6l@hotelreservation-8f21f.iam.gserviceaccount.com",
      "client_id": "107673874366341946642",
      "auth_uri": "https://accounts.google.com/o/oauth2/auth",
      "token_uri": "https://oauth2.googleapis.com/token",
      "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
      "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-g4f6l%40hotelreservation-8f21f.iam.gserviceaccount.com",
      "universe_domain": "googleapis.com"
    };

    final accountCredentials = ServiceAccountCredentials.fromJson(serviceAccountJson);
    final scopes = ['https://www.googleapis.com/auth/userinfo.email', 'https://www.googleapis.com/auth/firebase.database', 'https://www.googleapis.com/auth/firebase.messaging'];
    final client = await clientViaServiceAccount(accountCredentials, scopes);
    final accessToken = client.credentials.accessToken;
    return accessToken.data;
  }

  sendNotification({required String userToken, required String message, required String title}) async {
    final String accessToken = await getAccessToken();

    var body = jsonEncode({
      'message': {
        'token': userToken,
        'notification': {
          'body': message,
          'title': title,
        },
        "data": {'current_user_fcm_token': userToken}
      }
    });
    await http.post(Uri.parse('https://fcm.googleapis.com/v1/projects/hotelreservation-8f21f/messages:send'),
        headers: <String, String>{"Authorization": "Bearer $accessToken", "Content-Type": "application/json"}, body: body);
  }

  Future<void> notificationSetup() async {
    AwesomeNotifications().initialize(
      null,
      [
        NotificationChannel(
          channelKey: 'basic_channel',
          channelName: 'Basic notifications',
          channelDescription: 'Notification channel for basic tests',
          importance: NotificationImportance.High,
        ),
        NotificationChannel(
          channelKey: 'basic_channel_muted',
          channelName: 'Basic muted notifications ',
          channelDescription: 'Notification channel for muted basic tests',
          importance: NotificationImportance.High,
          playSound: false,
        )
      ],
    );
  }

  Future<void> onForegroundMessage() async {
    FirebaseMessaging.onMessage.listen(
      (RemoteMessage message) {
        if (message.notification != null) {
          // if (Get.find<StorageService>().storage.read("notificationSound") ==
          //     true) {
          //   AwesomeNotifications().createNotification(
          //     content: NotificationContent(
          //       id: Random().nextInt(9999),
          //       channelKey: 'basic_channel',
          //       title: '${message.notification!.title}',
          //       body: '${message.notification!.body}',
          //       notificationLayout: NotificationLayout.BigText,
          //     ),
          //   );
          // } else {
          AwesomeNotifications().createNotification(
            content: NotificationContent(
              id: Random().nextInt(9999),
              channelKey: 'basic_channel_muted',
              title: '${message.notification!.title}',
              body: '${message.notification!.body}',
              notificationLayout: NotificationLayout.BigText,
            ),
          );
          // }

          // call_unseen_messages();
        }
      },
    );
  }

  Future<void> checkNotificationPermission() async {
    var res = await messaging.requestPermission();
    if (res.authorizationStatus == AuthorizationStatus.authorized) {
      await notificationSetup();
      await onBackgroundMessage();
      await onForegroundMessage();
      // String? token = await messaging.getToken();
      // Future.delayed(const Duration(seconds: 4), () {
      //   sendNotification(
      //       userToken: token!, message: "Sampe notif", title: "Sample");
      // });
    }
  }
}

Future<void> onBackgroundMessage() async {
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
}

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  if (message.notification != null) {
    // if (Get.find<StorageService>().storage.read("notificationSound") ==
    //     true) {
    //   AwesomeNotifications().createNotification(
    //     content: NotificationContent(
    //       id: Random().nextInt(9999),
    //       channelKey: 'basic_channel',
    //       title: '${message.notification!.title}',
    //       body: '${message.notification!.body}',
    //       notificationLayout: NotificationLayout.BigText,
    //     ),
    //   );
    // } else {
    AwesomeNotifications().createNotification(
      content: NotificationContent(
        id: Random().nextInt(9999),
        channelKey: 'basic_channel_muted',
        title: '${message.notification!.title}',
        body: '${message.notification!.body}',
        notificationLayout: NotificationLayout.BigText,
      ),
    );
    // if (Get.isRegistered<HomeScreenController>() == true &&
    //     message.data['notif_from'] == "Order Status") {
    //   Get.find<HomeScreenController>().getOrders();
    //   if (Get.isRegistered<OrderDetailScreenController>() == true) {
    //     Get.find<OrderDetailScreenController>().getOrderStatus();
    //   }
    // }
    // if (Get.isRegistered<HomeScreenController>() == true &&
    //     message.data['notif_from'] == "Chat") {
    //   Get.find<HomeScreenController>()
    //       .putMessageIdentifier(order_id: message.data['value']);
    //   if (Get.isRegistered<OrderDetailScreenController>()) {
    //     Get.find<OrderDetailScreenController>().hasMessage.value = true;
    //   }
    // }
    // }

    // call_unseen_messages();
  }
}
