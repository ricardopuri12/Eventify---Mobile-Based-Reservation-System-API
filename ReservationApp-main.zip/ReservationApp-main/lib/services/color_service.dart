import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ColorsService extends GetxService {
  Color getColor({required String color}) {
    Color selected = Colors.black;
    switch (color) {
      case "red":
        selected = Colors.red;
        break;
      case "blue":
        selected = Colors.blue;
        break;
      case "green":
        selected = Colors.green;
        break;
      case "yellow":
        selected = Colors.yellow;
        break;
      case "purple":
        selected = Colors.purple;
        break;
      case "pink":
        selected = Colors.pink;
        break;
      case "grey":
        selected = Colors.grey;
        break;
      case "amber":
        selected = Colors.amber;
        break;
      case "orange":
        selected = Colors.orange;
        break;
      case "cyan":
        selected = Colors.cyan;
        break;
      case "brown":
        selected = Colors.brown;
        break;
      case "teal":
        selected = Colors.teal;
        break;
      case "indigo":
        selected = Colors.indigo;
        break;
      default:
        selected = Colors.black;
    }
    return selected;
  }
}
