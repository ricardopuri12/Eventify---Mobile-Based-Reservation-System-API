import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

class StorageServices extends GetxController {
  final storage = GetStorage();

  saveClientCredentials({
    required String id,
    required String email,
    required String firstname,
    required String lastname,
    required String profilePicture,
    required String password,
  }) {
    storage.write("id", id);

    storage.write("firstname", firstname);
    storage.write("lastname", lastname);
    storage.write("email", email);
    storage.write("profilePicture", profilePicture);
    storage.write("password", password);
  }

  removeStorageCredentials() {
    storage.remove("id");
    storage.remove("email");
    storage.remove("firstname");
    storage.remove("lastname");
    storage.remove("profilePicture");
    storage.remove("password");
  }

  setLanguage({required String locale}) {
    storage.write("language", locale);
  }

  acceptTermsAndServices() {
    storage.write("termsAndCondition", true);
  }

  introductionDone() {
    storage.write("intro", true);
  }

  setThemeMode({required String mode}) async {
    storage.write("mode", mode);
  }
}
