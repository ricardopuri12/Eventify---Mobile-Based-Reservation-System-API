class DefaultImage {
  static const String defaultImage = 'https://xtlhegoxjkfrdniswans.supabase.co/storage/v1/object/public/hotelreservationbucket/defaultprofile.jpg';
  static const String defaultStoreLogo = 'https://xtlhegoxjkfrdniswans.supabase.co/storage/v1/object/public/hotelreservationbucket/launcher.png';
}
