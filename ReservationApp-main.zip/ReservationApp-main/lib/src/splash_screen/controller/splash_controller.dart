import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/src/user_bottom_nav_screen/view/user_bottom_nav_view.dart';

import '../../login_screen/view/login_page.dart';

class SplashController extends GetxController {
  navigateTo() async {
    Timer(const Duration(seconds: 4), () async {
      FirebaseAuth auth = FirebaseAuth.instance;
      User? user = auth.currentUser;
      if (user != null && user.emailVerified) {
        Get.offAll(() => const UserBottomNavPage());
      } else {
        Get.offAll(() => const LoginPage());
      }
    });
  }

  @override
  void onInit() {
    navigateTo();
    super.onInit();
  }
}
