import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../../config/app_colors.dart';
import '../../../config/app_fontsizes.dart';
import '../controller/language_controller.dart';

class LanguagePage extends GetView<LanguageController> {
  const LanguagePage({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(LanguageController());
    return Scaffold(
      appBar: AppBar(
        title: Text(
          AppLocalizations.of(context)!.wordlanguage,
          style: Theme.of(context).textTheme.labelMedium,
        ),
      ),
      body: SizedBox(
        height: 100.h,
        width: 100.w,
        child: Padding(
          padding: EdgeInsets.only(left: 5.w, right: 5.w),
          child: Column(
            children: [
              Row(
                children: [
                  Obx(() => Checkbox(
                      value: controller.selectedLanguage.value == "en",
                      onChanged: (value) {
                        controller.selectedLanguage.value = "en";
                      })),
                  Text(
                    AppLocalizations.of(context)!.english,
                    style: Theme.of(context).textTheme.labelMedium,
                  )
                ],
              ),
              SizedBox(
                height: 1.h,
              ),
              Row(
                children: [
                  Obx(() => Checkbox(
                      value: controller.selectedLanguage.value == "es",
                      onChanged: (value) {
                        controller.selectedLanguage.value = "es";
                      })),
                  Text(
                    AppLocalizations.of(context)!.spanish,
                    style: Theme.of(context).textTheme.labelMedium,
                  )
                ],
              ),
              SizedBox(
                height: 1.h,
              ),
              Row(
                children: [
                  Obx(() => Checkbox(
                      value: controller.selectedLanguage.value == "fr",
                      onChanged: (value) {
                        controller.selectedLanguage.value = "fr";
                      })),
                  Text(
                    AppLocalizations.of(context)!.french,
                    style: Theme.of(context).textTheme.labelMedium,
                  )
                ],
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: EdgeInsets.only(left: 5.w, right: 5.w, bottom: 4.h),
        child: SizedBox(
          width: 100.w,
          height: 7.h,
          child: ElevatedButton(
            style: ButtonStyle(
                foregroundColor: MaterialStateProperty.all<Color>(AppColors.lightBlue),
                backgroundColor: MaterialStateProperty.all<Color>(AppColors.lightBlue),
                shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0), side: const BorderSide(color: AppColors.lightBlue)))),
            onPressed: () {
              controller.setLanguage();
            },
            child: Text(AppLocalizations.of(context)!.set.capitalize.toString(), style: TextStyle(fontSize: AppFontSizes.regular, color: Colors.white)),
          ),
        ),
      ),
    );
  }
}
