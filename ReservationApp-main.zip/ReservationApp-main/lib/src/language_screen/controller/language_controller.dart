import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/services/getstorage_services.dart';

class LanguageController extends GetxController {
  RxString selectedLanguage = Get.find<StorageServices>().storage.read('language') == null ? "en".obs : Get.find<StorageServices>().storage.read('language').toString().obs;

  setLanguage() async {
    // var locale = Locale(langaugeGroupValue.value);
    // Get.updateLocale(locale);
    await Get.find<StorageServices>().setLanguage(locale: selectedLanguage.value);
    var locale = Locale(selectedLanguage.value);
    Get.updateLocale(locale);
    Get.forceAppUpdate();
  }
}
