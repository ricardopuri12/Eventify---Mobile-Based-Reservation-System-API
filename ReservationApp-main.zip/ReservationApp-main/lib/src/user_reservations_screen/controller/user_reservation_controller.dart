import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../model/reservation_model.dart';
import '../../../services/getstorage_services.dart';
// import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class UserReservationListController extends GetxController {
  Timer? debounce;
  RxList<Reservation> reservationsList = <Reservation>[].obs;
  RxList<Reservation> reservationsMasterList = <Reservation>[].obs;
  TextEditingController search = TextEditingController();

  RxBool hasDetails = false.obs;

  RxString categoryFilterValue = 'All'.obs;
  RxList<String> categoryFilterList = [
    'All',
    'Hotel',
    'Villa',
    'Resort',
  ].obs;

  StreamSubscription<dynamic>? reservationListener;

  String userID = Get.find<StorageServices>().storage.read('email').toString();
  String userName = "${Get.find<StorageServices>().storage.read('firstname')} ${Get.find<StorageServices>().storage.read('lastname')}";
  String userImage = Get.find<StorageServices>().storage.read('profilePicture').toString();

  getReservations() async {
    try {
      reservationListener =
          FirebaseFirestore.instance.collection('reservation').where('userID', isEqualTo: userID).orderBy('datecreated', descending: true).snapshots().listen((event) {
        var reservations = event.docs;
        List tempList = [];
        for (var i = 0; i < reservations.length; i++) {
          Map mapdata = reservations[i].data();
          mapdata['id'] = reservations[i].id;
          mapdata['datecreated'] = mapdata['datecreated'].toDate().toString();
          mapdata['from'] = mapdata['from'].toDate().toString();
          mapdata['to'] = mapdata['to'].toDate().toString();
          tempList.add(mapdata);
        }
        // log(jsonEncode(tempList));
        reservationsList.assignAll(reservationFromJson(jsonEncode(tempList)));
        reservationsMasterList.assignAll(reservationFromJson(jsonEncode(tempList)));
      });
    } catch (e) {
      log("ERROR (getReservations) $e");
    }
  }

  searchReservation() async {
    reservationsList.clear();

    log((search.text.isEmpty && categoryFilterValue.value.trim().toString() != "All").toString());
    for (var i = 0; i < reservationsMasterList.length; i++) {
      if (search.text.isNotEmpty && categoryFilterValue.value != "All") {
        log("3");
        if (reservationsMasterList[i].establishmentName.toLowerCase().toString().contains(search.text.toLowerCase().toString()) &&
            reservationsMasterList[i].establishmentCategory == categoryFilterValue.value) {
          reservationsList.add(reservationsMasterList[i]);
        }
      }
      if (search.text.isNotEmpty && categoryFilterValue.value == "All") {
        log("2");
        if (reservationsMasterList[i].establishmentName.toLowerCase().toString().contains(search.text.toLowerCase().toString())) {
          reservationsList.add(reservationsMasterList[i]);
        }
      }
      if (search.text.isEmpty && categoryFilterValue.value != "All") {
        log("1");
        if (reservationsMasterList[i].establishmentCategory == categoryFilterValue.value) {
          reservationsList.add(reservationsMasterList[i]);
        }
      }
    }

    if (search.text.isEmpty && categoryFilterValue.value == "All") {
      reservationsList.assignAll(reservationsMasterList);
    }
  }

  @override
  void onInit() {
    getReservations();
    super.onInit();
  }
}
