import 'dart:async';
import 'dart:convert';
import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../model/reservation_model.dart';

class AdminOtherStatusReservationController extends GetxController {
  Timer? debounce;
  RxList<Reservation> reservationsTempList = <Reservation>[].obs;

  RxList<Reservation> reservationsList = <Reservation>[].obs;
  RxList<Reservation> reservationsMasterList = <Reservation>[].obs;
  TextEditingController search = TextEditingController();

  RxBool hasDetails = false.obs;

  RxString categoryFilterValue = 'All'.obs;
  RxList<String> categoryFilterList = [
    'All',
    'Hotel',
    'Villa',
    'Resort',
  ].obs;

  StreamSubscription<dynamic>? reservationListener;

  getOtherReservations() async {
    try {
      reservationListener = FirebaseFirestore.instance
          .collection('reservation')
          .where('status', whereIn: ["Rejected", "Done", "Cancelled"])
          // .where('status', isEqualTo: "Rejected")
          // .where('status', isEqualTo: "Cancelled")
          // .where('status', isEqualTo: "Done")
          .orderBy('datecreated', descending: true)
          .snapshots()
          .listen((event) {
            var establishments = event.docs;
            List tempList = [];
            for (var i = 0; i < establishments.length; i++) {
              Map mapdata = establishments[i].data();
              mapdata['id'] = establishments[i].id;
              mapdata['datecreated'] = mapdata['datecreated'].toDate().toString();
              mapdata['from'] = mapdata['from'].toDate().toString();
              mapdata['to'] = mapdata['to'].toDate().toString();
              tempList.add(mapdata);
            }
            // log(jsonEncode(tempList));
            reservationsList.assignAll(reservationFromJson(jsonEncode(tempList)));
            reservationsMasterList.assignAll(reservationFromJson(jsonEncode(tempList)));
          });
    } catch (e) {
      log("ERROR (getOtherReservations) $e");
    }
  }

  searchReservation() async {
    reservationsList.clear();

    log((search.text.isEmpty && categoryFilterValue.value.trim().toString() != "All").toString());
    for (var i = 0; i < reservationsMasterList.length; i++) {
      if (search.text.isNotEmpty && categoryFilterValue.value != "All") {
        log("3");
        if (reservationsMasterList[i].establishmentName.toLowerCase().toString().contains(search.text.toLowerCase().toString()) &&
            reservationsMasterList[i].establishmentCategory == categoryFilterValue.value) {
          reservationsList.add(reservationsMasterList[i]);
        }
      }
      if (search.text.isNotEmpty && categoryFilterValue.value == "All") {
        log("2");
        if (reservationsMasterList[i].establishmentName.toLowerCase().toString().contains(search.text.toLowerCase().toString())) {
          reservationsList.add(reservationsMasterList[i]);
        }
      }
      if (search.text.isEmpty && categoryFilterValue.value != "All") {
        log("1");
        if (reservationsMasterList[i].establishmentCategory == categoryFilterValue.value) {
          reservationsList.add(reservationsMasterList[i]);
        }
      }
    }

    if (search.text.isEmpty && categoryFilterValue.value == "All") {
      reservationsList.assignAll(reservationsMasterList);
    }
  }

  @override
  void onInit() {
    getOtherReservations();
    super.onInit();
  }
}
