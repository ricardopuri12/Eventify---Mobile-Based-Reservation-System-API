import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sizer/sizer.dart';

import '../../../config/app_colors.dart';
import '../../../services/money_formatter.dart';
import '../../admin_reservation_details_screen/view/admin_reservation_details_view.dart';
import '../controller/admin_otherstatus_reservation_controller.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class AdminOtherStatusReservationPage extends GetView<AdminOtherStatusReservationController> {
  const AdminOtherStatusReservationPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          AppLocalizations.of(context)!.others,
          style: Theme.of(context).textTheme.labelLarge,
        ),
      ),
      body: SizedBox(
        height: 100.h,
        width: 100.w,
        child: Padding(
          padding: EdgeInsets.only(left: 5.w, right: 5.w),
          child: Column(
            children: [
              SizedBox(
                height: 2.h,
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 7.h,
                    width: 36.w,
                    child: TextField(
                      controller: controller.search,
                      style: Theme.of(context).textTheme.bodyMedium,
                      onChanged: (value) {
                        if (controller.debounce?.isActive ?? false) {
                          controller.debounce?.cancel();
                        }
                        controller.debounce = Timer(const Duration(milliseconds: 500), () {
                          controller.searchReservation();
                        });
                      },
                      decoration: InputDecoration(
                        filled: true,
                        contentPadding: EdgeInsets.only(left: 3.w),
                        alignLabelWithHint: false,
                        hintText: AppLocalizations.of(context)!.search,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(5)),
                        hintStyle: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(bottom: .5.h),
                    child: Container(
                      height: 5.4.h,
                      width: 50.w,
                      decoration: BoxDecoration(border: Border.all(), borderRadius: BorderRadius.circular(5)),
                      child: Padding(
                        padding: EdgeInsets.only(left: 3.w, right: 3.w),
                        child: Obx(
                          () => DropdownButton<String>(
                            value: controller.categoryFilterValue.value,
                            isExpanded: true,
                            underline: const SizedBox(),
                            onChanged: (String? value) {
                              controller.categoryFilterValue.value = value!;
                              controller.searchReservation();
                            },
                            items: controller.categoryFilterList.map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value == "All" ? AppLocalizations.of(context)!.all : value,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.bodySmall,
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 2.h,
              ),
              Expanded(
                  child: Obx(
                () => controller.reservationsList.isEmpty
                    ? Center(
                        child: Text(
                          AppLocalizations.of(context)!.noavailablereservation,
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      )
                    : SizedBox(
                        child: Obx(
                          () => ListView.builder(
                            itemCount: controller.reservationsList.length,
                            itemBuilder: (BuildContext context, int index) {
                              return Padding(
                                padding: EdgeInsets.only(
                                  top: 2.h,
                                ),
                                child: SizedBox(
                                  width: 100.w,
                                  child: GestureDetector(
                                    onTap: () {
                                      Get.to(() => const AdminReservationDetailsPage(), arguments: {"reservationDetails": controller.reservationsList[index]});
                                    },
                                    child: Card(
                                      child: Row(
                                        children: [
                                          CachedNetworkImage(
                                            imageUrl: controller.reservationsList[index].establishmentImage,
                                            imageBuilder: (context, imageProvider) => Container(
                                              height: 18.h,
                                              width: 40.w,
                                              decoration: BoxDecoration(
                                                borderRadius: const BorderRadius.only(topLeft: Radius.circular(10), bottomLeft: Radius.circular(10)),
                                                image: DecorationImage(fit: BoxFit.cover, image: imageProvider),
                                              ),
                                            ),
                                            placeholder: (context, url) => Container(
                                              height: 18.h,
                                              width: 40.w,
                                              decoration: const BoxDecoration(
                                                borderRadius: BorderRadius.only(topLeft: Radius.circular(10), bottomLeft: Radius.circular(10)),
                                                image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: AssetImage("assets/images/launcher.png"),
                                                ),
                                              ),
                                            ),
                                            errorWidget: (context, url, error) => Container(
                                              height: 18.h,
                                              width: 40.w,
                                              decoration: const BoxDecoration(
                                                borderRadius: BorderRadius.only(topLeft: Radius.circular(10), bottomLeft: Radius.circular(10)),
                                                image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: AssetImage("assets/images/launcher.png"),
                                                ),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            width: 3.w,
                                          ),
                                          Expanded(
                                              child: SizedBox(
                                            height: 18.h,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              mainAxisAlignment: MainAxisAlignment.start,
                                              children: [
                                                SizedBox(
                                                  height: 1.h,
                                                ),
                                                Text(
                                                  controller.reservationsList[index].establishmentName,
                                                  maxLines: 1,
                                                  overflow: TextOverflow.ellipsis,
                                                  style: Theme.of(context).textTheme.labelMedium,
                                                ),
                                                Text(
                                                  MoneyFormatter.formatMoney(amount: controller.reservationsList[index].reservationPrice),
                                                  style: Theme.of(context).textTheme.labelSmall,
                                                ),
                                                Text(
                                                  controller.reservationsList[index].status == "Pending"
                                                      ? AppLocalizations.of(context)!.pending
                                                      : controller.reservationsList[index].status == "Accepted"
                                                          ? AppLocalizations.of(context)!.accepted
                                                          : controller.reservationsList[index].status == "Rejected"
                                                              ? AppLocalizations.of(context)!.reject
                                                              : controller.reservationsList[index].status == "Cancelled"
                                                                  ? AppLocalizations.of(context)!.cancelled
                                                                  : AppLocalizations.of(context)!.done,
                                                  overflow: TextOverflow.ellipsis,
                                                  maxLines: 1,
                                                  style: Theme.of(context).textTheme.bodySmall!.copyWith(
                                                        color: controller.reservationsList[index].status == "Pending"
                                                            ? Colors.orange
                                                            : controller.reservationsList[index].status == "Accepted"
                                                                ? Colors.green
                                                                : controller.reservationsList[index].status == "Rejected" ||
                                                                        controller.reservationsList[index].status == "Cancelled"
                                                                    ? Colors.red
                                                                    : AppColors.darkBlue,
                                                      ),
                                                ),
                                                Text(
                                                  "${AppLocalizations.of(context)!.from} ${DateFormat.yMMMMd().format(controller.reservationsList[index].from)} ${AppLocalizations.of(context)!.to} ${DateFormat.yMMMMd().format(controller.reservationsList[index].to)}",
                                                  overflow: TextOverflow.ellipsis,
                                                  maxLines: 3,
                                                  style: Theme.of(context).textTheme.bodySmall,
                                                ),
                                                SizedBox(
                                                  height: 2.h,
                                                ),
                                              ],
                                            ),
                                          )),
                                          SizedBox(
                                            width: 1.w,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
              ))
            ],
          ),
        ),
      ),
    );
  }
}
