import 'dart:developer';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../../config/app_colors.dart';
import '../../../services/getstorage_services.dart';
import '../../../services/loading_services.dart';
import '../../user_bottom_nav_screen/view/user_bottom_nav_view.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class LoginController extends GetxController {
  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController name = TextEditingController();
  FirebaseAuth auth = FirebaseAuth.instance;
  RxString groupValueType = ''.obs;

  RxString filepath = ''.obs;
  RxString filename = ''.obs;
  RxBool showPass = true.obs;

  loginUser() async {
    LoadingDialog.showLoadingDialog();
    try {
      await auth.signInWithEmailAndPassword(email: email.text, password: password.text);
      var user = auth.currentUser!;
      if (user.emailVerified) {
        var res = await FirebaseFirestore.instance.collection('users').where('email', isEqualTo: email.text).get();
        var userdetails = res.docs;
        if (userdetails.isNotEmpty) {
          Get.back();
          Get.find<StorageServices>().saveClientCredentials(
            password: password.text,
            id: userdetails[0].id,
            email: userdetails[0]['email'],
            firstname: userdetails[0]['firstname'],
            lastname: userdetails[0]['lastname'],
            profilePicture: userdetails[0]['profilePicture'],
          );
          Get.offAll(() => const UserBottomNavPage());
        } else {
          Get.back();
          Get.snackbar(AppLocalizations.of(Get.context!)!.message, AppLocalizations.of(Get.context!)!.userdidnotexist,
              duration: const Duration(seconds: 3), backgroundColor: AppColors.lightBlue, colorText: Colors.white);
        }
      } else {
        Get.back();
        Get.snackbar(AppLocalizations.of(Get.context!)!.message, AppLocalizations.of(Get.context!)!.youraccountisnotyetverified,
            duration: const Duration(seconds: 3), backgroundColor: AppColors.lightBlue, colorText: Colors.white);
        await FirebaseAuth.instance.signOut();
      }
    } catch (e) {
      if (e is FirebaseAuthException) {
        Get.back();
        if (e.code == 'invalid-email') {
          Get.snackbar(AppLocalizations.of(Get.context!)!.message, AppLocalizations.of(Get.context!)!.invalidformat, backgroundColor: AppColors.red, colorText: Colors.white);
        } else if (e.code == 'INVALID_LOGIN_CREDENTIALS') {
          Get.snackbar(AppLocalizations.of(Get.context!)!.message, AppLocalizations.of(Get.context!)!.wrongpassword, backgroundColor: AppColors.red, colorText: Colors.white);
        } else if (e.code == 'too-many-requests') {
          Get.snackbar(AppLocalizations.of(Get.context!)!.message, AppLocalizations.of(Get.context!)!.wehaveblockedallrequest,
              backgroundColor: AppColors.red, colorText: Colors.white);
        } else {
          Get.snackbar(AppLocalizations.of(Get.context!)!.message, "${AppLocalizations.of(Get.context!)!.loginfailedwitherror}: ${e.code}",
              backgroundColor: AppColors.red, colorText: Colors.white);
        }
      } else {
        Get.back();
        Get.snackbar(AppLocalizations.of(Get.context!)!.message, AppLocalizations.of(Get.context!)!.loginfailedsomethingwentwrong,
            backgroundColor: AppColors.red, colorText: Colors.white);
        log(e.toString());
      }
    }
  }

  sampleUpload() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(allowedExtensions: ['png', 'jpg'], type: FileType.custom);
      if (result != null) {
        LoadingDialog.showLoadingDialog();
        String filepath = result.files.single.path!;
        String filename = result.files.single.name;
        await Supabase.instance.client.storage.from('AccounThingBucket').upload('images/$filename', File(filepath));
        final imageLink = Supabase.instance.client.storage.from('AccounThingBucket').getPublicUrl('images/$filename');
        log(imageLink);
        Get.back();
      } else {}
    } on Exception catch (e) {
      Get.back();
      log("ERROR (changeAccountProfileImage): ${e.toString()}");
    }
  }

  // googleSignin() async {
  //   try {
  //     LoadingDialog.showLoadingDialog();
  //     final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
  //     final GoogleSignInAuthentication? googleAuth = await googleUser?.authentication;
  //     if (googleAuth?.accessToken == null && googleAuth?.idToken == null) {
  //       // print("null ang access token ug idtoken");
  //       Get.back();
  //     } else {
  //       var credential = GoogleAuthProvider.credential(
  //         accessToken: googleAuth?.accessToken,
  //         idToken: googleAuth?.idToken,
  //       );
  //       // log("access token: ${googleAuth?.accessToken}");
  //       // log("id token: ${googleAuth?.idToken}");

  //       UserCredential? userCredential = await FirebaseAuth.instance.signInWithCredential(credential);
  //       await FirebaseAuth.instance.signInWithCredential(credential);
  //       log("email::${userCredential.user!.email!.toString()}");
  //       String emailOfUser = userCredential.user!.email!.toString();
  //       var res = await FirebaseFirestore.instance.collection('users').where('email', isEqualTo: emailOfUser.toString()).get();
  //       var userdetails = res.docs;
  //       log(userdetails.length.toString());
  //       if (userdetails.isNotEmpty) {
  //         Get.find<StorageServices>().saveClientCredentials(
  //           profilePicture: userdetails[0]['profilePhoto'],
  //           id: userdetails[0]['userid'],
  //           email: userdetails[0]['userid'],
  //           name: userdetails[0]['firstname'] + " " + userdetails[0]['lastname'],
  //         );
  //         Get.offAll(() => const BottomNavPage());
  //       } else {
  //         var userdoc = FirebaseFirestore.instance.collection('users').doc(emailOfUser);
  //         FirebaseMessaging messaging = FirebaseMessaging.instance;
  //         String? fcmToken = await messaging.getToken();
  //         await userdoc.set({
  //           "userid": emailOfUser,
  //           "email": emailOfUser,
  //           "profilePhoto": DefaultImage.defaultImage,
  //           "firstname": "",
  //           "lastname": "",
  //           "fcmToken": fcmToken ?? "",
  //           "datecreated": Timestamp.now(),
  //           "provider": 'gmail',
  //         });
  //         Get.find<StorageServices>().saveClientCredentials(
  //           profilePicture: DefaultImage.defaultImage,
  //           id: emailOfUser,
  //           email: emailOfUser,
  //           name: "",
  //         );
  //         List defaultCategories = Get.find<ColorsService>().defaultCategories;
  //         WriteBatch batch = FirebaseFirestore.instance.batch();
  //         for (var i = 0; i < defaultCategories.length; i++) {
  //           var categoryDoc = FirebaseFirestore.instance.collection('category').doc();
  //           Map categoryMap = defaultCategories[i];
  //           categoryMap['user'] = emailOfUser;
  //           batch.set(categoryDoc, categoryMap);
  //         }
  //         await batch.commit();
  //         Get.offAll(() => const BottomNavPage());
  //       }
  //     }
  //   } catch (e) {
  //     Get.back();
  //     log("ERROR $e");
  //     // Get.snackbar("Message", "Something went wrong please try again later. $e",
  //     //     colorText: AppColors.light, backgroundColor: AppColors.lightBlue);
  //   }
  // }

  forgotPassword({required String email}) async {
    FirebaseAuth auth = FirebaseAuth.instance;
    try {
      await auth.sendPasswordResetEmail(email: email);
      Get.back();
      Get.snackbar("Message", "Email sent to reset your password. Thank you!", backgroundColor: AppColors.lightBlue, colorText: AppColors.dark);
    } catch (e) {
      Get.snackbar("Message", "Something went wrong please try again later.", backgroundColor: AppColors.lightBlue, colorText: AppColors.dark);
    }
  }

  @override
  void onReady() {
    RxString selectedLanguage = Get.find<StorageServices>().storage.read('language') == null ? "en".obs : Get.find<StorageServices>().storage.read('language').toString().obs;
    var locale = Locale(selectedLanguage.value);
    Get.updateLocale(locale);
    super.onReady();
  }
}
