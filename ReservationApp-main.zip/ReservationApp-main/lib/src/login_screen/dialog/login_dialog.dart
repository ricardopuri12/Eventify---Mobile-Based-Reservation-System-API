import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import '../../../config/app_colors.dart';
import '../../../config/app_fontsizes.dart';
import '../controller/login_controller.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class LoginDialog {
  static showDialogForgotPassword({required LoginController controller}) async {
    TextEditingController email = TextEditingController();
    Get.dialog(
      AlertDialog(
        content: SizedBox(
          height: 20.h,
          width: 100.w,
          child: Column(
            children: [
              SizedBox(
                width: 100.w,
                child: Text(
                  AppLocalizations.of(Get.context!)!.enteremail,
                  style: TextStyle(color: AppColors.dark, fontWeight: FontWeight.bold, fontSize: AppFontSizes.regular),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              SizedBox(
                height: 7.h,
                width: 100.w,
                child: TextField(
                  controller: email,
                  style: TextStyle(color: Colors.black, fontSize: 12.sp),
                  decoration: InputDecoration(
                    fillColor: AppColors.light,
                    filled: true,
                    contentPadding: EdgeInsets.only(left: 3.w),
                    alignLabelWithHint: false,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    hintText: AppLocalizations.of(Get.context!)!.email,
                  ),
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  TextButton(
                      onPressed: () {
                        Get.back();
                      },
                      child: Text(
                        AppLocalizations.of(Get.context!)!.back,
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: AppFontSizes.regular, color: AppColors.dark),
                      )),
                  TextButton(
                      onPressed: () {
                        if (email.text.isEmail == true) {
                          controller.forgotPassword(email: email.text);
                        } else {
                          Get.snackbar(
                            AppLocalizations.of(Get.context!)!.message,
                            AppLocalizations.of(Get.context!)!.invalidemail,
                          );
                        }
                      },
                      child: Text(
                        AppLocalizations.of(Get.context!)!.submit,
                        style: TextStyle(color: AppColors.lightBlue, fontWeight: FontWeight.bold, fontSize: AppFontSizes.regular),
                      ))
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
