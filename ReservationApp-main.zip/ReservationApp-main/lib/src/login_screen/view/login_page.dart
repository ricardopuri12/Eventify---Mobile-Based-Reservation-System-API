import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/src/language_screen/view/language_view.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../../config/app_colors.dart';
import '../../../config/app_fontsizes.dart';
import '../../admin_passcode_screen/view/admin_passcode_view.dart';
import '../../registration_screen/view/registration_basic_info.dart';
import '../controller/login_controller.dart';
import '../dialog/login_dialog.dart';

class LoginPage extends GetView<LoginController> {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(LoginController());
    return Scaffold(
      body: SizedBox(
        height: 100.h,
        width: 100.w,
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: 8.h,
              ),
              Padding(
                padding: EdgeInsets.only(
                  right: 5.w,
                ),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: () {
                      Get.to(() => const LanguagePage());
                    },
                    child: const CircleAvatar(
                        backgroundColor: AppColors.darkBlue,
                        child: Icon(
                          Icons.translate,
                          color: Colors.white,
                        )),
                  ),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Container(
                height: 38.h,
                width: 100.w,
                decoration: const BoxDecoration(image: DecorationImage(image: AssetImage('assets/images/logoonly.png'))),
              ),
              SizedBox(
                height: 2.h,
              ),
              Container(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                height: 7.h,
                width: 100.w,
                child: TextField(
                  controller: controller.email,
                  style: TextStyle(fontSize: AppFontSizes.regular),
                  decoration: InputDecoration(
                    filled: true,
                    contentPadding: EdgeInsets.only(left: 3.w),
                    alignLabelWithHint: false,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    hintText: AppLocalizations.of(context)!.email,
                    hintStyle: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Container(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                height: 7.h,
                width: 100.w,
                child: Obx(
                  () => TextField(
                    controller: controller.password,
                    obscureText: controller.showPass.value,
                    style: TextStyle(fontSize: AppFontSizes.regular),
                    decoration: InputDecoration(
                      suffixIcon: GestureDetector(
                        onTap: () {
                          controller.showPass.value = controller.showPass.value ? false : true;
                        },
                        child: controller.showPass.value ? const Icon(Icons.remove_red_eye_outlined) : const Icon(Icons.remove_red_eye),
                      ),
                      filled: true,
                      contentPadding: EdgeInsets.only(left: 3.w),
                      alignLabelWithHint: false,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      hintText: AppLocalizations.of(context)!.password,
                      hintStyle: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: .2.h,
              ),
              Container(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                alignment: Alignment.centerRight,
                child: InkWell(
                  onTap: () {
                    LoginDialog.showDialogForgotPassword(controller: controller);
                  },
                  child: Text(AppLocalizations.of(context)!.forgotpassword, style: TextStyle(fontSize: AppFontSizes.small)),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                child: SizedBox(
                  width: 100.w,
                  height: 7.h,
                  child: ElevatedButton(
                    style: ButtonStyle(
                        foregroundColor: MaterialStateProperty.all<Color>(AppColors.lightBlue),
                        backgroundColor: MaterialStateProperty.all<Color>(AppColors.lightBlue),
                        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0), side: const BorderSide(color: AppColors.lightBlue)))),
                    onPressed: () {
                      if (controller.email.text.isEmpty || controller.password.text.isEmpty) {
                        Get.snackbar(AppLocalizations.of(context)!.message, AppLocalizations.of(context)!.missinginput,
                            backgroundColor: AppColors.lightBlue, colorText: AppColors.light);
                      } else if (controller.email.text.isEmail == false) {
                        Get.snackbar(AppLocalizations.of(context)!.message, AppLocalizations.of(context)!.invalidemail,
                            backgroundColor: AppColors.lightBlue, colorText: AppColors.light);
                      } else {
                        controller.loginUser();
                      }
                      // controller.sampleUpload();
                    },
                    child: Text(AppLocalizations.of(context)!.login.capitalize.toString(), style: TextStyle(fontSize: AppFontSizes.regular, color: Colors.white)),
                  ),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(AppLocalizations.of(context)!.donthaveaccount, style: TextStyle(fontSize: AppFontSizes.small)),
                    SizedBox(
                      width: 1.w,
                    ),
                    InkWell(
                      onTap: () {
                        Get.to(
                          () => const UsersRegistrationPage(),
                        );
                      },
                      child: Text(AppLocalizations.of(context)!.createaccount,
                          style: TextStyle(fontSize: AppFontSizes.small, color: AppColors.lightBlue, fontWeight: FontWeight.bold)),
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                child: InkWell(
                  onTap: () async {
                    Get.to(() => const AdminPassCodeView());
                  },
                  child: Container(
                    alignment: Alignment.center,
                    height: 6.h,
                    width: 100.w,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.black), color: Colors.white),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.admin_panel_settings_sharp,
                            color: AppColors.lightBlue,
                          ),
                          SizedBox(
                            width: 3.w,
                          ),
                          Text(
                            AppLocalizations.of(context)!.continueasadmin,
                            style: TextStyle(fontSize: AppFontSizes.regular, fontWeight: FontWeight.bold),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
