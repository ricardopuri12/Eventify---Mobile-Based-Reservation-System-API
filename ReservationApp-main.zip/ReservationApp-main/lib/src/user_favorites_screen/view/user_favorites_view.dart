import 'dart:async';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/src/user_home_screen/controller/user_home_controller.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../../../config/app_colors.dart';
import '../../../services/money_formatter.dart';
import '../../language_screen/view/language_view.dart';
import '../../user_and_chatbot_screen/view/user_and_chatbot_view.dart';
import '../../user_bottom_nav_screen/controller/user_bottom_nav_controller.dart';
import '../../user_home_screen/view/user_establishment_details_view.dart';
import '../controller/user_favorites_controller.dart';

class UserFavoritesPage extends GetView<UserFavoritesController> {
  const UserFavoritesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Padding(
          padding: EdgeInsets.only(left: 5.w),
          child: CircleAvatar(
            backgroundColor: AppColors.lightBlue,
            child: Padding(
              padding: const EdgeInsets.all(2),
              child: GestureDetector(
                onTap: () {
                  Get.find<UserBottomNavController>().scaffoldKey.currentState?.openDrawer();
                },
                child: Obx(
                  () => CircleAvatar(
                    backgroundImage: NetworkImage(Get.find<UserBottomNavController>().userImage.value),
                  ),
                ),
              ),
            ),
          ),
        ),
        title: Text(
          AppLocalizations.of(context)!.favorites,
          style: Theme.of(context).textTheme.labelLarge,
        ),
        actions: [
          Padding(
            padding: EdgeInsets.only(
              right: 2.w,
            ),
            child: GestureDetector(
              onTap: () {
                Get.to(() => const LanguagePage());
              },
              child: const CircleAvatar(
                backgroundColor: AppColors.darkBlue,
                child: Padding(
                  padding: EdgeInsets.all(1),
                  child: CircleAvatar(
                      backgroundColor: AppColors.light,
                      child: Icon(
                        Icons.translate,
                        color: AppColors.darkBlue,
                      )),
                ),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(
              right: 5.w,
            ),
            child: GestureDetector(
              onTap: () {
                Get.to(() => const UsersAndChatBotView());
              },
              child: const CircleAvatar(
                backgroundColor: AppColors.darkBlue,
                child: Padding(
                  padding: EdgeInsets.all(1),
                  child: CircleAvatar(
                      backgroundColor: AppColors.light,
                      child: Icon(
                        FontAwesomeIcons.message,
                        color: AppColors.darkBlue,
                      )),
                ),
              ),
            ),
          )
        ],
      ),
      body: SizedBox(
        height: 100.h,
        width: 100.w,
        child: Padding(
          padding: EdgeInsets.only(left: 5.w, right: 5.w),
          child: Column(
            children: [
              SizedBox(
                height: 2.h,
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 7.h,
                    width: 36.w,
                    child: TextField(
                      controller: controller.search,
                      style: Theme.of(context).textTheme.bodyMedium,
                      onChanged: (value) {
                        if (controller.debounce?.isActive ?? false) {
                          controller.debounce?.cancel();
                        }
                        controller.debounce = Timer(const Duration(milliseconds: 500), () {
                          controller.searchEstablishment();
                        });
                      },
                      decoration: InputDecoration(
                        filled: true,
                        contentPadding: EdgeInsets.only(left: 3.w),
                        alignLabelWithHint: false,
                        hintText: AppLocalizations.of(context)!.search,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(5)),
                        hintStyle: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(bottom: .5.h),
                    child: Container(
                      height: 5.4.h,
                      width: 50.w,
                      decoration: BoxDecoration(border: Border.all(), borderRadius: BorderRadius.circular(5)),
                      child: Padding(
                        padding: EdgeInsets.only(left: 3.w, right: 3.w),
                        child: Obx(
                          () => DropdownButton<String>(
                            value: controller.categoryFilterValue.value,
                            isExpanded: true,
                            underline: const SizedBox(),
                            onChanged: (String? value) {
                              controller.categoryFilterValue.value = value!;
                              controller.searchEstablishment();
                            },
                            items: controller.categoryFilterList.map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value == "All" ? AppLocalizations.of(context)!.all : value,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.bodySmall,
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 2.h,
              ),
              Expanded(
                  child: Obx(
                () => controller.establishmentsList.isEmpty
                    ? Center(
                        child: Text(
                          AppLocalizations.of(context)!.noavailablefavoritesestablishments,
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      )
                    : SizedBox(
                        child: Obx(
                          () => ListView.builder(
                            itemCount: controller.establishmentsList.length,
                            itemBuilder: (BuildContext context, int index) {
                              return Padding(
                                padding: EdgeInsets.only(
                                  top: 2.h,
                                ),
                                child: SizedBox(
                                  width: 100.w,
                                  child: GestureDetector(
                                    onTap: () {
                                      Get.find<UserHomeController>().hasDetails.value = true;
                                      Get.find<UserHomeController>().establishmentDetails = controller.establishmentsList[index];

                                      Get.to(() => const UserEstablishmentDetailsPage());
                                    },
                                    child: Card(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Stack(
                                            alignment: AlignmentDirectional.center,
                                            children: [
                                              Stack(
                                                children: [
                                                  CachedNetworkImage(
                                                    imageUrl: controller.establishmentsList[index].image,
                                                    imageBuilder: (context, imageProvider) => Container(
                                                      height: 20.h,
                                                      width: 100.w,
                                                      decoration: BoxDecoration(
                                                        borderRadius: const BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10)),
                                                        image: DecorationImage(
                                                          fit: BoxFit.cover,
                                                          image: imageProvider,
                                                        ),
                                                      ),
                                                    ),
                                                    placeholder: (context, url) => Container(
                                                      height: 20.h,
                                                      width: 100.w,
                                                      decoration: const BoxDecoration(
                                                        borderRadius: BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10)),
                                                        image: DecorationImage(
                                                          fit: BoxFit.cover,
                                                          image: AssetImage("assets/images/launcher.png"),
                                                        ),
                                                      ),
                                                    ),
                                                    errorWidget: (context, url, error) => Container(
                                                      height: 20.h,
                                                      width: 100.w,
                                                      decoration: const BoxDecoration(
                                                        borderRadius: BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10)),
                                                        image: DecorationImage(
                                                          fit: BoxFit.cover,
                                                          image: AssetImage("assets/images/launcher.png"),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    top: 1.h,
                                                    right: 2.w,
                                                    child: GestureDetector(
                                                      onTap: () {
                                                        controller.deleteToFavorites(favoriteID: controller.establishmentsList[index].id);
                                                      },
                                                      child: const CircleAvatar(
                                                        backgroundColor: AppColors.red,
                                                        child: Icon(
                                                          Icons.delete,
                                                          color: Colors.white,
                                                        ),
                                                      ),
                                                    ),
                                                  )
                                                ],
                                              ),
                                              // Positioned(
                                              //     child: controller.establishmentsList[index].reservationId.isEmpty
                                              //         ? const SizedBox()
                                              //         : Center(
                                              //             child: Container(
                                              //               height: 14.h,
                                              //               width: 50.w,
                                              //               decoration: const BoxDecoration(
                                              //                 borderRadius: BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10)),
                                              //                 image: DecorationImage(
                                              //                   fit: BoxFit.cover,
                                              //                   image: AssetImage("assets/images/unavailable.png"),
                                              //                 ),
                                              //               ),
                                              //             ),
                                              //           ))
                                            ],
                                          ),
                                          SizedBox(
                                            height: 1.h,
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(left: 2.w),
                                            child: Text(
                                              controller.establishmentsList[index].name,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: Theme.of(context).textTheme.labelMedium,
                                            ),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(left: 2.w),
                                            child: Row(
                                              children: [
                                                Text(
                                                  "${AppLocalizations.of(context)!.price}: ${MoneyFormatter.formatMoney(amount: controller.establishmentsList[index].price)}",
                                                  style: Theme.of(context).textTheme.labelSmall!.copyWith(fontSize: 9.sp),
                                                ),
                                                Text(
                                                  " (${controller.establishmentsList[index].category})",
                                                  style: Theme.of(context).textTheme.labelSmall!.copyWith(color: AppColors.darkBlue, fontSize: 9.sp),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 2.h,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
              ))
            ],
          ),
        ),
      ),
    );
  }
}
