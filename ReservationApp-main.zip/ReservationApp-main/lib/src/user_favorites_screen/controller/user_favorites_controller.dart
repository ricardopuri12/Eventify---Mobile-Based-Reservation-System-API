import 'dart:async';
import 'dart:convert';
import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/services/loading_services.dart';
import 'package:hotelreservation/services/message_dialog.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../../../model/establishments_model.dart';
import '../../../services/getstorage_services.dart';

class UserFavoritesController extends GetxController {
  TextEditingController search = TextEditingController();

  DateTime? from;
  DateTime? to;

  RxDouble reservationPrice = 0.0.obs;
  RxString dateRange = ''.obs;
  Timer? debounce;
  RxList<Establishments> establishmentsList = <Establishments>[].obs;
  RxList<Establishments> establishmentsMasterList = <Establishments>[].obs;

  RxString categoryFilterValue = 'All'.obs;
  RxList<String> categoryFilterList = [
    'All',
    'Hotel',
    'Villa',
    'Resort',
  ].obs;

  StreamSubscription<dynamic>? favoritesListener;

  String userID = Get.find<StorageServices>().storage.read('email').toString();
  String userName = "${Get.find<StorageServices>().storage.read('firstname')} ${Get.find<StorageServices>().storage.read('lastname')}";
  String userImage = Get.find<StorageServices>().storage.read('profilePicture').toString();

  getFavoriteEstablishment() async {
    try {
      favoritesListener = FirebaseFirestore.instance.collection('favorites').orderBy('datecreated', descending: true).snapshots().listen((event) {
        var establishments = event.docs;
        List tempList = [];
        for (var i = 0; i < establishments.length; i++) {
          Map mapdata = establishments[i].data();
          mapdata['id'] = establishments[i].id;
          mapdata['datecreated'] = mapdata['datecreated'].toDate().toString();

          tempList.add(mapdata);
        }
        establishmentsList.assignAll(establishmentsFromJson(jsonEncode(tempList)));
        establishmentsMasterList.assignAll(establishmentsFromJson(jsonEncode(tempList)));
      });
    } catch (e) {
      log("ERROR (getFavoriteEstablishment) $e");
    }
  }

  searchEstablishment() async {
    establishmentsList.clear();

    log((search.text.isEmpty && categoryFilterValue.value.trim().toString() != "All").toString());
    for (var i = 0; i < establishmentsMasterList.length; i++) {
      if (search.text.isNotEmpty && categoryFilterValue.value != "All") {
        log("3");
        if (establishmentsMasterList[i].name.toLowerCase().toString().contains(search.text.toLowerCase().toString()) &&
            establishmentsMasterList[i].category == categoryFilterValue.value) {
          establishmentsList.add(establishmentsMasterList[i]);
        }
      }
      if (search.text.isNotEmpty && categoryFilterValue.value == "All") {
        log("2");
        if (establishmentsMasterList[i].name.toLowerCase().toString().contains(search.text.toLowerCase().toString())) {
          establishmentsList.add(establishmentsMasterList[i]);
        }
      }
      if (search.text.isEmpty && categoryFilterValue.value != "All") {
        log("1");
        if (establishmentsMasterList[i].category == categoryFilterValue.value) {
          establishmentsList.add(establishmentsMasterList[i]);
        }
      }
    }

    if (search.text.isEmpty && categoryFilterValue.value == "All") {
      establishmentsList.assignAll(establishmentsMasterList);
    }
  }

  deleteToFavorites({required String favoriteID}) async {
    try {
      log("called?");
      LoadingDialog.showLoadingDialog();
      await FirebaseFirestore.instance.collection('favorites').doc(favoriteID).delete();
      Get.back();
      MessageDialog.showMessageDialog(
        message: AppLocalizations.of(Get.context!)!.favoriteremoved,
      );
    } catch (e) {
      log("ERROR (deleteToFavorites) $e");
    }
  }

  @override
  void onReady() async {
    await getFavoriteEstablishment();
    super.onReady();
  }

  @override
  void onClose() {
    if (favoritesListener != null) {
      favoritesListener!.cancel();
    }
    super.onClose();
  }
}
