import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/config/app_colors.dart';
import 'package:hotelreservation/src/admin_home_screen/view/admin_establishment_details_view.dart';
import 'package:sizer/sizer.dart';
import '../../../services/getstorage_services.dart';
import '../../../services/loading_services.dart';
import '../../../services/money_formatter.dart';
import '../../login_screen/view/login_page.dart';
import '../controller/admin_home_controller.dart';
import 'admin_add_establishment_view.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class AdminHomePage extends GetView<AdminHomeController> {
  const AdminHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          AppLocalizations.of(context)!.establishment,
          style: Theme.of(context).textTheme.labelLarge,
        ),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 5.w),
            child: GestureDetector(
                onTap: () {
                  controller.name.clear();
                  controller.price.clear();
                  controller.slot.clear();
                  controller.pax.clear();
                  controller.descriptionEnglish.clear();
                  controller.descriptionFrench.clear();
                  controller.descriptionSpanish.clear();
                  controller.categoryValue.value = 'Hotel';
                  controller.fileName.value = '';
                  controller.filePath.value = '';
                  controller.establishmentImage.value = '';
                  Get.to(() => const AdminAddEstablishmentPage());
                },
                child: const Icon(Icons.add)),
          ),
          Padding(
            padding: EdgeInsets.only(right: 5.w),
            child: GestureDetector(
                onTap: () {
                  LoadingDialog.showLoadingDialog();
                  Future.delayed(const Duration(seconds: 3), () {
                    FirebaseAuth.instance.signOut();
                    Get.find<StorageServices>().removeStorageCredentials();
                    Get.offAll(() => const LoginPage());
                  });
                },
                child: const Icon(Icons.logout)),
          )
        ],
      ),
      body: SizedBox(
        height: 100.h,
        width: 100.w,
        child: Padding(
          padding: EdgeInsets.only(left: 5.w, right: 5.w),
          child: Column(
            children: [
              SizedBox(
                height: 2.h,
              ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 7.h,
                    width: 36.w,
                    child: TextField(
                      controller: controller.search,
                      style: Theme.of(context).textTheme.bodyMedium,
                      onChanged: (value) {
                        if (controller.debounce?.isActive ?? false) {
                          controller.debounce?.cancel();
                        }
                        controller.debounce = Timer(const Duration(milliseconds: 500), () {
                          controller.searchEstablishment();
                        });
                      },
                      decoration: InputDecoration(
                        filled: true,
                        contentPadding: EdgeInsets.only(left: 3.w),
                        alignLabelWithHint: false,
                        hintText: AppLocalizations.of(context)!.search,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(5)),
                        hintStyle: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(bottom: .5.h),
                    child: Container(
                      height: 5.4.h,
                      width: 50.w,
                      decoration: BoxDecoration(border: Border.all(), borderRadius: BorderRadius.circular(5)),
                      child: Padding(
                        padding: EdgeInsets.only(left: 3.w, right: 3.w),
                        child: Obx(
                          () => DropdownButton<String>(
                            value: controller.categoryFilterValue.value,
                            isExpanded: true,
                            underline: const SizedBox(),
                            onChanged: (String? value) {
                              controller.categoryFilterValue.value = value!;
                              controller.searchEstablishment();
                            },
                            items: controller.categoryFilterList.map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(
                                  value == "All" ? AppLocalizations.of(context)!.all : value,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(context).textTheme.bodySmall,
                                ),
                              );
                            }).toList(),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 2.h,
              ),
              Expanded(
                  child: Obx(
                () => controller.establishmentsList.isEmpty
                    ? Center(
                        child: Text(
                          AppLocalizations.of(context)!.noavailableestablishments,
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      )
                    : SizedBox(
                        child: Obx(
                          () => ListView.builder(
                            itemCount: controller.establishmentsList.length,
                            itemBuilder: (BuildContext context, int index) {
                              return Padding(
                                padding: EdgeInsets.only(
                                  top: 2.h,
                                ),
                                child: SizedBox(
                                  width: 100.w,
                                  child: GestureDetector(
                                    onTap: () {
                                      controller.hasDetails.value = true;
                                      controller.establishmentDetails = controller.establishmentsList[index];
                                      Get.to(() => const AdminEstablishmentDetailsPage());
                                    },
                                    child: Card(
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          CachedNetworkImage(
                                            imageUrl: controller.establishmentsList[index].image,
                                            imageBuilder: (context, imageProvider) => Container(
                                              height: 20.h,
                                              width: 100.w,
                                              decoration: BoxDecoration(
                                                borderRadius: const BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10)),
                                                image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: imageProvider,
                                                ),
                                              ),
                                            ),
                                            placeholder: (context, url) => Container(
                                              height: 20.h,
                                              width: 100.w,
                                              decoration: const BoxDecoration(
                                                borderRadius: BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10)),
                                                image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: AssetImage("assets/images/launcher.png"),
                                                ),
                                              ),
                                            ),
                                            errorWidget: (context, url, error) => Container(
                                              height: 20.h,
                                              width: 100.w,
                                              decoration: const BoxDecoration(
                                                borderRadius: BorderRadius.only(topLeft: Radius.circular(10), topRight: Radius.circular(10)),
                                                image: DecorationImage(
                                                  fit: BoxFit.cover,
                                                  image: AssetImage("assets/images/launcher.png"),
                                                ),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 1.h,
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(left: 2.w, right: 2.w),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Text(
                                                  controller.establishmentsList[index].name,
                                                  maxLines: 1,
                                                  overflow: TextOverflow.ellipsis,
                                                  style: Theme.of(context).textTheme.labelMedium,
                                                ),
                                                controller.establishmentsList[index].rating != null
                                                    ? Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        children: [
                                                          Text(
                                                            controller.establishmentsList[index].rating!.toStringAsFixed(1),
                                                            maxLines: 1,
                                                            overflow: TextOverflow.ellipsis,
                                                            style: Theme.of(context).textTheme.labelSmall,
                                                          ),
                                                          Icon(
                                                            Icons.star,
                                                            color: Colors.yellow,
                                                            size: 15.sp,
                                                          )
                                                        ],
                                                      )
                                                    : const SizedBox()
                                              ],
                                            ),
                                          ),
                                          Padding(
                                            padding: EdgeInsets.only(left: 2.w),
                                            child: Row(
                                              children: [
                                                Text(
                                                  "${AppLocalizations.of(context)!.price}: ${MoneyFormatter.formatMoney(amount: controller.establishmentsList[index].price)}",
                                                  style: Theme.of(context).textTheme.labelSmall!.copyWith(fontSize: 9.sp),
                                                ),
                                                Text(
                                                  " (${controller.establishmentsList[index].category})",
                                                  style: Theme.of(context).textTheme.labelSmall!.copyWith(color: AppColors.darkBlue, fontSize: 9.sp),
                                                ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(
                                            height: 2.h,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                      ),
              ))
            ],
          ),
        ),
      ),
    );
  }
}
