import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import '../../../config/app_colors.dart';
import '../../../services/money_formatter.dart';
import '../controller/admin_home_controller.dart';
import '../dialog/admin_delete_establishment_confirmation_dialog.dart';
import 'admin_edit_establishment_view.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class AdminEstablishmentDetailsPage extends GetView<AdminHomeController> {
  const AdminEstablishmentDetailsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Obx(
      () => controller.hasDetails.value == false
          ? SizedBox(
              height: 100.h,
              width: 100.w,
              child: Center(
                child: SpinKitThreeBounce(
                  color: AppColors.darkBlue,
                  size: 35.sp,
                ),
              ),
            )
          : SizedBox(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Stack(
                      children: [
                        CachedNetworkImage(
                          imageUrl: controller.establishmentDetails!.image,
                          imageBuilder: (context, imageProvider) => Container(
                            height: 35.h,
                            width: 100.w,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: imageProvider,
                              ),
                            ),
                          ),
                          placeholder: (context, url) => Container(
                            height: 35.h,
                            width: 100.w,
                            decoration: const BoxDecoration(
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: AssetImage("assets/images/launcher.png"),
                              ),
                            ),
                          ),
                          errorWidget: (context, url, error) => Container(
                            height: 35.h,
                            width: 100.w,
                            decoration: const BoxDecoration(
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: AssetImage("assets/images/launcher.png"),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          top: 5.h,
                          right: 6.w,
                          child: Row(
                            children: [
                              GestureDetector(
                                onTap: () {
                                  controller.name.text = controller.establishmentDetails!.name;
                                  controller.price.text = controller.establishmentDetails!.price.toString();
                                  controller.descriptionEnglish.text = controller.establishmentDetails!.descriptionEnglish.toString();
                                  controller.categoryValue.value = controller.establishmentDetails!.category.toString();
                                  controller.fileName.value = '';
                                  controller.filePath.value = '';
                                  controller.establishmentImage.value = controller.establishmentDetails!.image.toString();
                                  Get.to(() => const AdminEditEstablishmentPage());
                                },
                                child: const CircleAvatar(
                                  backgroundColor: AppColors.darkBlue,
                                  child: Icon(
                                    Icons.edit,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 2.w,
                              ),
                              GestureDetector(
                                onTap: () {
                                  AdminDeleteEstablishmentConfirmation.showConfirmationDialog(controller: controller, establishmentDetail: controller.establishmentDetails!);
                                },
                                child: const CircleAvatar(
                                  backgroundColor: AppColors.darkBlue,
                                  child: Icon(
                                    Icons.delete,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Positioned(
                          top: 5.h,
                          left: 6.w,
                          child: GestureDetector(
                            onTap: () {
                              Get.back();
                            },
                            child: const CircleAvatar(
                              backgroundColor: AppColors.darkBlue,
                              child: Icon(
                                Icons.arrow_back,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                    SizedBox(
                      height: 1.h,
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 5.w, right: 5.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            controller.establishmentDetails!.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.labelLarge,
                          ),
                          controller.establishmentDetails!.rating != null
                              ? Row(
                                  children: [
                                    Text(
                                      controller.establishmentDetails!.rating!.toStringAsFixed(1),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: Theme.of(context).textTheme.labelMedium,
                                    ),
                                    const Icon(
                                      Icons.star,
                                      color: Colors.yellow,
                                    )
                                  ],
                                )
                              : const SizedBox.shrink(),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 5.w, right: 5.w),
                      child: Row(
                        children: [
                          Text(
                            "${AppLocalizations.of(context)!.price}: ${MoneyFormatter.formatMoney(amount: controller.establishmentDetails!.price)}",
                            style: Theme.of(context).textTheme.labelSmall!.copyWith(fontSize: 12.sp),
                          ),
                          Text(
                            " (${controller.establishmentDetails!.category})",
                            style: Theme.of(context).textTheme.labelSmall!.copyWith(color: AppColors.darkBlue, fontSize: 12.sp),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 5.w, right: 5.w),
                      child: Text(
                        "${AppLocalizations.of(context)!.pax}: ${controller.establishmentDetails!.pax}",
                        style: Theme.of(context).textTheme.labelSmall!.copyWith(fontSize: 12.sp),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 5.w, right: 5.w),
                      child: Text(
                        "${AppLocalizations.of(context)!.slot}: ${controller.establishmentDetails!.slot}",
                        style: Theme.of(context).textTheme.labelSmall!.copyWith(fontSize: 12.sp),
                      ),
                    ),
                    // Padding(
                    //   padding: EdgeInsets.only(left: 5.w, right: 5.w),
                    //   child: Text(
                    //     controller.establishmentDetails!.reservationId.isEmpty ? AppLocalizations.of(context)!.available : AppLocalizations.of(context)!.reserved,
                    //     maxLines: 1,
                    //     overflow: TextOverflow.ellipsis,
                    //     style: Theme.of(context).textTheme.labelSmall!.copyWith(color: controller.establishmentDetails!.reservationId.isEmpty ? Colors.green : AppColors.red),
                    //   ),
                    // ),
                    SizedBox(
                      height: 2.h,
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 5.w, right: 5.w),
                      child: Text(
                        controller.establishmentDetails!.descriptionEnglish,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  ],
                ),
              ),
            ),
    ));
  }
}
