import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';

import '../../../config/app_colors.dart';
import '../../../config/app_fontsizes.dart';
import '../controller/admin_home_controller.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class AdminAddEstablishmentPage extends GetView<AdminHomeController> {
  const AdminAddEstablishmentPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          AppLocalizations.of(context)!.addestablishment,
        ),
      ),
      body: SizedBox(
        child: Padding(
          padding: EdgeInsets.only(
            left: 5.w,
            right: 5.w,
          ),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 2.h,
                ),
                Text(
                  AppLocalizations.of(context)!.name,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                SizedBox(
                  height: .5.h,
                ),
                SizedBox(
                  height: 7.h,
                  width: 100.w,
                  child: TextField(
                    controller: controller.name,
                    style: TextStyle(fontSize: AppFontSizes.regular),
                    decoration: InputDecoration(
                      filled: true,
                      contentPadding: EdgeInsets.only(left: 3.w),
                      alignLabelWithHint: false,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      hintStyle: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
                Text(
                  AppLocalizations.of(context)!.price,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                SizedBox(
                  height: .5.h,
                ),
                SizedBox(
                  height: 7.h,
                  width: 100.w,
                  child: TextField(
                    controller: controller.price,
                    style: TextStyle(fontSize: AppFontSizes.regular),
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9.]')),
                      FilteringTextInputFormatter.deny(RegExp(r'\.\.')), // Prevent multiple periods
                    ],
                    decoration: InputDecoration(
                      filled: true,
                      contentPadding: EdgeInsets.only(
                        left: 3.w,
                      ),
                      alignLabelWithHint: false,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      hintStyle: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
                Text(
                  AppLocalizations.of(context)!.slot,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                SizedBox(
                  height: .5.h,
                ),
                SizedBox(
                  height: 7.h,
                  width: 100.w,
                  child: TextField(
                    controller: controller.slot,
                    style: TextStyle(fontSize: AppFontSizes.regular),
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      // FilteringTextInputFormatter.deny(RegExp(r'\.\.')), // Prevent multiple periods
                    ],
                    decoration: InputDecoration(
                      filled: true,
                      contentPadding: EdgeInsets.only(
                        left: 3.w,
                      ),
                      alignLabelWithHint: false,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      hintStyle: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
                Text(
                  AppLocalizations.of(context)!.pax,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                SizedBox(
                  height: .5.h,
                ),
                SizedBox(
                  height: 7.h,
                  width: 100.w,
                  child: TextField(
                    controller: controller.pax,
                    style: TextStyle(fontSize: AppFontSizes.regular),
                    keyboardType: TextInputType.number,
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),
                      // FilteringTextInputFormatter.deny(RegExp(r'\.\.')), // Prevent multiple periods
                    ],
                    decoration: InputDecoration(
                      filled: true,
                      contentPadding: EdgeInsets.only(
                        left: 3.w,
                      ),
                      alignLabelWithHint: false,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      hintStyle: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
                Text(
                  AppLocalizations.of(context)!.category,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                SizedBox(
                  height: .5.h,
                ),
                Container(
                  height: 7.h,
                  width: 100.w,
                  decoration: BoxDecoration(border: Border.all(), borderRadius: BorderRadius.circular(5)),
                  child: Padding(
                    padding: EdgeInsets.only(left: 3.w, right: 3.w),
                    child: Center(
                      child: Obx(
                        () => DropdownButton<String>(
                          value: controller.categoryValue.value,
                          isExpanded: true,
                          underline: const SizedBox(),
                          onChanged: (String? value) {
                            // This is called when the user selects an item.
                            controller.categoryValue.value = value!;
                          },
                          items: controller.categoryList.map<DropdownMenuItem<String>>((String value) {
                            return DropdownMenuItem<String>(
                              value: value,
                              child: Text(value),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
                Text(
                  "${AppLocalizations.of(context)!.description} English",
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                SizedBox(
                  height: .5.h,
                ),
                SizedBox(
                  height: 15.h,
                  width: 100.w,
                  child: TextField(
                    controller: controller.descriptionEnglish,
                    maxLines: 5,
                    style: TextStyle(fontSize: AppFontSizes.regular),
                    decoration: InputDecoration(
                      filled: true,
                      contentPadding: EdgeInsets.only(left: 3.w, top: 2.h),
                      alignLabelWithHint: false,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      hintStyle: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
                Text(
                  "${AppLocalizations.of(context)!.description} French",
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                SizedBox(
                  height: .5.h,
                ),
                SizedBox(
                  height: 15.h,
                  width: 100.w,
                  child: TextField(
                    controller: controller.descriptionFrench,
                    maxLines: 5,
                    style: TextStyle(fontSize: AppFontSizes.regular),
                    decoration: InputDecoration(
                      filled: true,
                      contentPadding: EdgeInsets.only(left: 3.w, top: 2.h),
                      alignLabelWithHint: false,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      hintStyle: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
                Text(
                  "${AppLocalizations.of(context)!.description} Spanish",
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                SizedBox(
                  height: .5.h,
                ),
                SizedBox(
                  height: 15.h,
                  width: 100.w,
                  child: TextField(
                    controller: controller.descriptionSpanish,
                    maxLines: 5,
                    style: TextStyle(fontSize: AppFontSizes.regular),
                    decoration: InputDecoration(
                      filled: true,
                      contentPadding: EdgeInsets.only(left: 3.w, top: 2.h),
                      alignLabelWithHint: false,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      hintStyle: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
                Text(
                  AppLocalizations.of(context)!.image,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                SizedBox(
                  height: .5.h,
                ),
                GestureDetector(
                  onTap: () {
                    controller.getImage();
                  },
                  child: Obx(
                    () => Container(
                      height: 25.h,
                      width: 100.w,
                      decoration: BoxDecoration(
                          border: Border.all(color: Colors.black54, width: 1),
                          borderRadius: BorderRadius.circular(6),
                          image: controller.filePath.value.isEmpty ? null : DecorationImage(fit: BoxFit.cover, image: FileImage(File(controller.filePath.value)))),
                      child: controller.filePath.value.isEmpty ? const Icon(Icons.image) : null,
                    ),
                  ),
                ),
                SizedBox(
                  height: 4.h,
                ),
                SizedBox(
                  width: 100.w,
                  height: 7.h,
                  child: ElevatedButton(
                    style: ButtonStyle(
                        foregroundColor: MaterialStateProperty.all<Color>(AppColors.lightBlue),
                        backgroundColor: MaterialStateProperty.all<Color>(AppColors.lightBlue),
                        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0), side: const BorderSide(color: AppColors.light)))),
                    onPressed: () {
                      double? pricedouble = double.tryParse(controller.price.text);
                      if (controller.name.text.isEmpty ||
                          controller.price.text.isEmpty ||
                          controller.slot.text.isEmpty ||
                          controller.pax.text.isEmpty ||
                          controller.descriptionFrench.text.isEmpty ||
                          controller.descriptionSpanish.text.isEmpty ||
                          controller.descriptionEnglish.text.isEmpty ||
                          controller.filePath.value.isEmpty ||
                          controller.filePath.value.isEmpty) {
                        Get.snackbar("Message", AppLocalizations.of(context)!.missinginput, backgroundColor: Colors.red, colorText: Colors.white);
                      } else if (pricedouble == null) {
                        Get.snackbar("Message", AppLocalizations.of(context)!.invalidamount, backgroundColor: AppColors.red, colorText: Colors.white);
                      } else if (pricedouble == 0) {
                        Get.snackbar("Message", AppLocalizations.of(context)!.invalidamount, backgroundColor: AppColors.red, colorText: Colors.white);
                      } else {
                        // controller.addEventPost();
                        controller.addEstablishment();
                      }
                    },
                    child: Text(AppLocalizations.of(context)!.submit, style: TextStyle(fontSize: AppFontSizes.regular, color: Colors.white)),
                  ),
                ),
                SizedBox(
                  height: 2.h,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
