import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/model/establishments_model.dart';
import 'package:hotelreservation/src/admin_home_screen/controller/admin_home_controller.dart';
import 'package:sizer/sizer.dart';
import '../../../config/app_colors.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class AdminDeleteEstablishmentConfirmation {
  static showConfirmationDialog({required AdminHomeController controller, required Establishments establishmentDetail}) async {
    Get.dialog(
      AlertDialog(
        title: Text(
          AppLocalizations.of(Get.context!)!.delete,
          style: Theme.of(Get.context!).textTheme.labelMedium,
        ),
        content: Padding(
          padding: const EdgeInsets.all(5.0),
          child: SizedBox(
              child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                AppLocalizations.of(Get.context!)!.areyousureyouwanttodeletethisestablishment,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12.sp, color: Colors.black),
              ),
              SizedBox(
                height: 2.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  SizedBox(
                    height: 6.5.h,
                    child: ElevatedButton(
                        style:
                            ElevatedButton.styleFrom(shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(5))), backgroundColor: AppColors.darkBlue),
                        onPressed: () {
                          Get.back();
                        },
                        child: Text(
                          AppLocalizations.of(Get.context!)!.cancel,
                          style: Theme.of(Get.context!).textTheme.labelSmall!.copyWith(color: Colors.white),
                        )),
                  ),
                  SizedBox(
                    height: 6.5.h,
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(5))), backgroundColor: AppColors.red),
                        onPressed: () {
                          controller.deleteEstablishment(establishmentID: establishmentDetail.id);
                        },
                        child: Text(
                          AppLocalizations.of(Get.context!)!.confirm,
                          style: Theme.of(Get.context!).textTheme.labelSmall!.copyWith(color: Colors.white),
                        )),
                  ),
                ],
              )
            ],
          )),
        ),
      ),
    );
  }
}
