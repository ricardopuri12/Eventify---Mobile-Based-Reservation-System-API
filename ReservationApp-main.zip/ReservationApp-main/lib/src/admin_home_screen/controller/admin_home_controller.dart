import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/services/default_image.dart';
import 'package:hotelreservation/services/loading_services.dart';
import 'package:hotelreservation/services/message_dialog.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../../model/establishments_model.dart';
import '../../../services/getstorage_services.dart';

class AdminHomeController extends GetxController {
  TextEditingController name = TextEditingController();
  TextEditingController price = TextEditingController();
  TextEditingController pax = TextEditingController();
  TextEditingController slot = TextEditingController();
  TextEditingController descriptionEnglish = TextEditingController();
  TextEditingController descriptionFrench = TextEditingController();
  TextEditingController descriptionSpanish = TextEditingController();

  TextEditingController search = TextEditingController();
  Timer? debounce;
  RxList<Establishments> establishmentsList = <Establishments>[].obs;
  RxList<Establishments> establishmentsMasterList = <Establishments>[].obs;
  RxString categoryValue = 'Hotel'.obs;

  RxBool hasDetails = false.obs;
  Establishments? establishmentDetails;

  RxList<String> categoryList = [
    'Hotel',
    'Villa',
    'Resort',
  ].obs;
  RxString categoryFilterValue = 'All'.obs;
  RxList<String> categoryFilterList = [
    'All',
    'Hotel',
    'Villa',
    'Resort',
  ].obs;

  RxString filePath = ''.obs;
  RxString fileName = ''.obs;
  RxString establishmentImage = DefaultImage.defaultStoreLogo.obs;
  File? imageFile;

  getImage() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(allowedExtensions: ['png', 'jpg'], type: FileType.custom);
      if (result != null) {
        filePath.value = result.files.single.path!;
        fileName.value = result.files.single.name;
      } else {}
    } on Exception catch (e) {
      log("ERROR (getImage) $e");
    }
  }

  getEstablishment() async {
    try {
      var res = await FirebaseFirestore.instance.collection('establishments').orderBy('datecreated', descending: true).get();
      var establishments = res.docs;

      List tempList = [];

      for (var i = 0; i < establishments.length; i++) {
        Map mapdata = establishments[i].data();
        mapdata['id'] = establishments[i].id;
        mapdata['datecreated'] = mapdata['datecreated'].toDate().toString();
        var ratingres = await FirebaseFirestore.instance.collection('establishments').doc(establishments[i].id).collection('ratings').get();
        if (ratingres.docs.isNotEmpty) {
          double totalrating = 0.0;
          for (var i = 0; i < ratingres.docs.length; i++) {
            totalrating = totalrating + ratingres.docs[0]['rating'];
          }
          double averageRating = totalrating / ratingres.docs.length;
          mapdata['rating'] = averageRating;
        }
        tempList.add(mapdata);
      }
      establishmentsList.assignAll(establishmentsFromJson(jsonEncode(tempList)));
      establishmentsMasterList.assignAll(establishmentsFromJson(jsonEncode(tempList)));
    } catch (e) {
      log("ERROR (getEstablishment) $e");
    }
  }

  addEstablishment() async {
    try {
      LoadingDialog.showLoadingDialog();
      String filename = 'Admin-${DateTime.now().millisecondsSinceEpoch}-${fileName.value}';
      await Supabase.instance.client.storage.from('hotelreservationbucket').upload('establishment/$filename', File(filePath.value));
      var establishmentPicture = Supabase.instance.client.storage.from('hotelreservationbucket').getPublicUrl('establishment/$filename');
      await FirebaseFirestore.instance.collection('establishments').add({
        "datecreated": DateTime.now(),
        "descriptionEnglish": descriptionEnglish.text,
        "descriptionSpanish": descriptionSpanish.text,
        "descriptionFrench": descriptionFrench.text,
        "pax": int.parse(pax.text),
        "slot": int.parse(slot.text),
        "price": double.parse(price.text),
        "category": categoryValue.value,
        "name": name.text,
        "image": establishmentPicture,
      });
      Get.back();
      Get.back();
      MessageDialog.showMessageDialog(
        message: AppLocalizations.of(Get.context!)!.establishmentadded,
      );
      getEstablishment();
    } catch (e) {
      log("ERROR (addEstablishment) $e");
    }
  }

  editEstablishment({required String establishmentID}) async {
    try {
      LoadingDialog.showLoadingDialog();
      var establishmentPicture = establishmentImage.value;
      if (filePath.value.isNotEmpty) {
        String filename = 'Admin-${DateTime.now().millisecondsSinceEpoch}-${fileName.value}';
        await Supabase.instance.client.storage.from('hotelreservationbucket').upload('establishment/$filename', File(filePath.value));
        establishmentPicture = Supabase.instance.client.storage.from('hotelreservationbucket').getPublicUrl('establishment/$filename');
      }
      await FirebaseFirestore.instance.collection('establishments').doc(establishmentID).update({
        "descriptionEnglish": descriptionEnglish.text,
        "descriptionSpanish": descriptionSpanish.text,
        "descriptionFrench": descriptionFrench.text,
        "pax": int.parse(pax.text),
        "slot": int.parse(slot.text),
        "name": name.text,
        "image": establishmentPicture,
        "price": double.parse(price.text),
        "category": categoryValue.value,
      });

      hasDetails.value = false;
      await getEstablishment();
      for (var i = 0; i < establishmentsMasterList.length; i++) {
        if (establishmentsMasterList[i].id == establishmentID) {
          establishmentDetails = establishmentsMasterList[i];
        }
      }
      hasDetails.value = true;
      Get.back();
      Get.back();
      MessageDialog.showMessageDialog(
        message: AppLocalizations.of(Get.context!)!.establishmentupdated,
      );
    } catch (e) {
      log("ERROR (editEstablishment) $e");
    }
  }

  deleteEstablishment({required String establishmentID}) async {
    try {
      Get.back();
      LoadingDialog.showLoadingDialog();
      await FirebaseFirestore.instance.collection('establishments').doc(establishmentID).delete();
      await getEstablishment();
      Get.back();
      Get.back();
      MessageDialog.showMessageDialog(
        message: AppLocalizations.of(Get.context!)!.establishmentdeleted,
      );
    } catch (e) {
      log("ERROR (deleteEstablishment) $e");
    }
  }

  searchEstablishment() async {
    establishmentsList.clear();

    log((search.text.isEmpty && categoryFilterValue.value.trim().toString() != "All").toString());
    for (var i = 0; i < establishmentsMasterList.length; i++) {
      if (search.text.isNotEmpty && categoryFilterValue.value != "All") {
        log("3");
        if (establishmentsMasterList[i].name.toLowerCase().toString().contains(search.text.toLowerCase().toString()) &&
            establishmentsMasterList[i].category == categoryFilterValue.value) {
          establishmentsList.add(establishmentsMasterList[i]);
        }
      }
      if (search.text.isNotEmpty && categoryFilterValue.value == "All") {
        log("2");
        if (establishmentsMasterList[i].name.toLowerCase().toString().contains(search.text.toLowerCase().toString())) {
          establishmentsList.add(establishmentsMasterList[i]);
        }
      }
      if (search.text.isEmpty && categoryFilterValue.value != "All") {
        log("1");
        if (establishmentsMasterList[i].category == categoryFilterValue.value) {
          establishmentsList.add(establishmentsMasterList[i]);
        }
      }
    }

    if (search.text.isEmpty && categoryFilterValue.value == "All") {
      establishmentsList.assignAll(establishmentsMasterList);
    }
  }

  iniData() async {
    LoadingDialog.showLoadingDialog();
    RxString selectedLanguage = Get.find<StorageServices>().storage.read('language') == null ? "en".obs : Get.find<StorageServices>().storage.read('language').toString().obs;
    var locale = Locale(selectedLanguage.value);
    Get.updateLocale(locale);
    await getEstablishment();
    Future.delayed(const Duration(seconds: 1), () {
      Get.back();
    });
  }

  @override
  void onReady() {
    iniData();
    super.onReady();
  }
}
