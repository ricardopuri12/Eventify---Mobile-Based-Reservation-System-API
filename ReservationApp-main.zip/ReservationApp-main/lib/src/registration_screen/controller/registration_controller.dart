import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../../../config/app_colors.dart';
import '../../../services/default_image.dart';
import '../../../services/loading_services.dart';

class UsersRegistrationController extends GetxController {
  FirebaseAuth auth = FirebaseAuth.instance;

  TextEditingController email = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController confirmpassword = TextEditingController();
  TextEditingController firstname = TextEditingController();
  TextEditingController lastname = TextEditingController();
  TextEditingController storename = TextEditingController();

  RxString filepath = ''.obs;
  RxString filename = ''.obs;
  File? filePick;

  RxBool showPass = true.obs;
  RxBool showPassConfirm = true.obs;

  signUpEmailUser() async {
    LoadingDialog.showLoadingDialog();
    try {
      var res = await FirebaseFirestore.instance.collection('users').where('email', isEqualTo: email.text).get();
      if (res.docs.isNotEmpty) {
        Get.back();
        Get.snackbar(AppLocalizations.of(Get.context!)!.message, AppLocalizations.of(Get.context!)!.emailalreadyexist,
            duration: const Duration(seconds: 3), backgroundColor: AppColors.lightBlue, colorText: Colors.white);
      } else {
        await auth.createUserWithEmailAndPassword(email: email.text, password: password.text);
        var user = auth.currentUser!;
        await user.sendEmailVerification();
        await saveUser(userid: user.uid);
        await FirebaseAuth.instance.signOut();
        Future.delayed(const Duration(milliseconds: 1500), () {
          Get.back();
          Get.back();
          Get.snackbar(AppLocalizations.of(Get.context!)!.message, AppLocalizations.of(Get.context!)!.accountcreatedwehavesentemail,
              duration: const Duration(seconds: 3), backgroundColor: AppColors.lightBlue, colorText: Colors.white);
        });
      }
    } catch (e) {
      Get.snackbar(AppLocalizations.of(Get.context!)!.message, AppLocalizations.of(Get.context!)!.somethingwentwrongpleasetryagainlater,
          backgroundColor: AppColors.lightBlue, colorText: AppColors.dark);
    }
  }

  saveUser({required String userid}) async {
    try {
      // END UPLOAD STORAGE
      var userdoc = FirebaseFirestore.instance.collection('users').doc(email.text);
      FirebaseMessaging messaging = FirebaseMessaging.instance;
      String? fcmToken = await messaging.getToken();
      userdoc.set({
        "userid": email.text,
        "email": email.text,
        "profilePicture": DefaultImage.defaultImage,
        "firstname": firstname.text,
        "lastname": lastname.text,
        "fcmToken": fcmToken ?? "",
        "provider": 'email',
        "datecreated": Timestamp.now(),
      });
    } catch (e) {
      Get.snackbar(
        AppLocalizations.of(Get.context!)!.message,
        AppLocalizations.of(Get.context!)!.somethingwentwrongpleasetryagainlater,
      );
    }
  }

  getFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(allowedExtensions: ['png', 'jpg'], type: FileType.custom);
    if (result != null) {
      filepath.value = result.files.single.path!;
      filename.value = result.files.single.name;
      filePick = File(result.files.single.path!);
    } else {
      // User canceled the picker
    }
  }

  bool isValidPassword(String input) {
    // Regular expression to check the presence of:
    // - At least one letter (upper or lowercase)
    // - At least one digit
    // - At least one special character from the set of common special characters
    final RegExp hasLetter = RegExp(r'[a-zA-Z]');
    final RegExp hasDigit = RegExp(r'[0-9]');
    final RegExp hasSpecialChar = RegExp(r'[!@#$%^&*(),.?":{}|<>]');

    // Check if the input string satisfies all conditions
    return hasLetter.hasMatch(input) && hasDigit.hasMatch(input) && hasSpecialChar.hasMatch(input);
  }
}
