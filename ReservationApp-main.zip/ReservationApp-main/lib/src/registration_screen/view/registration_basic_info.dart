import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../../../config/app_colors.dart';
import '../../../config/app_fontsizes.dart';
import '../controller/registration_controller.dart';

class UsersRegistrationPage extends GetView<UsersRegistrationController> {
  const UsersRegistrationPage({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(UsersRegistrationController());
    return Scaffold(
      body: SizedBox(
        height: 100.h,
        width: 100.w,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 6.h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 2.w, right: 5.w),
                child: IconButton(
                    onPressed: () {
                      Get.back();
                    },
                    icon: const Icon(
                      Icons.arrow_back_ios,
                    )),
              ),
              Padding(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                child: Text(
                  AppLocalizations.of(context)!.registration,
                  style: Theme.of(context).textTheme.labelLarge,
                ),
              ),
              SizedBox(
                height: 11.h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                child: Text(
                  AppLocalizations.of(context)!.firstname,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
              SizedBox(
                height: .5.h,
              ),
              Container(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                height: 7.h,
                width: 100.w,
                child: TextField(
                  controller: controller.firstname,
                  style: TextStyle(fontSize: AppFontSizes.regular),
                  decoration: InputDecoration(
                    filled: true,
                    contentPadding: EdgeInsets.only(left: 3.w),
                    alignLabelWithHint: false,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    hintStyle: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                child: Text(
                  AppLocalizations.of(context)!.lastname,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
              SizedBox(
                height: .5.h,
              ),
              Container(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                height: 7.h,
                width: 100.w,
                child: TextField(
                  controller: controller.lastname,
                  style: TextStyle(fontSize: AppFontSizes.regular),
                  decoration: InputDecoration(
                    filled: true,
                    contentPadding: EdgeInsets.only(left: 3.w),
                    alignLabelWithHint: false,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    hintStyle: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                child: Text(
                  AppLocalizations.of(context)!.email,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
              SizedBox(
                height: .5.h,
              ),
              Container(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                height: 7.h,
                width: 100.w,
                child: TextField(
                  controller: controller.email,
                  style: TextStyle(fontSize: AppFontSizes.regular),
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    filled: true,
                    contentPadding: EdgeInsets.only(left: 3.w),
                    alignLabelWithHint: false,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    hintStyle: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                child: Text(
                  AppLocalizations.of(context)!.password,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
              SizedBox(
                height: .5.h,
              ),
              Container(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                height: 7.h,
                width: 100.w,
                child: Obx(
                  () => TextField(
                    controller: controller.password,
                    style: TextStyle(fontSize: AppFontSizes.regular),
                    obscureText: controller.showPass.value,
                    decoration: InputDecoration(
                      suffixIcon: GestureDetector(
                        onTap: () {
                          controller.showPass.value = controller.showPass.value ? false : true;
                        },
                        child: controller.showPass.value ? const Icon(Icons.remove_red_eye_outlined) : const Icon(Icons.remove_red_eye),
                      ),
                      filled: true,
                      contentPadding: EdgeInsets.only(left: 3.w),
                      alignLabelWithHint: false,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      hintStyle: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                child: Text(
                  AppLocalizations.of(context)!.confirmpassword,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
              SizedBox(
                height: .5.h,
              ),
              Container(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                height: 7.h,
                width: 100.w,
                child: Obx(
                  () => TextField(
                    controller: controller.confirmpassword,
                    style: TextStyle(fontSize: AppFontSizes.regular),
                    obscureText: controller.showPassConfirm.value,
                    decoration: InputDecoration(
                      suffixIcon: GestureDetector(
                        onTap: () {
                          controller.showPassConfirm.value = controller.showPassConfirm.value ? false : true;
                        },
                        child: controller.showPassConfirm.value ? const Icon(Icons.remove_red_eye_outlined) : const Icon(Icons.remove_red_eye),
                      ),
                      filled: true,
                      contentPadding: EdgeInsets.only(left: 3.w),
                      alignLabelWithHint: false,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      hintStyle: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 3.h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 5.w, right: 5.w),
                child: SizedBox(
                  width: 100.w,
                  height: 7.h,
                  child: ElevatedButton(
                    style: ButtonStyle(
                        foregroundColor: MaterialStateProperty.all<Color>(AppColors.lightBlue),
                        backgroundColor: MaterialStateProperty.all<Color>(AppColors.lightBlue),
                        shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0), side: const BorderSide(color: AppColors.lightBlue)))),
                    onPressed: () {
                      if (controller.email.text.isEmpty ||
                          controller.password.text.isEmpty ||
                          controller.confirmpassword.text.isEmpty ||
                          controller.lastname.text.isEmpty ||
                          controller.firstname.text.isEmpty) {
                        Get.snackbar(AppLocalizations.of(context)!.message, AppLocalizations.of(context)!.missinginput,
                            backgroundColor: AppColors.lightBlue, colorText: AppColors.light);
                      } else if (controller.email.text.isEmail == false) {
                        Get.snackbar(AppLocalizations.of(context)!.message, AppLocalizations.of(context)!.invalidemail,
                            backgroundColor: AppColors.lightBlue, colorText: AppColors.light);
                      } else if (controller.password.text != controller.confirmpassword.text) {
                        Get.snackbar(AppLocalizations.of(context)!.message, AppLocalizations.of(context)!.passworddidnotmatch,
                            backgroundColor: AppColors.lightBlue, colorText: AppColors.light);
                      } else if (controller.isValidPassword(controller.password.text) == false) {
                        Get.snackbar(AppLocalizations.of(context)!.message, AppLocalizations.of(context)!.passwordspecialcharacters,
                            backgroundColor: AppColors.lightBlue, colorText: AppColors.light);
                      } else if (controller.password.text.length < 5) {
                        Get.snackbar(AppLocalizations.of(context)!.message, AppLocalizations.of(context)!.passwordcharacterlong,
                            backgroundColor: AppColors.lightBlue, colorText: AppColors.light);
                      } else {
                        controller.signUpEmailUser();
                      }
                    },
                    child: Text(AppLocalizations.of(context)!.register.toString().capitalize.toString(), style: TextStyle(fontSize: AppFontSizes.regular, color: Colors.white)),
                  ),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
