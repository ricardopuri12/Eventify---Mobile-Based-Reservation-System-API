import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/src/user_favorites_screen/controller/user_favorites_controller.dart';
import 'package:hotelreservation/src/user_home_screen/controller/user_home_controller.dart';
import 'package:hotelreservation/src/user_reservations_screen/controller/user_reservation_controller.dart';
import 'package:sizer/sizer.dart';
import '../../../config/app_colors.dart';
import '../controller/user_bottom_nav_controller.dart';
import '../drawer/app_drawer.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class UserBottomNavPage extends GetView<UserBottomNavController> {
  const UserBottomNavPage({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(UserBottomNavController());
    Get.put(UserHomeController());
    Get.put(UserReservationListController());
    Get.put(UserFavoritesController());

    return Scaffold(
      key: controller.scaffoldKey,
      drawer: AppDrawer.appDrawer(controller: controller),
      body: Obx(() => controller.body[controller.currentIndex.value]),
      bottomNavigationBar: SizedBox(
        height: 10.h,
        width: 100.w,
        child: Obx(
          () => BottomNavigationBar(
            selectedItemColor: AppColors.lightBlue,
            unselectedItemColor: AppColors.dark,
            showUnselectedLabels: true,
            type: BottomNavigationBarType.fixed,
            onTap: (index) {
              controller.currentIndex.value = index;
            },
            currentIndex: controller.currentIndex.value,
            items: [
              BottomNavigationBarItem(icon: const Icon(Icons.home), label: AppLocalizations.of(context)!.home, backgroundColor: Theme.of(context).bottomAppBarTheme.color),
              BottomNavigationBarItem(icon: const Icon(Icons.list), label: AppLocalizations.of(context)!.reservation, backgroundColor: Theme.of(context).bottomAppBarTheme.color),
              BottomNavigationBarItem(icon: const Icon(Icons.favorite), label: AppLocalizations.of(context)!.favorites, backgroundColor: Theme.of(context).bottomAppBarTheme.color),
            ],
          ),
        ),
      ),
    );
  }
}
