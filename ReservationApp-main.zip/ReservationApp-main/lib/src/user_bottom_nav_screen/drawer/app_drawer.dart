import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import '../../../config/app_colors.dart';
import '../../../services/getstorage_services.dart';
import '../../../services/loading_services.dart';
import '../../login_screen/view/login_page.dart';
import '../../user_profile_screen/view/user_profile_view.dart';
import '../controller/user_bottom_nav_controller.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class AppDrawer {
  static appDrawer({required UserBottomNavController controller}) {
    return Drawer(
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(0),
        ),
      ),
      child: Padding(
        padding: EdgeInsets.only(left: 3.w),
        child: ListView(
          children: [
            SizedBox(
              height: 14.h,
              child: SizedBox(
                width: 100.w,
                child: Padding(
                  padding: EdgeInsets.only(left: 2.w),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      CircleAvatar(
                        radius: 4.2.h,
                        backgroundColor: AppColors.lightBlue,
                        child: Obx(
                          () => CircleAvatar(
                            radius: 4.h,
                            backgroundImage: NetworkImage(controller.userImage.value),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 2.w,
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          SizedBox(
                            width: 40.w,
                            child: Obx(
                              () => Text(
                                "${controller.userFirstName.value} ${controller.userLastName.value}",
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(Get.context!).textTheme.labelMedium!.copyWith(fontSize: 10.sp),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 40.w,
                            child: Obx(
                              () => Text(
                                controller.userEmail.value,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: Theme.of(Get.context!).textTheme.labelSmall!.copyWith(color: AppColors.lightBlue, fontSize: 10.sp),
                              ),
                            ),
                          )
                        ],
                      )
                    ],
                  ),
                ),
              ),
            ),
            ListTile(
              onTap: () {
                Get.back();
                controller.currentIndex.value = 0;
              },
              leading: const Icon(
                Icons.home,
                color: AppColors.darkBlue,
              ),
              title: Text(
                AppLocalizations.of(Get.context!)!.home,
                style: Theme.of(Get.context!).textTheme.labelMedium,
              ),
            ),
            ListTile(
              onTap: () {
                Get.back();
                controller.currentIndex.value = 1;
              },
              leading: const Icon(
                Icons.list,
                color: AppColors.darkBlue,
              ),
              title: Text(
                AppLocalizations.of(Get.context!)!.reservation,
                style: Theme.of(Get.context!).textTheme.labelMedium,
              ),
            ),
            ListTile(
              onTap: () {
                Get.back();
                controller.currentIndex.value = 2;
              },
              leading: const Icon(
                Icons.favorite,
                color: AppColors.darkBlue,
              ),
              title: Text(
                AppLocalizations.of(Get.context!)!.favorites,
                style: Theme.of(Get.context!).textTheme.labelMedium,
              ),
            ),
            ListTile(
              onTap: () {
                Get.back();
                Get.to(() => const UserProfilePage());
              },
              leading: const Icon(
                Icons.person,
                color: AppColors.darkBlue,
              ),
              title: Text(
                AppLocalizations.of(Get.context!)!.profile,
                style: Theme.of(Get.context!).textTheme.labelMedium,
              ),
            ),
            ListTile(
              onTap: () {
                Get.back();
                LoadingDialog.showLoadingDialog();
                Future.delayed(const Duration(seconds: 3), () {
                  FirebaseAuth.instance.signOut();
                  Get.find<StorageServices>().removeStorageCredentials();
                  Get.offAll(() => const LoginPage());
                });
              },
              leading: const Icon(
                Icons.logout,
                color: AppColors.darkBlue,
              ),
              title: Text(
                AppLocalizations.of(Get.context!)!.logout,
                style: Theme.of(Get.context!).textTheme.labelMedium,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
