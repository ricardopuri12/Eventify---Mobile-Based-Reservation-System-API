import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/services/default_image.dart';
import 'package:hotelreservation/src/user_favorites_screen/view/user_favorites_view.dart';

import '../../../services/getstorage_services.dart';
import '../../user_home_screen/view/user_home_view.dart';
import '../../user_reservations_screen/view/user_reservation_view.dart';

class UserBottomNavController extends GetxController {
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey();

  FirebaseMessaging messaging = FirebaseMessaging.instance;
  String userID = Get.find<StorageServices>().storage.read('id');

  RxString userEmail = ''.obs;
  RxString userFirstName = ''.obs;
  RxString userLastName = ''.obs;
  RxString userImage = DefaultImage.defaultImage.obs;

  RxInt currentIndex = 0.obs;

  final List<Widget> body = [
    const UserHomePage(),
    const UserReservationListPage(),
    const UserFavoritesPage(),
  ];

  getUserDetails() async {
    try {
      var storeDetails = await FirebaseFirestore.instance.collection('users').doc(userID).get();
      if (storeDetails.exists) {
        userEmail.value = storeDetails.get('email');
        userFirstName.value = storeDetails.get('firstname');
        userLastName.value = storeDetails.get('lastname');
        userImage.value = storeDetails.get('profilePicture');
      }
    } on Exception catch (e) {
      log("ERROR (getUserDetails) $e");
    }
  }

  Future updateFcmToken() async {
    try {
      FirebaseMessaging messaging = FirebaseMessaging.instance;
      String? fcmToken = await messaging.getToken();
      await FirebaseFirestore.instance.collection('users').doc(userID).update({"fcmToken": fcmToken});
    } catch (e) {
      log("ERROR (updateFcmToken) $e");
    }
  }

  @override
  void onInit() async {
    await updateFcmToken().then((value) {
      getUserDetails();
    });
    super.onInit();
  }
}
