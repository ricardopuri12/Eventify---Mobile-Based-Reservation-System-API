import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import '../../../config/app_colors.dart';
import '../../../config/app_fontsizes.dart';
import '../controller/user_profile_controller.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class ChangeAccountName {
  static showChangeAccountName({
    required UserProfileController controller,
    required String fname,
    required String lname,
  }) async {
    TextEditingController firstname = TextEditingController(text: fname);
    TextEditingController lastname = TextEditingController(text: lname);

    Get.dialog(
      AlertDialog(
        content: SizedBox(
            child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 2.h,
              ),
              Container(
                height: 35.w,
                width: 100.w,
                decoration: const BoxDecoration(image: DecorationImage(image: AssetImage("assets/images/logo.png"))),
              ),
              SizedBox(
                height: 2.h,
              ),
              Text(
                AppLocalizations.of(Get.context!)!.firstname,
                style: Theme.of(Get.context!).textTheme.bodyMedium!.copyWith(color: Colors.black),
              ),
              SizedBox(
                height: 7.h,
                width: 100.w,
                child: TextField(
                  controller: firstname,
                  style: Theme.of(Get.context!).textTheme.bodyMedium!.copyWith(color: Colors.black),
                  decoration: InputDecoration(
                      fillColor: AppColors.light,
                      filled: true,
                      contentPadding: EdgeInsets.only(left: 3.w),
                      alignLabelWithHint: false,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      hintText: AppLocalizations.of(Get.context!)!.firstname,
                      hintStyle: const TextStyle(fontFamily: 'Bariol')),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Text(
                AppLocalizations.of(Get.context!)!.lastname,
                style: Theme.of(Get.context!).textTheme.bodyMedium!.copyWith(color: Colors.black),
              ),
              SizedBox(
                height: 7.h,
                width: 100.w,
                child: TextField(
                  controller: lastname,
                  style: Theme.of(Get.context!).textTheme.bodyMedium!.copyWith(color: Colors.black),
                  decoration: InputDecoration(
                      fillColor: AppColors.light,
                      filled: true,
                      contentPadding: EdgeInsets.only(left: 3.w),
                      alignLabelWithHint: false,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      hintText: AppLocalizations.of(Get.context!)!.lastname,
                      hintStyle: const TextStyle(fontFamily: 'Bariol')),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              SizedBox(
                height: 7.h,
                width: 100.w,
                child: ElevatedButton(
                  style: ButtonStyle(
                      foregroundColor: const MaterialStatePropertyAll(AppColors.darkBlue),
                      backgroundColor: const MaterialStatePropertyAll(AppColors.darkBlue),
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0), side: const BorderSide(color: Colors.white)))),
                  onPressed: () {
                    if (lastname.text.isEmpty || firstname.text.isEmpty) {
                      Get.snackbar(AppLocalizations.of(Get.context!)!.lastname, AppLocalizations.of(Get.context!)!.message,
                          backgroundColor: AppColors.red, colorText: AppColors.light);
                    } else {
                      controller.changeAccountName(fname: firstname.text, lname: lastname.text);
                    }
                  },
                  child: Text(AppLocalizations.of(Get.context!)!.save, style: TextStyle(fontSize: AppFontSizes.regular, color: Colors.white)),
                ),
              ),
            ],
          ),
        )),
      ),
    );
  }
}
