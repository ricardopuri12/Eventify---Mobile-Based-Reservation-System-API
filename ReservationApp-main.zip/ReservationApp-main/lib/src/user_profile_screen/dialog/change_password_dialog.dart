import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import '../../../config/app_colors.dart';
import '../../../config/app_fontsizes.dart';
import '../controller/user_profile_controller.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class ChangePassword {
  static showChangePassword({required UserProfileController controller}) async {
    TextEditingController passcode = TextEditingController();
    TextEditingController oldPasscode = TextEditingController();

    RxBool showPass = true.obs;
    RxBool showOldPass = true.obs;

    Get.dialog(
      AlertDialog(
        content: SizedBox(
            child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SizedBox(
                height: 2.h,
              ),
              Container(
                height: 35.w,
                width: 100.w,
                decoration: const BoxDecoration(image: DecorationImage(image: AssetImage("assets/images/logo.png"))),
              ),
              SizedBox(
                height: 2.h,
              ),
              SizedBox(
                height: 7.h,
                width: 100.w,
                child: Obx(
                  () => TextField(
                    controller: oldPasscode,
                    obscureText: showOldPass.value,
                    style: Theme.of(Get.context!).textTheme.bodyMedium!.copyWith(color: Colors.black),
                    // keyboardType: TextInputType.number, // Numeric keyboard
                    // inputFormatters: <TextInputFormatter>[
                    //   FilteringTextInputFormatter
                    //       .digitsOnly, // Only numbers allowed
                    // ],

                    decoration: InputDecoration(
                        suffixIcon: GestureDetector(
                          onTap: () {
                            showOldPass.value = showOldPass.value ? false : true;
                          },
                          child: showOldPass.value ? const Icon(Icons.remove_red_eye_outlined) : const Icon(Icons.remove_red_eye),
                        ),
                        fillColor: AppColors.light,
                        filled: true,
                        contentPadding: EdgeInsets.only(left: 3.w),
                        alignLabelWithHint: false,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                        hintText: AppLocalizations.of(Get.context!)!.oldpasscode,
                        hintStyle: const TextStyle(fontFamily: 'Bariol')),
                  ),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              SizedBox(
                height: 7.h,
                width: 100.w,
                child: Obx(
                  () => TextField(
                    controller: passcode,
                    obscureText: showPass.value,
                    style: Theme.of(Get.context!).textTheme.bodyMedium!.copyWith(color: Colors.black),
                    // keyboardType: TextInputType.number, // Numeric keyboard
                    // inputFormatters: <TextInputFormatter>[
                    //   FilteringTextInputFormatter
                    //       .digitsOnly, // Only numbers allowed
                    // ],

                    decoration: InputDecoration(
                        suffixIcon: GestureDetector(
                          onTap: () {
                            showPass.value = showPass.value ? false : true;
                          },
                          child: showPass.value ? const Icon(Icons.remove_red_eye_outlined) : const Icon(Icons.remove_red_eye),
                        ),
                        fillColor: AppColors.light,
                        filled: true,
                        contentPadding: EdgeInsets.only(left: 3.w),
                        alignLabelWithHint: false,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                        hintText: AppLocalizations.of(Get.context!)!.newpasscode,
                        hintStyle: const TextStyle(fontFamily: 'Bariol')),
                  ),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              SizedBox(
                height: 7.h,
                width: 100.w,
                child: ElevatedButton(
                  style: ButtonStyle(
                      foregroundColor: const MaterialStatePropertyAll(AppColors.black),
                      backgroundColor: const MaterialStatePropertyAll(AppColors.darkBlue),
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0), side: const BorderSide(color: Colors.white)))),
                  onPressed: () {
                    if (controller.isValidPassword(passcode.text) == false) {
                      Get.snackbar(AppLocalizations.of(Get.context!)!.message, AppLocalizations.of(Get.context!)!.passwordmusthavespecialcharacter,
                          backgroundColor: AppColors.red, colorText: AppColors.light);
                    } else if (passcode.text.length < 5) {
                      Get.snackbar(AppLocalizations.of(Get.context!)!.message, AppLocalizations.of(Get.context!)!.passwordmustbeatleastfivecharacterslong,
                          backgroundColor: AppColors.red, colorText: AppColors.light);
                    } else {
                      controller.changePassword(password: passcode.text, oldPassword: oldPasscode.text);
                    }
                  },
                  child: Text(AppLocalizations.of(Get.context!)!.save, style: TextStyle(fontSize: AppFontSizes.regular, color: Colors.white)),
                ),
              ),
            ],
          ),
        )),
      ),
    );
  }
}
