import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/src/user_profile_screen/controller/user_profile_controller.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../../../config/app_colors.dart';
import '../dialog/change_account_name.dart';
import '../dialog/change_password_dialog.dart';

class UserProfilePage extends GetView<UserProfileController> {
  const UserProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(UserProfileController());
    return Scaffold(
      appBar: AppBar(
          title: Text(
        AppLocalizations.of(Get.context!)!.profile,
        style: Theme.of(context).textTheme.labelLarge,
      )),
      body: SizedBox(
        child: Padding(
          padding: EdgeInsets.only(left: 5.w, right: 5.w),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 3.h,
                ),
                Text(
                  AppLocalizations.of(Get.context!)!.accountdetails,
                  style: Theme.of(context).textTheme.labelMedium,
                ),
                SizedBox(
                  height: 5.h,
                ),
                SizedBox(
                  width: 100.w,
                  child: Padding(
                    padding: EdgeInsets.only(left: 2.w),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        CircleAvatar(
                          radius: 4.2.h,
                          backgroundColor: AppColors.lightBlue,
                          child: Obx(
                            () => CircleAvatar(
                              radius: 4.h,
                              backgroundImage: NetworkImage(controller.profilePicture.value),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 3.w,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 60.w,
                              child: Obx(
                                () => Text(
                                  "${controller.userFirstName.value} ${controller.userLastName.value}",
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(Get.context!).textTheme.labelMedium!.copyWith(fontSize: 12.sp),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 60.w,
                              child: Obx(
                                () => Text(
                                  controller.userEmail.value,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: Theme.of(Get.context!).textTheme.labelSmall!.copyWith(color: AppColors.lightBlue, fontSize: 10.sp),
                                ),
                              ),
                            )
                          ],
                        )
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 4.h,
                ),
                GestureDetector(
                  onTap: () {
                    ChangeAccountName.showChangeAccountName(controller: controller, fname: controller.userFirstName.value, lname: controller.userLastName.value);
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.person),
                          SizedBox(
                            width: 2.w,
                          ),
                          Text(
                            AppLocalizations.of(Get.context!)!.changeaccountname,
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ],
                      ),
                      const Icon(Icons.chevron_right)
                    ],
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                GestureDetector(
                  onTap: () {
                    ChangePassword.showChangePassword(controller: controller);
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.password),
                          SizedBox(
                            width: 2.w,
                          ),
                          Text(
                            AppLocalizations.of(Get.context!)!.changeaccountpassword,
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ],
                      ),
                      const Icon(Icons.chevron_right)
                    ],
                  ),
                ),
                SizedBox(
                  height: 3.h,
                ),
                GestureDetector(
                  onTap: () {
                    controller.changeAccountProfileImage();
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.person_pin),
                          SizedBox(
                            width: 2.w,
                          ),
                          Text(
                            AppLocalizations.of(Get.context!)!.changeaccountimage,
                            style: Theme.of(context).textTheme.bodyMedium,
                          ),
                        ],
                      ),
                      const Icon(Icons.chevron_right)
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
