import 'dart:developer';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:supabase_flutter/supabase_flutter.dart' as supabase;
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../../../config/app_colors.dart';
import '../../../services/default_image.dart';
import '../../../services/getstorage_services.dart';
import '../../../services/loading_services.dart';
import '../../../services/message_dialog.dart';
import '../../user_bottom_nav_screen/controller/user_bottom_nav_controller.dart';

class UserProfileController extends GetxController {
  RxString profilePicture = DefaultImage.defaultImage.obs;
  RxString userFirstName = ''.obs;
  RxString userLastName = ''.obs;
  RxString userEmail = ''.obs;

  String userID = Get.find<StorageServices>().storage.read('id');

  getUserProfile() async {
    try {
      var user = await FirebaseFirestore.instance.collection('users').doc(userID).get();
      if (user.exists) {
        profilePicture.value = user.get('profilePicture');
        userFirstName.value = user.get('firstname');
        userLastName.value = user.get('lastname');
        userEmail.value = user.get('email');
      }
    } catch (e) {
      log("ERROR (getUserProfile) $e");
    }
  }

  changeAccountProfileImage() async {
    try {
      FilePickerResult? result = await FilePicker.platform.pickFiles(allowedExtensions: ['png', 'jpg'], type: FileType.custom);
      if (result != null) {
        LoadingDialog.showLoadingDialog();
        String filepath = result.files.single.path!;
        String filename = result.files.single.name;
        String fileName = '$userID-${DateTime.now().millisecondsSinceEpoch}-$filename';
        await supabase.Supabase.instance.client.storage.from('hotelreservationbucket').upload('usersimage/$fileName', File(filepath));
        var profileLink = supabase.Supabase.instance.client.storage.from('hotelreservationbucket').getPublicUrl('usersimage/$fileName');
        await FirebaseFirestore.instance.collection('users').doc(userID).update({
          "profilePicture": profileLink,
        });
        Get.find<StorageServices>().storage.write('profilePicture', profileLink);
        getUserProfile();
        Get.find<UserBottomNavController>().getUserDetails();
        Get.back();
        MessageDialog.showMessageDialog(
          message: AppLocalizations.of(Get.context!)!.profileupdated,
        );
      } else {}
    } on Exception catch (e) {
      log("ERROR (changeAccountProfileImage): ${e.toString()}");
    }
  }

  Future<void> changePassword({required String password, required String oldPassword}) async {
    try {
      Get.back();
      LoadingDialog.showLoadingDialog();
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: userID, password: oldPassword);
      User? user = FirebaseAuth.instance.currentUser;
      await user?.updatePassword(password);
      getUserProfile();
      Get.find<UserBottomNavController>().getUserDetails();
      Get.back();
      MessageDialog.showMessageDialog(
        message: AppLocalizations.of(Get.context!)!.accountpasswordupdated,
      );
    } catch (e) {
      if (e is FirebaseAuthException) {
        Get.back();
        if (e.code == 'invalid-email') {
          Get.snackbar(AppLocalizations.of(Get.context!)!.message, AppLocalizations.of(Get.context!)!.invalidformat, backgroundColor: AppColors.red, colorText: Colors.white);
        } else if (e.code == 'INVALID_LOGIN_CREDENTIALS') {
          Get.snackbar(AppLocalizations.of(Get.context!)!.message, AppLocalizations.of(Get.context!)!.wrongpassword, backgroundColor: AppColors.red, colorText: Colors.white);
        } else if (e.code == 'too-many-requests') {
          Get.snackbar(AppLocalizations.of(Get.context!)!.message, AppLocalizations.of(Get.context!)!.wehaveblockedallrequest,
              backgroundColor: AppColors.red, colorText: Colors.white);
        } else {
          Get.snackbar(AppLocalizations.of(Get.context!)!.message, "${AppLocalizations.of(Get.context!)!.loginfailedwitherror}: ${e.code}",
              backgroundColor: AppColors.red, colorText: Colors.white);
        }
      } else {
        Get.back();
        Get.snackbar(AppLocalizations.of(Get.context!)!.message, AppLocalizations.of(Get.context!)!.loginfailedsomethingwentwrong,
            backgroundColor: AppColors.red, colorText: Colors.white);
        log(e.toString());
      }
    }
  }

  changeAccountName({required String fname, required String lname}) async {
    try {
      Get.back();
      LoadingDialog.showLoadingDialog();
      await FirebaseFirestore.instance.collection('users').doc(userID).update({
        "firstname": fname,
        "lastname": lname,
      });
      await getUserProfile();
      Get.find<UserBottomNavController>().getUserDetails();
      Get.back();
      MessageDialog.showMessageDialog(message: "Account name updated");
    } catch (e) {
      log("ERROR (changeAccountName): ${e.toString()}");
    }
  }

  bool isValidPassword(String input) {
    // Regular expression to check the presence of:
    // - At least one letter (upper or lowercase)
    // - At least one digit
    // - At least one special character from the set of common special characters
    final RegExp hasLetter = RegExp(r'[a-zA-Z]');
    final RegExp hasDigit = RegExp(r'[0-9]');
    final RegExp hasSpecialChar = RegExp(r'[!@#$%^&*(),.?":{}|<>]');

    // Check if the input string satisfies all conditions
    return hasLetter.hasMatch(input) && hasDigit.hasMatch(input) && hasSpecialChar.hasMatch(input);
  }

  getData() async {
    LoadingDialog.showLoadingDialog();
    Future.delayed(const Duration(seconds: 2), () async {
      await getUserProfile();
      Get.back();
    });
  }

  @override
  void onReady() {
    getData();
    super.onReady();
  }
}
