import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sizer/sizer.dart';
import '../../../config/app_colors.dart';
import '../controller/user_and_chatbot_controller.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class UsersAndChatBotView extends GetView<UserAndChatbotController> {
  const UsersAndChatBotView({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(UserAndChatbotController());
    return Scaffold(
      appBar: AppBar(
        leadingWidth: 12.w,
        titleSpacing: 1,
        leading: GestureDetector(
          onTap: () {
            Get.back();
          },
          child: const Icon(Icons.arrow_back),
        ),
        title: const Text("Eventify"),
      ),
      body: SizedBox(
        height: 100.h,
        width: 100.w,
        child: Column(
          children: [
            Expanded(
              child: SizedBox(
                child: Obx(
                  () => ListView.builder(
                    itemCount: controller.chatList.length,
                    shrinkWrap: true,
                    controller: controller.scrollController,
                    padding: const EdgeInsets.only(top: 10, bottom: 10),
                    itemBuilder: (context, index) {
                      return Column(
                        children: [
                          Container(
                              padding: const EdgeInsets.only(
                                left: 14,
                                right: 14,
                                top: 10,
                              ),
                              child: Align(
                                alignment: (controller.chatList[index].sender == "bot" ? Alignment.topLeft : Alignment.topRight),
                                child: Container(
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: (controller.chatList[index].sender == "bot" ? AppColors.darkBlue : AppColors.light),
                                  ),
                                  padding: const EdgeInsets.all(16),
                                  child: Text(
                                    controller.chatList[index].message,
                                    style: TextStyle(
                                      fontSize: 15,
                                      color: (controller.chatList[index].sender == "bot" ? Colors.white : Colors.black),
                                    ),
                                  ),
                                ),
                              )),
                          Padding(
                            padding: EdgeInsets.only(
                              left: 7.w,
                              right: 7.w,
                            ),
                            child: Align(
                                alignment: (controller.chatList[index].sender == "bot" ? Alignment.topLeft : Alignment.topRight),
                                child: Text(
                                  "${DateFormat('yMMMd').format(controller.chatList[index].datecreated)} ${DateFormat('jm').format(controller.chatList[index].datecreated)}",
                                  style: TextStyle(fontWeight: FontWeight.w500, color: Colors.grey, fontSize: 9.sp),
                                )),
                          )
                        ],
                      );
                    },
                  ),
                ),
              ),
            ),
            Container(
              height: 10.h,
              decoration: const BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(color: Colors.grey, blurRadius: 5, spreadRadius: 3, offset: Offset(1, 2))]),
              padding: EdgeInsets.only(bottom: 2.h, left: 3.w, right: 3.w),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 6.h,
                    width: 70.w,
                    child: TextField(
                      style: Theme.of(context).textTheme.bodySmall!.copyWith(fontSize: 11.sp),
                      controller: controller.messageController,
                      decoration: InputDecoration(
                          fillColor: Colors.white,
                          filled: true,
                          contentPadding: EdgeInsets.only(left: 3.w),
                          alignLabelWithHint: false,
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                          hintStyle: Theme.of(context).textTheme.bodySmall!.copyWith(fontSize: 11.sp),
                          hintText: '${AppLocalizations.of(context)!.typesomething}..'),
                    ),
                  ),
                  InkWell(
                      onTap: () async {
                        if (controller.messageController.text.isNotEmpty) {
                          controller.sendMessageToChatBot(query: controller.messageController.text);
                          // controller.sendMessageMethodTwo(query: controller.messageController.text);

                          controller.messageController.clear();
                        }
                      },
                      child: const Icon(Icons.send))
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
