import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/src/admin_home_screen/view/admin_home_view.dart';
import 'package:hotelreservation/src/admin_pending_reservation_screen/view/admin_pending_reservation_view.dart';
import '../../admin_accepted_reservation_screen/view/admin_accepted_reservation_view.dart';
import '../../admin_otherstatus_reservation_screen/view/admin_otherstatus_reservation_view.dart';

class AdminBottomNavController extends GetxController {
  FirebaseMessaging messaging = FirebaseMessaging.instance;

  RxInt currentIndex = 0.obs;
  final List<Widget> body = [
    const AdminHomePage(),
    const AdminPendingReservationPage(),
    const AdminAcceptedReservationPage(),
    const AdminOtherStatusReservationPage(),
  ];

  Future updateFcmToken() async {
    try {
      FirebaseMessaging messaging = FirebaseMessaging.instance;
      String? fcmToken = await messaging.getToken();
      await FirebaseFirestore.instance.collection('admin').doc('EhGuSHlielkjG9Elckwe').update({"fcmToken": fcmToken});
    } catch (e) {
      log("ERROR (updateFcmToken) $e");
    }
  }

  @override
  void onInit() {
    updateFcmToken();
    super.onInit();
  }
}
