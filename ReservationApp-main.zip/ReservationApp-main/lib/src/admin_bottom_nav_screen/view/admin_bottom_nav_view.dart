import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/src/admin_accepted_reservation_screen/controller/admin_accepted_reservation_controller.dart';
import 'package:hotelreservation/src/admin_otherstatus_reservation_screen/controller/admin_otherstatus_reservation_controller.dart';
import 'package:hotelreservation/src/admin_pending_reservation_screen/controller/admin_pending_reservation_controller.dart';
import 'package:sizer/sizer.dart';
import '../../../config/app_colors.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../../admin_home_screen/controller/admin_home_controller.dart';
import '../controller/admin_bottom_nav_controller.dart';

class AdminBottomNavPage extends GetView<AdminBottomNavController> {
  const AdminBottomNavPage({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(AdminBottomNavController());
    Get.put(AdminHomeController());
    Get.put(AdminPendingReservationController());
    Get.put(AdminAcceptedReservationController());
    Get.put(AdminOtherStatusReservationController());
    return Scaffold(
      body: Obx(() => controller.body[controller.currentIndex.value]),
      bottomNavigationBar: SizedBox(
        height: 10.h,
        width: 100.w,
        child: Obx(
          () => BottomNavigationBar(
            selectedItemColor: AppColors.lightBlue,
            unselectedItemColor: AppColors.dark,
            showUnselectedLabels: true,
            type: BottomNavigationBarType.fixed,
            onTap: (index) {
              controller.currentIndex.value = index;
            },
            currentIndex: controller.currentIndex.value,
            items: [
              BottomNavigationBarItem(icon: const Icon(Icons.home), label: AppLocalizations.of(context)!.home, backgroundColor: Theme.of(context).bottomAppBarTheme.color),
              BottomNavigationBarItem(icon: const Icon(Icons.pending), label: AppLocalizations.of(context)!.pending, backgroundColor: Theme.of(context).bottomAppBarTheme.color),
              BottomNavigationBarItem(icon: const Icon(Icons.list), label: AppLocalizations.of(context)!.accepted, backgroundColor: Theme.of(context).bottomAppBarTheme.color),
              BottomNavigationBarItem(icon: const Icon(Icons.history), label: AppLocalizations.of(context)!.others, backgroundColor: Theme.of(context).bottomAppBarTheme.color),
            ],
          ),
        ),
      ),
    );
  }
}
