import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';

import '../../../config/app_colors.dart';
import '../../../services/loading_services.dart';
import '../../admin_bottom_nav_screen/view/admin_bottom_nav_view.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class AdminPassCodeController extends GetxController {
  checkAdminAccount({required String code}) async {
    LoadingDialog.showLoadingDialog();
    try {
      var res = await FirebaseFirestore.instance.collection('admin').where('code', isEqualTo: code).limit(1).get();
      var admin = res.docs;
      Get.back();
      if (admin.isNotEmpty) {
        var admindetails = admin[0].data();
        if (admindetails['active'] == true) {
          Get.offAll(() => const AdminBottomNavPage());
        } else {
          Get.snackbar("Message", AppLocalizations.of(Get.context!)!.thisadminisnotactive,
              duration: const Duration(seconds: 3), backgroundColor: AppColors.lightBlue, colorText: AppColors.light);
        }
      } else {
        Get.snackbar("Message", AppLocalizations.of(Get.context!)!.adminaccountnotfound,
            duration: const Duration(seconds: 3), backgroundColor: AppColors.lightBlue, colorText: AppColors.light);
      }
    } catch (_) {
      Get.back();

      log("ERROR: (checkAdminAccount) Something went wrong $_");
    }
  }
}
