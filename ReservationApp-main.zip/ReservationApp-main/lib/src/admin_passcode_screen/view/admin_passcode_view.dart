import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_otp_text_field/flutter_otp_text_field.dart';
import 'package:sizer/sizer.dart';
import '../../../config/app_colors.dart';
import '../controller/admin_passcode_controller.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class AdminPassCodeView extends GetView<AdminPassCodeController> {
  const AdminPassCodeView({super.key});
// 9199032452
  @override
  Widget build(BuildContext context) {
    Get.put(AdminPassCodeController());
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            AppLocalizations.of(context)!.verificationcode,
            textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 30.sp),
          ),
          SizedBox(
            height: 1.h,
          ),
          Text(
            AppLocalizations.of(context)!.pleasetypethepasscode,
            textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.w400, fontSize: 12.sp),
          ),
          Text(
            AppLocalizations.of(context)!.fortheadminaccount,
            textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.w400, fontSize: 12.sp),
          ),
          SizedBox(
            height: 3.h,
          ),
          Container(
            alignment: Alignment.center,
            child: OtpTextField(
              obscureText: true,
              numberOfFields: 6,
              cursorColor: AppColors.lightBlue,
              borderColor: AppColors.darkBlue,
              disabledBorderColor: Colors.black,
              enabledBorderColor: AppColors.darkBlue,
              fillColor: AppColors.darkBlue,
              showFieldAsBox: true,
              focusedBorderColor: Colors.white,
              onCodeChanged: (String code) {},
              onSubmit: (String verificationCode) async {
                controller.checkAdminAccount(code: verificationCode);
              }, // end onSubmit
            ),
          ),
        ],
      ),
    );
  }
}
