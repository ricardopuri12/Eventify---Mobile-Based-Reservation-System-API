import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
// import 'package:hotelreservation/services/message_dialog.dart';
import 'package:hotelreservation/src/user_home_screen/controller/user_home_controller.dart';
import 'package:sizer/sizer.dart';
import '../../../config/app_colors.dart';
import '../../../services/message_dialog.dart';
import '../../../services/money_formatter.dart';
import '../../user_ratings_and_feedback_screen/view/user_ratings_and_feedback_view.dart';
import 'user_reserved_establishment_view.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class UserEstablishmentDetailsPage extends GetView<UserHomeController> {
  const UserEstablishmentDetailsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Obx(
      () => controller.hasDetails.value == false
          ? SizedBox(
              height: 100.h,
              width: 100.w,
              child: Center(
                child: SpinKitThreeBounce(
                  color: AppColors.darkBlue,
                  size: 35.sp,
                ),
              ),
            )
          : SizedBox(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Stack(
                      children: [
                        CachedNetworkImage(
                          imageUrl: controller.establishmentDetails!.image,
                          imageBuilder: (context, imageProvider) => Container(
                            height: 35.h,
                            width: 100.w,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: imageProvider,
                              ),
                            ),
                          ),
                          placeholder: (context, url) => Container(
                            height: 35.h,
                            width: 100.w,
                            decoration: const BoxDecoration(
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: AssetImage("assets/images/launcher.png"),
                              ),
                            ),
                          ),
                          errorWidget: (context, url, error) => Container(
                            height: 35.h,
                            width: 100.w,
                            decoration: const BoxDecoration(
                              image: DecorationImage(
                                fit: BoxFit.cover,
                                image: AssetImage("assets/images/launcher.png"),
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          top: 5.h,
                          right: 6.w,
                          child: Row(
                            children: [
                              GestureDetector(
                                onTap: () {
                                  if (controller.slotAvailable.value > 0) {
                                    controller.reservationPrice.value = 0.0;
                                    controller.dateFromText.value = '';
                                    controller.timeFromText.value = '';
                                    controller.dateToText.value = '';
                                    controller.timeToText.value = '';
                                    controller.datefrom = null;
                                    controller.dateto = null;
                                    controller.timefrom = null;
                                    controller.timeto = null;
                                    controller.remarks.clear();
                                    controller.paxNumber.text = controller.establishmentDetails!.pax.toString();
                                    Get.to(() => const UserReservationPage());
                                  } else {
                                    MessageDialog.showMessageDialog(
                                      message: AppLocalizations.of(context)!.thisestablishmentiscurrentlynotavailable,
                                    );
                                  }
                                },
                                child: const CircleAvatar(
                                  backgroundColor: AppColors.darkBlue,
                                  child: Icon(
                                    Icons.book,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                              // SizedBox(
                              //   width: 2.w,
                              // ),
                              // GestureDetector(
                              //   onTap: () {},
                              //   child: const CircleAvatar(
                              //     backgroundColor: AppColors.darkBlue,
                              //     child: Icon(
                              //       Icons.delete,
                              //       color: Colors.white,
                              //     ),
                              //   ),
                              // ),
                            ],
                          ),
                        ),
                        Positioned(
                          top: 5.h,
                          left: 6.w,
                          child: GestureDetector(
                            onTap: () {
                              Get.back();
                            },
                            child: const CircleAvatar(
                              backgroundColor: AppColors.darkBlue,
                              child: Icon(
                                Icons.arrow_back,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                    SizedBox(
                      height: 1.h,
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 5.w, right: 5.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            controller.establishmentDetails!.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.labelLarge,
                          ),
                          controller.establishmentDetails!.rating != null
                              ? GestureDetector(
                                  onTap: () {
                                    Get.to(() => const UserRatingAndFeedbackPage(), arguments: {
                                      "establishmentID": controller.establishmentDetails!.id,
                                    });
                                  },
                                  child: SizedBox(
                                    child: Row(
                                      children: [
                                        Text(
                                          controller.establishmentDetails!.rating!.toStringAsFixed(1),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: Theme.of(context).textTheme.labelMedium,
                                        ),
                                        const Icon(
                                          Icons.star,
                                          color: Colors.yellow,
                                        )
                                      ],
                                    ),
                                  ),
                                )
                              : const SizedBox.shrink(),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 5.w, right: 5.w),
                      child: Row(
                        children: [
                          Text(
                            "${AppLocalizations.of(context)!.price}: ${MoneyFormatter.formatMoney(amount: controller.establishmentDetails!.price)}",
                            style: Theme.of(context).textTheme.labelSmall!.copyWith(fontSize: 12.sp),
                          ),
                          Text(
                            " (${controller.establishmentDetails!.category})",
                            style: Theme.of(context).textTheme.labelSmall!.copyWith(color: AppColors.darkBlue, fontSize: 12.sp),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 5.w, right: 5.w),
                      child: Text(
                        "${AppLocalizations.of(context)!.pax}: ${controller.establishmentDetails!.pax}",
                        style: Theme.of(context).textTheme.labelSmall!.copyWith(fontSize: 12.sp),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 5.w, right: 5.w),
                      child: Text(
                        "${AppLocalizations.of(context)!.slot}: ${controller.establishmentDetails!.slot}",
                        style: Theme.of(context).textTheme.labelSmall!.copyWith(fontSize: 12.sp),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 5.w, right: 5.w),
                      child: Obx(
                        () => Text(
                          controller.slotAvailable.value > 0 ? AppLocalizations.of(context)!.available : AppLocalizations.of(context)!.fullybooked,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.labelSmall!.copyWith(color: controller.slotAvailable.value > 0 ? Colors.green : AppColors.red),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 2.h,
                    ),
                    Padding(
                      padding: EdgeInsets.only(left: 5.w, right: 5.w),
                      child: Text(
                        AppLocalizations.of(context)!.language == "English"
                            ? controller.establishmentDetails!.descriptionEnglish
                            : AppLocalizations.of(context)!.language == "French"
                                ? controller.establishmentDetails!.descriptionFrench
                                : controller.establishmentDetails!.descriptionSpanish,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ),
                  ],
                ),
              ),
            ),
    ));
  }
}
