import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/services/message_dialog.dart';
import 'package:hotelreservation/src/user_home_screen/controller/user_home_controller.dart';
import 'package:intl/intl.dart';
import 'package:sizer/sizer.dart';
import '../../../config/app_colors.dart';
import '../../../config/app_fontsizes.dart';
import '../../../services/money_formatter.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../dialog/payment_confirmation_dialog.dart';

class UserReservationPage extends GetView<UserHomeController> {
  const UserReservationPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          AppLocalizations.of(context)!.reservation,
        ),
      ),
      body: SizedBox(
        height: 100.h,
        width: 100.w,
        child: Padding(
          padding: EdgeInsets.only(
            left: 5.w,
            right: 5.w,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 2.h,
              ),
              Text(
                "${AppLocalizations.of(context)!.date} ${AppLocalizations.of(context)!.from}",
                style: Theme.of(context).textTheme.bodySmall,
              ),
              SizedBox(
                height: .5.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 6.h,
                    width: 43.w,
                    child: Container(
                      decoration: BoxDecoration(border: Border.all(), borderRadius: BorderRadius.circular(8)),
                      child: Padding(
                        padding: EdgeInsets.only(left: 3.w, right: 3.w),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Obx(() => Text(
                                    controller.dateFromText.value,
                                    style: Theme.of(context).textTheme.bodySmall!.copyWith(fontSize: 11.sp),
                                  )),
                              GestureDetector(
                                  onTap: () async {
                                    var datepicked =
                                        await showDatePicker(context: context, firstDate: DateTime.now().add(const Duration(days: 2)), lastDate: DateTime(2050, 12, 30));
                                    if (datepicked != null) {
                                      controller.dateFromText.value = DateFormat.yMMMd().format(datepicked);
                                      controller.datefrom = datepicked;
                                      controller.calculatePrice();

                                      // Duration difference = daterangepicked.end.difference(daterangepicked.start);
                                      // int daysBetween = difference.inDays;
                                      // controller.from = daterangepicked.start;
                                      // controller.to = daterangepicked.end;
                                      // if (daysBetween == 0) {
                                      //   controller.reservationPrice.value = controller.establishmentDetails!.price;
                                      // } else {
                                      //   controller.reservationPrice.value = controller.establishmentDetails!.price * daysBetween;
                                      // }
                                      // controller.dateRange.value = "${DateFormat.yMMMMd().format(daterangepicked.start)} - ${DateFormat.yMMMMd().format(daterangepicked.end)}";
                                    }
                                  },
                                  child: Icon(
                                    Icons.calendar_month,
                                    size: 23.sp,
                                  )),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 6.h,
                    width: 43.w,
                    child: Container(
                      decoration: BoxDecoration(border: Border.all(), borderRadius: BorderRadius.circular(8)),
                      child: Padding(
                        padding: EdgeInsets.only(left: 3.w, right: 3.w),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Obx(() => Text(
                                    controller.timeFromText.value,
                                    style: Theme.of(context).textTheme.bodySmall!.copyWith(fontSize: 11.sp),
                                  )),
                              GestureDetector(
                                  onTap: () async {
                                    DateTime dateselected = controller.datefrom != null ? controller.datefrom! : DateTime.now();
                                    var timepicked = await showTimePicker(context: context, initialTime: TimeOfDay.now());
                                    if (timepicked != null) {
                                      controller.timeFromText.value =
                                          DateFormat.jm().format(DateTime(dateselected.year, dateselected.month, dateselected.day, timepicked.hour, timepicked.minute));
                                      controller.timefrom = DateTime(dateselected.year, dateselected.month, dateselected.day, timepicked.hour, timepicked.minute);
                                      controller.calculatePrice();

                                      // Duration difference = daterangepicked.end.difference(daterangepicked.start);
                                      // int daysBetween = difference.inDays;
                                      // controller.from = daterangepicked.start;
                                      // controller.to = daterangepicked.end;
                                      // if (daysBetween == 0) {
                                      //   controller.reservationPrice.value = controller.establishmentDetails!.price;
                                      // } else {
                                      //   controller.reservationPrice.value = controller.establishmentDetails!.price * daysBetween;
                                      // }
                                      // controller.dateRange.value = "${DateFormat.yMMMMd().format(daterangepicked.start)} - ${DateFormat.yMMMMd().format(daterangepicked.end)}";
                                    }
                                  },
                                  child: Icon(
                                    Icons.alarm,
                                    size: 23.sp,
                                  )),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 2.h,
              ),
              Text(
                "${AppLocalizations.of(context)!.date} ${AppLocalizations.of(context)!.to}",
                style: Theme.of(context).textTheme.bodySmall,
              ),
              SizedBox(
                height: .5.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    height: 6.h,
                    width: 43.w,
                    child: Container(
                      decoration: BoxDecoration(border: Border.all(), borderRadius: BorderRadius.circular(8)),
                      child: Padding(
                        padding: EdgeInsets.only(left: 3.w, right: 3.w),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Obx(() => Text(
                                    controller.dateToText.value,
                                    style: Theme.of(context).textTheme.bodySmall!.copyWith(fontSize: 11.sp),
                                  )),
                              GestureDetector(
                                  onTap: () async {
                                    var datepicked = await showDatePicker(
                                        context: context,
                                        firstDate: controller.datefrom != null ? controller.datefrom!.add(const Duration(days: 1)) : DateTime.now().add(const Duration(days: 2)),
                                        lastDate: DateTime(2050, 12, 30));
                                    if (datepicked != null) {
                                      controller.dateToText.value = DateFormat.yMMMd().format(datepicked);
                                      controller.dateto = datepicked;
                                      controller.calculatePrice();
                                      // Duration difference = daterangepicked.end.difference(daterangepicked.start);
                                      // int daysBetween = difference.inDays;
                                      // controller.from = daterangepicked.start;
                                      // controller.to = daterangepicked.end;
                                      // if (daysBetween == 0) {
                                      //   controller.reservationPrice.value = controller.establishmentDetails!.price;
                                      // } else {
                                      //   controller.reservationPrice.value = controller.establishmentDetails!.price * daysBetween;
                                      // }
                                      // controller.dateRange.value = "${DateFormat.yMMMMd().format(daterangepicked.start)} - ${DateFormat.yMMMMd().format(daterangepicked.end)}";
                                    }
                                  },
                                  child: Icon(
                                    Icons.calendar_month,
                                    size: 23.sp,
                                  )),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 6.h,
                    width: 43.w,
                    child: Container(
                      decoration: BoxDecoration(border: Border.all(), borderRadius: BorderRadius.circular(8)),
                      child: Padding(
                        padding: EdgeInsets.only(left: 3.w, right: 3.w),
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Obx(() => Text(
                                    controller.timeToText.value,
                                    style: Theme.of(context).textTheme.bodySmall!.copyWith(fontSize: 11.sp),
                                  )),
                              GestureDetector(
                                  onTap: () async {
                                    var timepicked = await showTimePicker(context: context, initialTime: TimeOfDay.now());
                                    if (timepicked != null) {
                                      controller.timeToText.value = DateFormat.jm().format(DateTime(2050, 1, 1, timepicked.hour, timepicked.minute));
                                      controller.timeto = DateTime(2050, 1, 1, timepicked.hour, timepicked.minute);
                                      controller.calculatePrice();

                                      // Duration difference = daterangepicked.end.difference(daterangepicked.start);
                                      // int daysBetween = difference.inDays;
                                      // controller.from = daterangepicked.start;
                                      // controller.to = daterangepicked.end;
                                      // if (daysBetween == 0) {
                                      //   controller.reservationPrice.value = controller.establishmentDetails!.price;
                                      // } else {
                                      //   controller.reservationPrice.value = controller.establishmentDetails!.price * daysBetween;
                                      // }
                                      // controller.dateRange.value = "${DateFormat.yMMMMd().format(daterangepicked.start)} - ${DateFormat.yMMMMd().format(daterangepicked.end)}";
                                    }
                                  },
                                  child: Icon(
                                    Icons.alarm,
                                    size: 23.sp,
                                  )),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 2.h,
              ),
              Text(
                AppLocalizations.of(context)!.price,
                style: Theme.of(context).textTheme.bodySmall,
              ),
              SizedBox(
                height: .5.h,
              ),
              SizedBox(
                height: 6.h,
                width: 100.w,
                child: Container(
                  decoration: BoxDecoration(border: Border.all(), borderRadius: BorderRadius.circular(8)),
                  child: Padding(
                    padding: EdgeInsets.only(left: 3.w),
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: Obx(() => Text(MoneyFormatter.formatMoney(amount: controller.reservationPrice.value))),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Text(
                AppLocalizations.of(context)!.contactno,
                style: Theme.of(context).textTheme.bodySmall,
              ),
              SizedBox(
                height: 7.h,
                width: 100.w,
                child: Center(
                  child: TextField(
                    controller: controller.contactno,
                    style: Theme.of(context).textTheme.bodySmall!.copyWith(fontSize: 11.sp),
                    keyboardType: TextInputType.number,
                    onChanged: (value) {
                      if (controller.contactno.text.isEmpty) {
                      } else {
                        if (controller.contactno.text[0] != "9" || controller.contactno.text.length > 10) {
                          controller.contactno.clear();
                        } else {}
                      }
                    },
                    decoration: InputDecoration(
                      contentPadding: EdgeInsets.only(left: 3.w),
                      alignLabelWithHint: false,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      hintStyle: Theme.of(context).textTheme.bodySmall!.copyWith(fontSize: 11.sp),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 1.h,
              ),
              Text(
                AppLocalizations.of(context)!.pax,
                style: Theme.of(context).textTheme.bodySmall,
              ),
              SizedBox(
                height: 7.h,
                width: 100.w,
                child: Center(
                  child: TextField(
                    controller: controller.paxNumber,
                    style: Theme.of(context).textTheme.bodySmall!.copyWith(fontSize: 11.sp),
                    keyboardType: TextInputType.number,
                    onChanged: (value) {
                      if (controller.paxNumber.text.isEmpty) {
                      } else {
                        if (int.parse(controller.paxNumber.text) > controller.establishmentDetails!.pax) {
                          controller.paxNumber.clear();
                          MessageDialog.showMessageDialog(message: AppLocalizations.of(context)!.paxmessagewarning);
                        } else if (int.parse(controller.paxNumber.text) == 0) {
                          controller.paxNumber.text = controller.establishmentDetails!.pax.toString();
                        }
                      }
                    },
                    decoration: InputDecoration(
                      contentPadding: EdgeInsets.only(left: 3.w),
                      alignLabelWithHint: false,
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                      hintStyle: Theme.of(context).textTheme.bodySmall!.copyWith(fontSize: 11.sp),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 1.h,
              ),
              Text(
                AppLocalizations.of(context)!.remarks,
                style: Theme.of(context).textTheme.bodySmall,
              ),
              SizedBox(
                height: .5.h,
              ),
              SizedBox(
                height: 12.h,
                width: 100.w,
                child: TextField(
                  controller: controller.remarks,
                  maxLines: 5,
                  style: TextStyle(fontSize: AppFontSizes.regular),
                  decoration: InputDecoration(
                    filled: true,
                    contentPadding: EdgeInsets.only(left: 3.w, top: 2.h),
                    alignLabelWithHint: false,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    hintStyle: Theme.of(context).textTheme.bodySmall,
                  ),
                ),
              ),
              const Expanded(
                child: SizedBox(),
              ),
              SizedBox(
                width: 100.w,
                height: 7.h,
                child: ElevatedButton(
                  style: ButtonStyle(
                      foregroundColor: MaterialStateProperty.all<Color>(AppColors.lightBlue),
                      backgroundColor: MaterialStateProperty.all<Color>(AppColors.lightBlue),
                      shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                          RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0), side: const BorderSide(color: AppColors.light)))),
                  onPressed: () async {
                    if (controller.datefrom == null && controller.dateto == null && controller.timefrom == null && controller.timeto == null) {
                      Get.snackbar(AppLocalizations.of(context)!.message, AppLocalizations.of(context)!.pleaseprovide, backgroundColor: Colors.red, colorText: Colors.white);
                    } else if (controller.reservationPrice.value == 0) {
                      Get.snackbar(AppLocalizations.of(context)!.message, AppLocalizations.of(context)!.invalidamount, backgroundColor: AppColors.red, colorText: Colors.white);
                    } else if (controller.contactno.text.length != 10 || controller.contactno.text.isEmpty) {
                      Get.snackbar(AppLocalizations.of(context)!.message, AppLocalizations.of(context)!.invalidcontactno,
                          backgroundColor: AppColors.red, colorText: AppColors.light);
                    } else {
                      var isAvailable = await controller.checkingAvailability();
                      if (isAvailable) {
                        controller.acceptTermsAndConditions.value = false;
                        PaymentConfirmationDialog.showPaymentConfirmation();
                      } else {
                        MessageDialog.showMessageDialog(message: AppLocalizations.of(Get.context!)!.theunitisnotavailable);
                      }
                    }
                  },
                  child: Text(AppLocalizations.of(context)!.submit, style: TextStyle(fontSize: AppFontSizes.regular, color: Colors.white)),
                ),
              ),
              SizedBox(
                height: 4.h,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
