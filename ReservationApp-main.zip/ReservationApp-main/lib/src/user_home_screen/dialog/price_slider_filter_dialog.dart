import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../../config/app_colors.dart';
import '../../../config/app_fontsizes.dart';
import '../controller/user_home_controller.dart';

class PriceFilterSlider {
  static showPriceFilterSlider() {
    var controller = Get.find<UserHomeController>();
    RxDouble sliderResult = controller.maxPrice.value.obs;
    Get.dialog(AlertDialog(
      content: SizedBox(
        width: 40.h,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                AppLocalizations.of(Get.context!)!.price,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: AppFontSizes.large,
                ),
              ),
              SizedBox(height: 1.h),
              Obx(
                () => Text(
                  sliderResult.toStringAsFixed(0),
                  style: TextStyle(
                    fontWeight: FontWeight.normal,
                    fontSize: AppFontSizes.small,
                  ),
                ),
              ),
              Obx(
                () => Slider(
                  thumbColor: AppColors.darkBlue,
                  activeColor: AppColors.darkBlue,
                  value: sliderResult.value,
                  min: controller.minPrice.value,
                  max: controller.maxPrice.value,
                  onChanged: (double value) {
                    sliderResult.value = value;
                  },
                ),
              ),
              SizedBox(
                height: 1.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: 30.w,
                    height: 6.h,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: AppColors.black, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(8)))),
                      onPressed: () {
                        Get.back();
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.arrow_back,
                            color: Colors.white,
                          ),
                          SizedBox(
                            width: 1.w,
                          ),
                          Text(
                            AppLocalizations.of(Get.context!)!.back,
                            style: TextStyle(fontWeight: FontWeight.normal, fontSize: AppFontSizes.small, color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 30.w,
                    height: 6.h,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.lightBlue,
                        shape: const RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(
                            Radius.circular(8),
                          ),
                        ),
                      ),
                      onPressed: () async {
                        controller.selectedPrice.value = sliderResult.value;
                        controller.filterPrice(price: sliderResult.value);
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.done,
                            color: Colors.white,
                          ),
                          SizedBox(
                            width: 1.w,
                          ),
                          Text(
                            AppLocalizations.of(Get.context!)!.confirm,
                            style: TextStyle(fontWeight: FontWeight.normal, fontSize: AppFontSizes.small, color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    ));
  }
}
