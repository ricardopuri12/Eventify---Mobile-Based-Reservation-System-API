import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../../config/app_colors.dart';
import '../../../config/app_fontsizes.dart';
import '../../../services/constant_string.dart';
import '../controller/user_home_controller.dart';

class PaymentConfirmationDialog {
  static showPaymentConfirmation() {
    var controller = Get.find<UserHomeController>();
    Get.dialog(AlertDialog(
      content: SizedBox(
        width: 40.h,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                AppLocalizations.of(Get.context!)!.termsAndCondition,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: AppFontSizes.large,
                ),
              ),
              SizedBox(height: 1.h),
              Text(
                AppLocalizations.of(Get.context!)!.language == "English"
                    ? ConstantString.termsAndConditionsEnglish
                    : AppLocalizations.of(Get.context!)!.language == "French"
                        ? ConstantString.termsAndConditionsFrench
                        : ConstantString.termsAndConditionsSpanish,
                style: TextStyle(
                  fontWeight: FontWeight.normal,
                  fontSize: AppFontSizes.small,
                ),
              ),
              SizedBox(height: 1.h),
              Text(
                AppLocalizations.of(Get.context!)!.confirmreservationpayment,
                style: TextStyle(
                  fontWeight: FontWeight.normal,
                  fontSize: AppFontSizes.small,
                ),
              ),
              SizedBox(
                height: 1.h,
              ),
              Row(
                children: [
                  Obx(
                    () => Checkbox(
                        activeColor: AppColors.darkBlue,
                        value: controller.acceptTermsAndConditions.value,
                        onChanged: (value) {
                          controller.acceptTermsAndConditions.value = value!;
                        }),
                  ),
                  SizedBox(
                    width: 1.w,
                  ),
                  Text(
                    "${AppLocalizations.of(Get.context!)!.accept} ${AppLocalizations.of(Get.context!)!.termsAndCondition}",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: AppFontSizes.small,
                    ),
                  ),
                ],
              ),
              SizedBox(
                height: 1.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: 30.w,
                    height: 6.h,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: AppColors.black, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(8)))),
                      onPressed: () {
                        Get.back();
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.arrow_back,
                            color: Colors.white,
                          ),
                          SizedBox(
                            width: 1.w,
                          ),
                          Text(
                            AppLocalizations.of(Get.context!)!.back,
                            style: TextStyle(fontWeight: FontWeight.normal, fontSize: AppFontSizes.small, color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 30.w,
                    height: 6.h,
                    child: Obx(
                      () => ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: controller.acceptTermsAndConditions.value ? AppColors.lightBlue : AppColors.black,
                          shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(
                              Radius.circular(8),
                            ),
                          ),
                        ),
                        onPressed: () async {
                          if (controller.acceptTermsAndConditions.value) {
                            Get.back();
                            String amountString = (controller.reservationPrice.value * .30).toStringAsFixed(2);
                            controller.makePayment(amount: amountString.toString(), currency: "PHP");
                          }
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(
                              Icons.payment,
                              color: Colors.white,
                            ),
                            SizedBox(
                              width: 1.w,
                            ),
                            Text(
                              AppLocalizations.of(Get.context!)!.confirm,
                              style: TextStyle(fontWeight: FontWeight.normal, fontSize: AppFontSizes.small, color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    ));
  }
}
