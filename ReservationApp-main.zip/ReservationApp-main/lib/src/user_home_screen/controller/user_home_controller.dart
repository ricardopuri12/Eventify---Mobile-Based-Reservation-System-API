import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/services/default_image.dart';
import 'package:hotelreservation/services/getstorage_services.dart';
import 'package:hotelreservation/services/loading_services.dart';
import 'package:hotelreservation/services/message_dialog.dart';
import '../../../model/establishments_model.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:http/http.dart' as http;

class UserHomeController extends GetxController {
  TextEditingController search = TextEditingController();
  TextEditingController remarks = TextEditingController();
  TextEditingController contactno = TextEditingController();
  TextEditingController paxNumber = TextEditingController();
  RxBool acceptTermsAndConditions = false.obs;

  RxDouble maxPrice = 0.0.obs;
  RxDouble minPrice = 0.0.obs;
  RxDouble selectedPrice = 0.0.obs;

  RxInt slotAvailable = 0.obs;

  DateTime? datefrom;
  DateTime? dateto;
  DateTime? timefrom;
  DateTime? timeto;

  RxDouble reservationPrice = 0.0.obs;
  RxString dateFromText = ''.obs;
  RxString timeFromText = ''.obs;
  RxString dateToText = ''.obs;
  RxString timeToText = ''.obs;

  Timer? debounce;
  RxList<Establishments> establishmentsList = <Establishments>[].obs;
  RxList<Establishments> establishmentsMasterList = <Establishments>[].obs;

  RxBool hasDetails = false.obs;
  Establishments? establishmentDetails;

  RxString categoryFilterValue = 'All'.obs;
  RxList<String> categoryFilterList = [
    'All',
    'Hotel',
    'Villa',
    'Resort',
  ].obs;

  RxString clientSecret = ''.obs;
  Map<String, dynamic>? paymentIntentData;

  RxString filePath = ''.obs;
  RxString fileName = ''.obs;
  RxString establishmentImage = DefaultImage.defaultStoreLogo.obs;
  File? imageFile;

  StreamSubscription<dynamic>? establishmentListener;

  String userID = Get.find<StorageServices>().storage.read('email').toString();
  String userName = "${Get.find<StorageServices>().storage.read('firstname')} ${Get.find<StorageServices>().storage.read('lastname')}";
  String userImage = Get.find<StorageServices>().storage.read('profilePicture').toString();

  getEstablishment() async {
    try {
      establishmentListener = FirebaseFirestore.instance.collection('establishments').orderBy('datecreated', descending: true).snapshots().listen((event) async {
        var establishments = event.docs;
        List tempList = [];
        for (var i = 0; i < establishments.length; i++) {
          Map mapdata = establishments[i].data();
          mapdata['id'] = establishments[i].id;
          mapdata['datecreated'] = mapdata['datecreated'].toDate().toString();
          var ratingres = await FirebaseFirestore.instance.collection('establishments').doc(establishments[i].id).collection('ratings').get();
          if (ratingres.docs.isNotEmpty) {
            double totalrating = 0.0;
            for (var i = 0; i < ratingres.docs.length; i++) {
              totalrating = totalrating + ratingres.docs[0]['rating'];
            }
            double averageRating = totalrating / ratingres.docs.length;
            mapdata['rating'] = averageRating;
          }
          tempList.add(mapdata);
        }
        establishmentsList.assignAll(establishmentsFromJson(jsonEncode(tempList)));
        establishmentsMasterList.assignAll(establishmentsFromJson(jsonEncode(tempList)));
        RxList<Establishments> priceList = <Establishments>[].obs;
        priceList.assignAll(establishmentsFromJson(jsonEncode(tempList)));
        priceList.sort((a, b) => b.price.compareTo(a.price));
        if (priceList.isNotEmpty) {
          maxPrice.value = priceList.first.price;
          minPrice.value = priceList.last.price;
          selectedPrice.value = priceList.first.price;
        }
        if (establishmentDetails != null) {
          hasDetails.value = false;
          for (var i = 0; i < establishmentsMasterList.length; i++) {
            if (establishmentsMasterList[i].id == establishmentDetails!.id) {
              establishmentDetails = establishmentsMasterList[i];
              slotAvailable.value = establishmentsMasterList[i].slot;
            }
          }
          hasDetails.value = true;
        }
      });
    } catch (e) {
      log("ERROR (getEstablishment) $e");
    }
  }

  searchEstablishment() async {
    establishmentsList.clear();

    log((search.text.isEmpty && categoryFilterValue.value.trim().toString() != "All").toString());
    for (var i = 0; i < establishmentsMasterList.length; i++) {
      if (search.text.isNotEmpty && categoryFilterValue.value != "All") {
        log("3");
        if (establishmentsMasterList[i].name.toLowerCase().toString().contains(search.text.toLowerCase().toString()) &&
            establishmentsMasterList[i].category == categoryFilterValue.value) {
          establishmentsList.add(establishmentsMasterList[i]);
        }
      }
      if (search.text.isNotEmpty && categoryFilterValue.value == "All") {
        log("2");
        if (establishmentsMasterList[i].name.toLowerCase().toString().contains(search.text.toLowerCase().toString())) {
          establishmentsList.add(establishmentsMasterList[i]);
        }
      }
      if (search.text.isEmpty && categoryFilterValue.value != "All") {
        log("1");
        if (establishmentsMasterList[i].category == categoryFilterValue.value) {
          establishmentsList.add(establishmentsMasterList[i]);
        }
      }
    }

    if (search.text.isEmpty && categoryFilterValue.value == "All") {
      establishmentsList.assignAll(establishmentsMasterList);
    }
  }

  filterPrice({required double price}) async {
    RxList<Establishments> partialList = <Establishments>[].obs;
    for (var i = 0; i < establishmentsMasterList.length; i++) {
      if (establishmentsMasterList[i].price <= price) {
        partialList.add(establishmentsMasterList[i]);
      }
    }
    establishmentsList.assignAll(partialList);
    Get.back();
  }

  reservedEstablishment() async {
    try {
      DateTime datetimeToFinal = DateTime(dateto!.year, dateto!.month, dateto!.day, timeto!.hour, timeto!.minute);
      DateTime datetimeFromFinal = DateTime(datefrom!.year, datefrom!.month, datefrom!.day, timefrom!.hour, timefrom!.minute);
      var reservationDoc = FirebaseFirestore.instance.collection('reservation').doc();
      await reservationDoc.set({
        "userID": userID,
        "from": datetimeFromFinal,
        "to": datetimeToFinal,
        "establishmentImage": establishmentDetails!.image,
        "establishmentName": establishmentDetails!.name,
        "establishmentPrice": establishmentDetails!.price,
        "establishmentID": establishmentDetails!.id,
        "establishmentSlot": establishmentDetails!.slot,
        "establishmentPax": establishmentDetails!.pax,
        "establishmentDescriptionEnglish": establishmentDetails!.descriptionEnglish,
        "establishmentDescriptionFrench": establishmentDetails!.descriptionFrench,
        "establishmentDescriptionSpanish": establishmentDetails!.descriptionSpanish,
        "establishmentCategory": establishmentDetails!.category,
        "reservationDownpayment": (reservationPrice.value * .30),
        "reservationPrice": reservationPrice.value,
        "customerPax": paxNumber.text.isEmpty ? establishmentDetails!.pax : int.parse(paxNumber.text),
        "reservationID": reservationDoc.id,
        "userName": userName,
        "userImage": userImage,
        "datecreated": DateTime.now(),
        "status": "Pending",
        "paymentStatus": "Down Payment",
        "remarks": remarks.text,
        "contactno": contactno.text,
      });
      Get.back();
      Get.back();
      Get.back();
      MessageDialog.showMessageDialog(
        message: AppLocalizations.of(Get.context!)!.thankyouforyourreservation,
      );
    } catch (e) {
      log("ERROR (reservedEstablishment) $e");
    }
  }

  calculatePrice() {
    if (datefrom != null && dateto != null && timefrom != null && timeto != null) {
      DateTime datetimeToFinal = DateTime(dateto!.year, dateto!.month, dateto!.day, timeto!.hour, timeto!.minute);
      DateTime datetimeFromFinal = DateTime(datefrom!.year, datefrom!.month, datefrom!.day, timefrom!.hour, timefrom!.minute);
      Duration difference = datetimeToFinal.difference(datetimeFromFinal);
      int daysBetween = difference.inDays;

      if (daysBetween == 0) {
        reservationPrice.value = establishmentDetails!.price;
      } else {
        reservationPrice.value = establishmentDetails!.price * daysBetween;
      }
    }
  }

  iniData() async {
    LoadingDialog.showLoadingDialog();
    RxString selectedLanguage = Get.find<StorageServices>().storage.read('language') == null ? "en".obs : Get.find<StorageServices>().storage.read('language').toString().obs;
    var locale = Locale(selectedLanguage.value);
    Get.updateLocale(locale);
    await getEstablishment();
    Future.delayed(const Duration(seconds: 1), () {
      Get.back();
    });
  }

  Future<bool> checkingAvailability() async {
    LoadingDialog.showLoadingDialog();
    try {
      bool isAvailable = true;
      DateTime datetimeToFinal = DateTime(dateto!.year, dateto!.month, dateto!.day, timeto!.hour, timeto!.minute);
      DateTime datetimeFromFinal = DateTime(datefrom!.year, datefrom!.month, datefrom!.day, timefrom!.hour, timefrom!.minute);
      var res = await FirebaseFirestore.instance
          .collection('reservation')
          .where('establishmentID', isEqualTo: establishmentDetails!.id)
          .where('status', whereIn: ['Pending', 'Accepted']).get();
      var reservations = res.docs;
      for (var i = 0; i < reservations.length; i++) {
        Map mapdata = reservations[i].data();
        DateTime dateFrom = DateTime.parse(mapdata['from'].toDate().toString());
        DateTime dateTo = DateTime.parse(mapdata['to'].toDate().toString());
        if (datetimeFromFinal.isAfter(dateFrom) && datetimeFromFinal.isBefore(dateTo)) {
          isAvailable = false;
        }
        if (datetimeToFinal.isAfter(dateFrom) && datetimeToFinal.isBefore(dateTo)) {
          isAvailable = false;
        }
      }
      Get.back();
      return isAvailable;
    } catch (e) {
      log('ERROR (checkingAvailability) $e');
      Get.back();
      return false;
    }
  }

  Future<void> makePayment({required String amount, required String currency}) async {
    try {
      paymentIntentData = await createPaymentIntent(amount, currency);
      clientSecret.value = paymentIntentData!['client_secret'].toString();
      log("CLIENT SECRET ${clientSecret.value}");
      if (paymentIntentData != null) {
        log(amount);
        log(currency);
        await Stripe.instance.initPaymentSheet(
            paymentSheetParameters: SetupPaymentSheetParameters(
          billingDetails: const BillingDetails(
            address: Address(
              city: "",
              line1: "",
              line2: "",
              postalCode: "",
              state: "PH",
              country: 'PH', // Set default country (ISO country code)
            ),
          ),
          // applePay: PaymentSheetApplePay(merchantCountryCode: currency),
          googlePay: const PaymentSheetGooglePay(merchantCountryCode: "PHP"),
          customerId: "${Get.find<StorageServices>().storage.read('email')}-${DateTime.now().millisecondsSinceEpoch.toString()}",
          merchantDisplayName: 'Prospects',
          // customerId: Get.find<StorageServices>().storage.read('id'),
          // sk_test_51Lize7DbhTM8s4NtDpmRR7iPcppW41EG2AYCHLmJjopgdCnUUP85FQVvmEt98rCnpnr59xQd6zOP7D4kfkMDXqKM00ejfzOuph
          paymentIntentClientSecret: paymentIntentData!['client_secret'],
          customerEphemeralKeySecret: paymentIntentData!['ephemeralKey'],
        ));
        displayPaymentSheet();
      }
    } catch (e, s) {
      log('exception:$e$s');
    }
  }

  displayPaymentSheet() async {
    try {
      LoadingDialog.showLoadingDialog();
      await Stripe.instance.presentPaymentSheet();
      reservedEstablishment();
    } on Exception catch (e) {
      if (e is StripeException) {
        Get.back();
        Get.back();
        log("Error from Stripe: ${e.error.localizedMessage}");
      } else {
        Get.back();
        Get.back();
        log("Unforeseen error: $e");
      }
    } catch (e) {
      Get.back();
      Get.back();
      log("exception:$e");
    }
  }

  createPaymentIntent(String amount, String currency) async {
    var amountString = double.parse(amount).toInt();
    try {
      Map<String, dynamic> body = {'amount': calculateAmount(amountString.toString()), 'currency': currency, 'payment_method_types[]': 'card'};
      var response = await http.post(Uri.parse('https://api.stripe.com/v1/payment_intents'), body: body, headers: {
        'Authorization': 'Bearer sk_test_51QOvqZFNGDv7UO58k875n1eR9WpJaT3t8W0OZo8uS7fM25h0xcUhu3EJfysVzjd5uOvcu4K3Zi5veBCfShxV628F00jhzuhMZH',
        'Content-Type': 'application/x-www-form-urlencoded'
      });
      // log(jsonDecode(response.body)['clientSecret']);
      return jsonDecode(response.body);
    } catch (err) {
      log('err charging user: ${err.toString()}');
    }
  }

  calculateAmount(String amount) {
    final a = (int.parse(amount)) * 100;
    return a.toString();
  }

  @override
  void onReady() {
    iniData();
    super.onReady();
  }

  @override
  void onClose() {
    if (establishmentListener != null) {
      establishmentListener!.cancel();
    }
    super.onClose();
  }
}
