// import 'package:cached_network_image/cached_network_image.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:sizer/sizer.dart';

import '../../../config/app_colors.dart';
import '../../../config/app_fontsizes.dart';
import '../controller/user_ratings_and_feedback_controller.dart';

class UserRatingAndFeedbackPage extends GetView<UserRatingAndFeedbackController> {
  const UserRatingAndFeedbackPage({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(UserRatingAndFeedbackController());
    return Scaffold(
        body: SafeArea(
            child: SizedBox(
      height: 100.h,
      width: 100.w,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            height: 2.h,
          ),
          Padding(
            padding: EdgeInsets.only(left: 5.w, right: 5.w),
            child: Text(
              "Ratings & Feedback",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: AppFontSizes.extraLarge),
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 5.w, right: 5.w),
            child: Row(
              children: [
                Text(
                  "Ratings count ",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: AppFontSizes.regular),
                ),
                Obx(
                  () => Text(
                    controller.ratingCount.value,
                    style: TextStyle(color: AppColors.darkBlue, fontWeight: FontWeight.bold, fontSize: AppFontSizes.regular),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 5.w, right: 5.w),
            child: Row(
              children: [
                Text(
                  "Average ",
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: AppFontSizes.regular),
                ),
                Obx(
                  () => Text(
                    controller.ratingsAverage.value,
                    style: TextStyle(color: AppColors.darkBlue, fontWeight: FontWeight.bold, fontSize: AppFontSizes.regular),
                  ),
                ),
                Icon(
                  Icons.star,
                  color: Colors.yellow,
                  size: 15.sp,
                )
              ],
            ),
          ),
          SizedBox(
            height: 2.h,
          ),
          const Divider(),
          Expanded(
            child: Obx(
              () => controller.ratingAndFeedbackList.isEmpty
                  ? const SizedBox(
                      child: Center(
                        child: Text("No feedbacks & rating available."),
                      ),
                    )
                  : ListView.builder(
                      itemCount: controller.ratingAndFeedbackList.length,
                      itemBuilder: (BuildContext context, int index) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 2.h,
                            ),
                            Padding(
                              padding: EdgeInsets.only(left: 5.w, right: 5.w),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      CachedNetworkImage(
                                        imageUrl: controller.ratingAndFeedbackList[index].profilePicture,
                                        imageBuilder: (context, imageProvider) => CircleAvatar(
                                          radius: 6.5.w,
                                          backgroundColor: AppColors.dark,
                                          child: CircleAvatar(
                                            radius: 6.w,
                                            backgroundImage: imageProvider,
                                          ),
                                        ),
                                        placeholder: (context, url) => CircleAvatar(
                                          radius: 6.5.w,
                                          backgroundColor: AppColors.dark,
                                          child: CircleAvatar(
                                            radius: 6.w,
                                            backgroundColor: AppColors.light,
                                          ),
                                        ),
                                        errorWidget: (context, url, error) => CircleAvatar(
                                          radius: 6.5.w,
                                          backgroundColor: AppColors.dark,
                                          child: CircleAvatar(
                                            radius: 6.w,
                                            backgroundColor: AppColors.light,
                                          ),
                                        ),
                                      ),
                                      SizedBox(
                                        width: 2.w,
                                      ),
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "${controller.ratingAndFeedbackList[index].firstname} ${controller.ratingAndFeedbackList[index].lastname}",
                                            style: TextStyle(
                                              fontWeight: FontWeight.bold,
                                              fontSize: AppFontSizes.regular,
                                            ),
                                          ),
                                          Text(
                                            "${DateFormat.yMMMd().format(controller.ratingAndFeedbackList[index].datecreated)} ${DateFormat.jm().format(controller.ratingAndFeedbackList[index].datecreated)}",
                                            style: TextStyle(
                                              fontWeight: FontWeight.normal,
                                              fontSize: AppFontSizes.small,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Text(
                                        controller.ratingAndFeedbackList[index].rating.toString(),
                                        style: TextStyle(fontWeight: FontWeight.normal, fontSize: AppFontSizes.regular),
                                      ),
                                      Icon(
                                        Icons.star,
                                        color: Colors.yellow,
                                        size: 17.sp,
                                      ),
                                    ],
                                  )
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 1.h,
                            ),
                            Padding(
                              padding: EdgeInsets.only(left: 20.w, right: 5.w),
                              child: Text(
                                controller.ratingAndFeedbackList[index].feedback,
                                style: TextStyle(fontWeight: FontWeight.normal, fontSize: AppFontSizes.regular),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
            ),
          ),
        ],
      ),
    )));
  }
}
