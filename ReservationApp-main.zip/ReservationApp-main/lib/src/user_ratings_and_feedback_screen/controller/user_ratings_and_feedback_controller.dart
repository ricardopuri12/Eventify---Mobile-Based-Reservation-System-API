import 'dart:convert';
import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';

import '../../../model/rating_and_feedback_model.dart';

class UserRatingAndFeedbackController extends GetxController {
  RxString establishmentID = ''.obs;
  RxString ratingsAverage = ''.obs;
  RxString ratingCount = ''.obs;
  RxBool isReplying = false.obs;
  RxString ratingAndFeedbackID = ''.obs;

  RxList<RatingAndFeedback> ratingAndFeedbackList = <RatingAndFeedback>[].obs;
  getRatingsAndFeedback() async {
    try {
      var res = await FirebaseFirestore.instance.collection('establishments').doc(establishmentID.value).collection('ratings').get();
      var ratingsAndFeedbacks = res.docs;
      List data = [];
      for (var i = 0; i < ratingsAndFeedbacks.length; i++) {
        Map mapdata = ratingsAndFeedbacks[i].data();
        mapdata['id'] = ratingsAndFeedbacks[i].id;
        mapdata['datecreated'] = ratingsAndFeedbacks[i]['datecreated'].toDate().toString();
        data.add(mapdata);
      }
      // log(jsonEncode(data));
      ratingAndFeedbackList.assignAll(ratingAndFeedbackFromJson(jsonEncode(data)));
      ratingCount.value = ratingAndFeedbackList.length.toString();
      if (ratingAndFeedbackList.isNotEmpty) {
        double total = 0.0;
        for (var i = 0; i < ratingAndFeedbackList.length; i++) {
          total = total + double.parse(ratingAndFeedbackList[i].rating.toString());
        }
        ratingsAverage.value = (total / ratingAndFeedbackList.length).toStringAsFixed(1);
      } else {
        ratingsAverage.value = 0.0.toStringAsFixed(1);
      }
    } catch (_) {
      log("ERROR: (getRatingsAndFeedback) Something went wrong $_");
    }
  }

  @override
  void onInit() async {
    establishmentID.value = await Get.arguments['establishmentID'];
    getRatingsAndFeedback();
    super.onInit();
  }
}
