import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../../config/app_colors.dart';
import '../../../services/money_formatter.dart';
import '../controller/user_reservation_details_controller.dart';
import '../dialog/user_payment_checkout_dialog.dart';
import '../dialog/user_rating_dialog.dart';

class UserReservationDetailsPage extends GetView<UserReservationDetailsController> {
  const UserReservationDetailsPage({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(UserReservationDetailsController());
    return Scaffold(
      body: Obx(
        () => controller.isLoading.value == true
            ? SizedBox(
                height: 100.h,
                width: 100.w,
                child: Center(
                  child: SpinKitThreeBounce(
                    color: AppColors.darkBlue,
                    size: 35.sp,
                  ),
                ),
              )
            : SizedBox(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        children: [
                          CachedNetworkImage(
                            imageUrl: controller.reservationDetails.establishmentImage,
                            imageBuilder: (context, imageProvider) => Container(
                              height: 35.h,
                              width: 100.w,
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.cover,
                                  image: imageProvider,
                                ),
                              ),
                            ),
                            placeholder: (context, url) => Container(
                              height: 35.h,
                              width: 100.w,
                              decoration: const BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.cover,
                                  image: AssetImage("assets/images/launcher.png"),
                                ),
                              ),
                            ),
                            errorWidget: (context, url, error) => Container(
                              height: 35.h,
                              width: 100.w,
                              decoration: const BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.cover,
                                  image: AssetImage("assets/images/launcher.png"),
                                ),
                              ),
                            ),
                          ),
                          Positioned(
                            top: 5.h,
                            right: 6.w,
                            child: Row(
                              children: [
                                GestureDetector(
                                  onTap: () {
                                    controller.addToFavorites(establishmentsDetails: controller.reservationDetails);
                                  },
                                  child: const CircleAvatar(
                                    backgroundColor: AppColors.darkBlue,
                                    child: Icon(
                                      Icons.favorite,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                                Obx(
                                  () => controller.status.value == "Done"
                                      ? Row(
                                          children: [
                                            SizedBox(
                                              width: 2.w,
                                            ),
                                            GestureDetector(
                                              onTap: () {
                                                RatingDialog.showRateUser();
                                              },
                                              child: const CircleAvatar(
                                                backgroundColor: AppColors.darkBlue,
                                                child: Icon(
                                                  Icons.star,
                                                  color: Colors.yellow,
                                                ),
                                              ),
                                            ),
                                          ],
                                        )
                                      : const SizedBox(),
                                ),
                              ],
                            ),
                          ),
                          Positioned(
                            top: 5.h,
                            left: 6.w,
                            child: GestureDetector(
                              onTap: () {
                                Get.back();
                              },
                              child: const CircleAvatar(
                                backgroundColor: AppColors.darkBlue,
                                child: Icon(
                                  Icons.arrow_back,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 5.w, right: 5.w),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: 3.3.h,
                              backgroundColor: AppColors.lightBlue,
                              child: CircleAvatar(
                                radius: 3.h,
                                child: GestureDetector(
                                  child: CircleAvatar(
                                    backgroundImage: NetworkImage(controller.reservationDetails.userImage),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 2.w,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SizedBox(
                                  width: 70.w,
                                  child: Text(
                                    controller.reservationDetails.userName,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: Theme.of(Get.context!).textTheme.labelMedium!.copyWith(fontSize: 12.sp),
                                  ),
                                ),
                                SizedBox(
                                  width: 70.w,
                                  child: Text(
                                    controller.reservationDetails.userId,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: Theme.of(Get.context!).textTheme.labelSmall!.copyWith(color: AppColors.lightBlue, fontSize: 10.sp),
                                  ),
                                ),
                                SizedBox(
                                  width: 70.w,
                                  child: Text(
                                    controller.reservationDetails.contactno,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: Theme.of(Get.context!).textTheme.labelSmall!.copyWith(color: AppColors.lightBlue, fontSize: 10.sp),
                                  ),
                                )
                              ],
                            )
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 5.w, right: 5.w),
                        child: Text(
                          controller.reservationDetails.establishmentName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Theme.of(context).textTheme.labelLarge,
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 5.w, right: 5.w),
                        child: Row(
                          children: [
                            Text(
                              "${AppLocalizations.of(Get.context!)!.price}: ${MoneyFormatter.formatMoney(amount: controller.reservationDetails.reservationPrice)}",
                              style: Theme.of(context).textTheme.labelSmall!.copyWith(fontSize: 12.sp),
                            ),
                            Text(
                              " (${controller.reservationDetails.establishmentCategory})",
                              style: Theme.of(context).textTheme.labelSmall!.copyWith(color: AppColors.darkBlue, fontSize: 12.sp),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 5.w, right: 5.w),
                        child: Row(
                          children: [
                            Text(
                              "${AppLocalizations.of(Get.context!)!.payment}: ${MoneyFormatter.formatMoney(amount: controller.reservationDetails.reservationDownpayment)}",
                              style: Theme.of(context).textTheme.labelSmall!.copyWith(fontSize: 12.sp),
                            ),
                            Obx(
                              () => Text(
                                controller.paymentStatus.value == "Down Payment"
                                    ? " (${AppLocalizations.of(context)!.downpayment})"
                                    : " (${AppLocalizations.of(context)!.fullypaid})",
                                style: Theme.of(context)
                                    .textTheme
                                    .labelSmall!
                                    .copyWith(color: controller.paymentStatus.value == "Down Payment" ? Colors.orange : Colors.green, fontSize: 12.sp),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 5.w, right: 5.w),
                        child: Obx(
                          () => Text(
                            controller.status.value == "Pending"
                                ? AppLocalizations.of(context)!.pending
                                : controller.status.value == "Accepted"
                                    ? AppLocalizations.of(context)!.accepted
                                    : controller.status.value == "Rejected"
                                        ? AppLocalizations.of(context)!.reject
                                        : controller.status.value == "Cancelled"
                                            ? AppLocalizations.of(context)!.cancelled
                                            : AppLocalizations.of(context)!.done,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.labelSmall!.copyWith(
                                  color: controller.status.value == "Pending"
                                      ? Colors.orange
                                      : controller.status.value == "Accepted"
                                          ? Colors.green
                                          : controller.status.value == "Rejected" || controller.status.value == "Cancelled"
                                              ? Colors.red
                                              : AppColors.darkBlue,
                                ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 2.h,
                      ),
                      Padding(
                        padding: EdgeInsets.only(left: 5.w, right: 5.w),
                        child: Text(
                          controller.reservationDetails.remarks,
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
      ),
      bottomNavigationBar: Obx(
        () => controller.isLoading.value || controller.status.value == "Rejected" || controller.status.value == "Cancelled" || controller.status.value == "Done"
            ? const SizedBox()
            : controller.status.value == "Pending"
                ? Padding(
                    padding: EdgeInsets.only(left: 5.w, right: 5.w, bottom: 3.h),
                    child: SizedBox(
                      height: 6.5.h,
                      width: 100.w,
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(5))), backgroundColor: AppColors.red),
                          onPressed: () {
                            // CheckoutPaymentConfirmationDialog.showCheckoutPaymentConfirmation(controller: controller);
                            controller.cancelReservation();
                          },
                          child: Text(
                            AppLocalizations.of(Get.context!)!.cancel,
                            style: Theme.of(Get.context!).textTheme.labelSmall!.copyWith(color: Colors.white),
                          )),
                    ),
                  )
                : Padding(
                    padding: EdgeInsets.only(left: 5.w, right: 5.w, bottom: 3.h),
                    child: SizedBox(
                      height: 6.5.h,
                      width: 100.w,
                      child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(5))), backgroundColor: AppColors.darkBlue),
                          onPressed: () {
                            CheckoutPaymentConfirmationDialog.showCheckoutPaymentConfirmation(controller: controller);
                          },
                          child: Text(
                            AppLocalizations.of(Get.context!)!.checkout,
                            style: Theme.of(Get.context!).textTheme.labelSmall!.copyWith(color: Colors.white),
                          )),
                    ),
                  ),
      ),
    );
  }
}
