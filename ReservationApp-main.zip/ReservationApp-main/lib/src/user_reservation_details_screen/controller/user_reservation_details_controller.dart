import 'dart:convert';
import 'dart:developer';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/model/reservation_model.dart';
import 'package:hotelreservation/services/message_dialog.dart';
import 'package:hotelreservation/services/notification_services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../services/getstorage_services.dart';
import '../../../services/loading_services.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:http/http.dart' as http;

class UserReservationDetailsController extends GetxController {
  RxBool isLoading = true.obs;
  late Reservation reservationDetails;
  RxString status = ''.obs;
  RxString paymentStatus = ''.obs;

  String userName = "${Get.find<StorageServices>().storage.read('firstname')} ${Get.find<StorageServices>().storage.read('lastname')}";
  String userID = Get.find<StorageServices>().storage.read('email').toString();

  RxString clientSecret = ''.obs;
  Map<String, dynamic>? paymentIntentData;

  checkoutReservation() async {
    try {
      await FirebaseFirestore.instance.collection('reservation').doc(reservationDetails.reservationId).update({
        "status": "Done",
        "paymentStatus": "Fully Paid",
      });
      var establishmentDetails = await FirebaseFirestore.instance.collection('establishments').doc(reservationDetails.establishmentId).get();
      if (establishmentDetails.exists) {
        int slot = establishmentDetails.get('slot');
        await FirebaseFirestore.instance.collection('establishments').doc(establishmentDetails.id).update({
          "slot": slot + 1,
        });
      }
      Get.back();
      status.value = "Done";
      paymentStatus.value = "Fully Paid";
      MessageDialog.showMessageDialog(
        message: "${AppLocalizations.of(Get.context!)!.checkout} ${AppLocalizations.of(Get.context!)!.success}",
      );
      sendNotif(message: "${reservationDetails.userName} ${AppLocalizations.of(Get.context!)!.isgoingtocheckout}");
    } catch (e) {
      log("ERROR (checkoutReservation) $e");
    }
  }

  sendNotif({required String message}) async {
    var adminDetails = await FirebaseFirestore.instance.collection('admin').where('active', isEqualTo: true).get();
    if (adminDetails.docs.isNotEmpty) {
      String fcmToken = adminDetails.docs[0]['fcmToken'];
      Get.find<NotificationServices>().sendNotification(userToken: fcmToken, message: message, title: "Reservation Notif");
    }
  }

  callUser() async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: "+63${reservationDetails.contactno}",
    );
    await launchUrl(launchUri);
  }

  emailUser() async {
    final Uri launchUri = Uri(
      scheme: 'mailto',
      path: reservationDetails.userId,
    );
    await launchUrl(launchUri);
  }

  addToFavorites({required Reservation establishmentsDetails}) async {
    try {
      LoadingDialog.showLoadingDialog();
      var res = await FirebaseFirestore.instance.collection('favorites').where('userID', isEqualTo: userID).where('establishmentID', isEqualTo: establishmentsDetails.id).get();
      if (res.docs.isEmpty) {
        await FirebaseFirestore.instance.collection('favorites').add({
          'establishmentID': establishmentsDetails.id,
          "datecreated": DateTime.now(),
          "descriptionEnglish": establishmentsDetails.establishmentDescriptionEnglish,
          "descriptionFrench": establishmentsDetails.establishmentDescriptionFrench,
          "descriptionSpanish": establishmentsDetails.establishmentDescriptionSpanish,
          "price": establishmentsDetails.establishmentPrice,
          "category": establishmentsDetails.establishmentCategory,
          "pax": establishmentsDetails.establishmentPax,
          "slot": establishmentsDetails.establishmentSlot,
          "name": establishmentsDetails.establishmentName,
          "image": establishmentsDetails.establishmentImage,
          'userID': userID
        });
        Get.back();
        MessageDialog.showMessageDialog(
          message: AppLocalizations.of(Get.context!)!.addedtofavorites,
        );
      } else {
        Get.back();
        MessageDialog.showMessageDialog(
          message: AppLocalizations.of(Get.context!)!.alreadyexist,
        );
      }
    } catch (e) {
      Get.back();
      log("ERROR (addToFavorites) $e");
    }
  }

  rateEstablishment({required double rating, required String message}) async {
    try {
      Get.back();
      LoadingDialog.showLoadingDialog();
      var res = await FirebaseFirestore.instance
          .collection('establishments')
          .doc(reservationDetails.establishmentId)
          .collection('ratings')
          .where(
            'userid',
            isEqualTo: userID,
          )
          .get();
      if (res.docs.isNotEmpty) {
        await FirebaseFirestore.instance.collection('establishments').doc(reservationDetails.establishmentId).collection('ratings').doc(res.docs[0].id).update({
          "rating": rating,
          "feedback": message,
        });
      } else {
        await FirebaseFirestore.instance.collection('establishments').doc(reservationDetails.establishmentId).collection('ratings').add({
          "rating": rating,
          'userid': userID,
          "feedback": message,
          "firstname": Get.find<StorageServices>().storage.read('firstname'),
          "lastname": Get.find<StorageServices>().storage.read('lastname'),
          "profilePicture": Get.find<StorageServices>().storage.read('profilePicture'),
          "datecreated": DateTime.now()
        });
      }
      await FirebaseFirestore.instance.collection('establishments').doc(reservationDetails.establishmentId).update({"dateupdated": DateTime.now().toString()});
      Get.back();
      MessageDialog.showMessageDialog(message: "Thank you for providing rating.");
    } catch (e) {
      Get.back();
      log("ERROR (rateEstablishment) $e");
    }
  }

  Future<void> makePayment({required String amount, required String currency}) async {
    try {
      paymentIntentData = await createPaymentIntent(amount, currency);
      clientSecret.value = paymentIntentData!['client_secret'].toString();
      log("CLIENT SECRET ${clientSecret.value}");
      if (paymentIntentData != null) {
        log(amount);
        log(currency);
        await Stripe.instance.initPaymentSheet(
            paymentSheetParameters: SetupPaymentSheetParameters(
          billingDetails: const BillingDetails(
            address: Address(
              city: "",
              line1: "",
              line2: "",
              postalCode: "",
              state: "PH",
              country: 'PH', // Set default country (ISO country code)
            ),
          ),
          // applePay: PaymentSheetApplePay(merchantCountryCode: currency),
          googlePay: const PaymentSheetGooglePay(merchantCountryCode: "PHP"),
          customerId: "${Get.find<StorageServices>().storage.read('email')}-${DateTime.now().millisecondsSinceEpoch.toString()}",
          merchantDisplayName: 'Prospects',
          // customerId: Get.find<StorageServices>().storage.read('id'),
          // sk_test_51Lize7DbhTM8s4NtDpmRR7iPcppW41EG2AYCHLmJjopgdCnUUP85FQVvmEt98rCnpnr59xQd6zOP7D4kfkMDXqKM00ejfzOuph
          paymentIntentClientSecret: paymentIntentData!['client_secret'],
          customerEphemeralKeySecret: paymentIntentData!['ephemeralKey'],
        ));
        displayPaymentSheet();
      }
    } catch (e, s) {
      log('exception:$e$s');
    }
  }

  displayPaymentSheet() async {
    try {
      LoadingDialog.showLoadingDialog();
      await Stripe.instance.presentPaymentSheet();
      checkoutReservation();
    } on Exception catch (e) {
      if (e is StripeException) {
        Get.back();
        Get.back();
        log("Error from Stripe: ${e.error.localizedMessage}");
      } else {
        Get.back();
        Get.back();
        log("Unforeseen error: $e");
      }
    } catch (e) {
      Get.back();
      Get.back();
      log("exception:$e");
    }
  }

  createPaymentIntent(String amount, String currency) async {
    var amountString = double.parse(amount).toInt();
    try {
      Map<String, dynamic> body = {'amount': calculateAmount(amountString.toString()), 'currency': currency, 'payment_method_types[]': 'card'};
      var response = await http.post(Uri.parse('https://api.stripe.com/v1/payment_intents'), body: body, headers: {
        'Authorization': 'Bearer sk_test_51QOvqZFNGDv7UO58k875n1eR9WpJaT3t8W0OZo8uS7fM25h0xcUhu3EJfysVzjd5uOvcu4K3Zi5veBCfShxV628F00jhzuhMZH',
        'Content-Type': 'application/x-www-form-urlencoded'
      });
      // log(jsonDecode(response.body)['clientSecret']);
      return jsonDecode(response.body);
    } catch (err) {
      log('err charging user: ${err.toString()}');
    }
  }

  calculateAmount(String amount) {
    final a = (int.parse(amount)) * 100;
    return a.toString();
  }

  iniData() async {
    LoadingDialog.showLoadingDialog();
    Future.delayed(const Duration(seconds: 1), () {
      isLoading.value = false;
      Get.back();
    });
  }

  cancelReservation() async {
    try {
      LoadingDialog.showLoadingDialog();
      await FirebaseFirestore.instance.collection('reservation').doc(reservationDetails.reservationId).update({
        "status": "Cancelled",
      });
      Get.back();
      status.value = "Cancelled";
      MessageDialog.showMessageDialog(message: AppLocalizations.of(Get.context!)!.cancelled);
    } catch (e) {
      log("ERROR (cancelReservation) $e");
    }
  }

  @override
  void onReady() async {
    isLoading.value = true;
    reservationDetails = await Get.arguments['reservationDetails'];
    status.value = reservationDetails.status;
    paymentStatus.value = reservationDetails.paymentStatus;
    iniData();
    super.onReady();
  }
}
