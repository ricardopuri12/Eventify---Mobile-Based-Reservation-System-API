import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import '../../../config/app_colors.dart';
import '../../../config/app_fontsizes.dart';
import '../controller/user_reservation_details_controller.dart';

class CheckoutPaymentConfirmationDialog {
  static showCheckoutPaymentConfirmation({required UserReservationDetailsController controller}) {
    var controller = Get.find<UserReservationDetailsController>();
    Get.dialog(AlertDialog(
      content: SizedBox(
        width: 40.h,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                AppLocalizations.of(Get.context!)!.message,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: AppFontSizes.large,
                ),
              ),
              SizedBox(height: 1.h),
              Text(
                "${AppLocalizations.of(Get.context!)!.areyousureyouwanttocheckoutinthe} ${controller.reservationDetails.establishmentName}? ${AppLocalizations.of(Get.context!)!.youwillpaytheremainingbalance}",
                style: TextStyle(
                  fontWeight: FontWeight.normal,
                  fontSize: AppFontSizes.small,
                ),
              ),
              SizedBox(
                height: 2.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  SizedBox(
                    width: 30.w,
                    height: 6.h,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: AppColors.black, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(8)))),
                      onPressed: () {
                        Get.back();
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.arrow_back,
                            color: Colors.white,
                          ),
                          SizedBox(
                            width: 1.w,
                          ),
                          Text(
                            AppLocalizations.of(Get.context!)!.back,
                            style: TextStyle(fontWeight: FontWeight.normal, fontSize: AppFontSizes.small, color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    width: 30.w,
                    height: 6.h,
                    child: ElevatedButton(
                      style:
                          ElevatedButton.styleFrom(backgroundColor: AppColors.lightBlue, shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(8)))),
                      onPressed: () async {
                        Get.back();
                        String amountString = (controller.reservationDetails.reservationPrice - controller.reservationDetails.reservationDownpayment).toStringAsFixed(2);
                        controller.makePayment(amount: amountString.toString(), currency: "PHP");
                      },
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.payment,
                            color: Colors.white,
                          ),
                          SizedBox(
                            width: 1.w,
                          ),
                          Text(
                            AppLocalizations.of(Get.context!)!.confirm,
                            style: TextStyle(fontWeight: FontWeight.normal, fontSize: AppFontSizes.small, color: Colors.white),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      ),
    ));
  }
}
