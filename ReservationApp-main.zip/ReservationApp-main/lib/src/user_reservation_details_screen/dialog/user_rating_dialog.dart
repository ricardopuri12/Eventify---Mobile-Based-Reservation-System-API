import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';

import '../../../config/app_colors.dart';
import '../../../config/app_fontsizes.dart';
import '../controller/user_reservation_details_controller.dart';

class RatingDialog {
  static showRateUser() {
    var controller = Get.find<UserReservationDetailsController>();
    TextEditingController feedback = TextEditingController();
    double selectedRating = 3.0;
    Get.dialog(AlertDialog(
      backgroundColor: Colors.white,
      content: SizedBox(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 1.h,
            ),
            Text(
              "Ratings",
              style: TextStyle(fontSize: AppFontSizes.large, fontWeight: FontWeight.bold),
            ),
            SizedBox(
              height: 2.h,
            ),
            RatingBar.builder(
              initialRating: 3,
              minRating: 1,
              direction: Axis.horizontal,
              allowHalfRating: true,
              itemCount: 5,
              itemPadding: const EdgeInsets.symmetric(horizontal: 3.0),
              itemBuilder: (context, _) => const Icon(
                Icons.star,
                color: Colors.amber,
              ),
              onRatingUpdate: (rating) {
                selectedRating = rating;
              },
            ),
            SizedBox(
              height: 2.h,
            ),
            Container(
              padding: EdgeInsets.only(
                left: 5.w,
                right: 5.w,
              ),
              height: 20.h,
              width: 100.w,
              child: Center(
                child: TextField(
                  controller: feedback,
                  expands: true,
                  maxLines: null,
                  minLines: null,
                  style: TextStyle(fontSize: AppFontSizes.regular),
                  textAlign: TextAlign.left,
                  textAlignVertical: TextAlignVertical.top,
                  decoration: InputDecoration(
                    filled: true,
                    contentPadding: EdgeInsets.only(left: 3.w, top: 1.h),
                    alignLabelWithHint: false,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                    hintStyle: Theme.of(Get.context!).textTheme.bodySmall,
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 2.h,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                    width: 25.w,
                    child: ElevatedButton(
                        style: const ButtonStyle(foregroundColor: MaterialStatePropertyAll(AppColors.darkBlue), backgroundColor: MaterialStatePropertyAll(AppColors.light)),
                        onPressed: () {
                          Get.back();
                        },
                        child: Text(
                          "Cancel",
                          style: Theme.of(Get.context!).textTheme.labelSmall,
                        ))),
                SizedBox(
                    width: 25.w,
                    child: ElevatedButton(
                        onPressed: () {
                          if (feedback.text.isNotEmpty) {
                            controller.rateEstablishment(rating: selectedRating, message: feedback.text);
                          }
                        },
                        child: Text(
                          "Submit",
                          style: Theme.of(Get.context!).textTheme.labelSmall,
                        ))),
              ],
            ),
            SizedBox(
              height: 2.h,
            ),
          ],
        ),
      ),
    ));
  }
}
