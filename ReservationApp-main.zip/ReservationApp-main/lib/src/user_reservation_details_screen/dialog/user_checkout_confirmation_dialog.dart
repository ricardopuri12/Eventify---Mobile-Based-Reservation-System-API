import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import '../../../config/app_colors.dart';
import '../controller/user_reservation_details_controller.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

class UserCheckoutConfirmationDialog {
  static showCheckoutDialog({required UserReservationDetailsController controller}) async {
    Get.dialog(
      AlertDialog(
        title: Text(
          AppLocalizations.of(Get.context!)!.checkout,
          style: Theme.of(Get.context!).textTheme.labelMedium,
        ),
        content: Padding(
          padding: const EdgeInsets.all(5.0),
          child: SizedBox(
              child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "${AppLocalizations.of(Get.context!)!.areyousureyouwanttocheckoutinthe} ${controller.reservationDetails.establishmentName}?",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12.sp, color: Colors.black),
              ),
              SizedBox(
                height: 2.h,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  SizedBox(
                    height: 6.5.h,
                    width: 25.w,
                    child: ElevatedButton(
                        style:
                            ElevatedButton.styleFrom(shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(5))), backgroundColor: AppColors.darkBlue),
                        onPressed: () {
                          Get.back();
                        },
                        child: Text(
                          AppLocalizations.of(Get.context!)!.cancel,
                          style: Theme.of(Get.context!).textTheme.labelSmall!.copyWith(color: Colors.white),
                        )),
                  ),
                  SizedBox(
                    height: 6.5.h,
                    width: 25.w,
                    child: ElevatedButton(
                        style: ElevatedButton.styleFrom(shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(5))), backgroundColor: Colors.green),
                        onPressed: () {
                          controller.checkoutReservation();
                        },
                        child: Text(
                          AppLocalizations.of(Get.context!)!.confirm,
                          style: Theme.of(Get.context!).textTheme.labelSmall!.copyWith(color: Colors.white),
                        )),
                  ),
                ],
              )
            ],
          )),
        ),
      ),
    );
  }
}
