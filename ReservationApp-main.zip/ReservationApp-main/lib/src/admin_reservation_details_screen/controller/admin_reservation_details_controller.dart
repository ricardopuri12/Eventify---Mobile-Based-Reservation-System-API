import 'dart:developer';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import 'package:hotelreservation/model/reservation_model.dart';
import 'package:hotelreservation/services/message_dialog.dart';
import 'package:hotelreservation/services/notification_services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import '../../../services/loading_services.dart';

class AdminReservationDetailsController extends GetxController {
  RxBool isLoading = true.obs;
  late Reservation reservationDetails;
  RxString status = ''.obs;
  RxString paymentStatus = ''.obs;

  acceptReservation() async {
    try {
      LoadingDialog.showLoadingDialog();
      await FirebaseFirestore.instance.collection('reservation').doc(reservationDetails.reservationId).update({
        "status": "Accepted",
      });
      var establishmentDetails = await FirebaseFirestore.instance.collection('establishments').doc(reservationDetails.establishmentId).get();
      if (establishmentDetails.exists) {
        int slot = establishmentDetails.get('slot');
        await FirebaseFirestore.instance.collection('establishments').doc(establishmentDetails.id).update({
          "slot": slot - 1,
        });
      }
      Get.back();
      Get.back();
      status.value = "Accepted";
      MessageDialog.showMessageDialog(message: AppLocalizations.of(Get.context!)!.reservationaccepted);
      sendNotif(message: "${AppLocalizations.of(Get.context!)!.yourreservationat} ${reservationDetails.establishmentName} ${AppLocalizations.of(Get.context!)!.hasbeenaccepted}");
    } catch (e) {
      log("ERROR (acceptReservation) $e");
    }
  }

  rejectReservation() async {
    try {
      LoadingDialog.showLoadingDialog();
      await FirebaseFirestore.instance.collection('reservation').doc(reservationDetails.reservationId).update({
        "status": "Rejected",
      });
      Get.back();
      Get.back();
      status.value = "Rejected";
      MessageDialog.showMessageDialog(message: AppLocalizations.of(Get.context!)!.reservationrejected);
      sendNotif(message: "${AppLocalizations.of(Get.context!)!.yourreservationat} ${reservationDetails.establishmentName} ${AppLocalizations.of(Get.context!)!.hasbeenrejected}");
    } catch (e) {
      log("ERROR (acceptReservation) $e");
    }
  }

  sendNotif({required String message}) async {
    var userDetails = await FirebaseFirestore.instance.collection('users').doc(reservationDetails.userId).get();
    if (userDetails.exists) {
      String fcmToken = userDetails.get('fcmToken');
      Get.find<NotificationServices>().sendNotification(userToken: fcmToken, message: message, title: "Reservation Notif");
    }
  }

  callUser() async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: "+63${reservationDetails.contactno}",
    );
    await launchUrl(launchUri);
  }

  emailUser() async {
    final Uri launchUri = Uri(
      scheme: 'mailto',
      path: reservationDetails.userId,
    );
    await launchUrl(launchUri);
  }

  iniData() async {
    LoadingDialog.showLoadingDialog();
    Future.delayed(const Duration(seconds: 1), () {
      isLoading.value = false;
      Get.back();
    });
  }

  @override
  void onReady() async {
    isLoading.value = true;
    reservationDetails = await Get.arguments['reservationDetails'];
    status.value = reservationDetails.status;
    paymentStatus.value = reservationDetails.paymentStatus;

    iniData();
    super.onReady();
  }
}
