import 'dart:developer';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sizer/sizer.dart';
import 'config/app_colors.dart';
import 'services/getstorage_services.dart';
import 'services/notification_services.dart';
import 'src/splash_screen/view/splash_page.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:hotelreservation/l10n/l10n.dart';
import 'package:flutter_stripe/flutter_stripe.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
      options: const FirebaseOptions(
          apiKey: 'AIzaSyBdx3JR3rLP6jlKlI7XzPC_FQXvHpGHCMU',
          appId: '1:1085848859236:android:cfff897e6fdab6889b6571',
          messagingSenderId: '1085848859236',
          // storageBucket: "accounthing-c6198.appspot.com",
          storageBucket: "hotelreservation-8f21f.firebasestorage.app",
          projectId: 'hotelreservation-8f21f'));
  Stripe.publishableKey = 'pk_test_51QOvqZFNGDv7UO587BmFxGWXa2ah9JU7jTLTMHYAjLuZiNw4IqEU7YhqwurENqHgiedW8PfVW4BxUmIXttJ90AHX00Fd0PpyzK';
  await Stripe.instance.applySettings();
  await Supabase.initialize(
    url: 'https://xtlhegoxjkfrdniswans.supabase.co',
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh0bGhlZ294amtmcmRuaXN3YW5zIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzA4NzYzNzQsImV4cCI6MjA0NjQ1MjM3NH0.oZK5_9ljDixWtESfNtwUfgXiQaWsNufFgs9jnw7PH1o',
  );
  await Get.putAsync<StorageServices>(() async => StorageServices());
  await Get.putAsync<NotificationServices>(() async => NotificationServices());

  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) async {
    super.didChangeAppLifecycleState(state);
    if (state == AppLifecycleState.detached) {
      log("detached");
    } else if (state == AppLifecycleState.paused) {
      log("paused");
    } else if (state == AppLifecycleState.resumed) {
      log("resumed");
    } else if (state == AppLifecycleState.inactive) {
      log("inactive");
    }
  }

  @override
  void dispose() {
    super.dispose();
    WidgetsBinding.instance.removeObserver(this);
  }

  @override
  Widget build(BuildContext context) {
    return Sizer(builder: (context, orientation, deviceType) {
      return GetMaterialApp(
        supportedLocales: L10n.all,
        locale: const Locale('en'),
        localizationsDelegates: const [
          AppLocalizations.delegate,
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        debugShowCheckedModeBanner: false,
        title: 'Eventify',
        theme: ThemeData(
          iconTheme: const IconThemeData(color: Colors.black),
          bottomAppBarTheme: const BottomAppBarTheme(
            color: Colors.white,
          ),
          appBarTheme: AppBarTheme(
            backgroundColor: Colors.white,
            elevation: 0,
            iconTheme: const IconThemeData(color: Colors.black),
            actionsIconTheme: const IconThemeData(color: Colors.black),
            titleTextStyle: TextStyle(color: Colors.black, fontSize: 15.sp),
          ),
          inputDecorationTheme: const InputDecorationTheme(
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: AppColors.lightBlue, width: 2.0), // Active border color
              ),
              fillColor: Colors.white),
          textTheme: TextTheme(
            headlineLarge: TextStyle(color: Colors.black, fontSize: 28.sp, fontWeight: FontWeight.bold),
            headlineMedium: TextStyle(color: Colors.black, fontSize: 24.sp, fontWeight: FontWeight.bold),
            bodyLarge: TextStyle(color: Colors.black, fontSize: 18.sp),
            bodyMedium: TextStyle(color: Colors.black, fontSize: 13.sp),
            bodySmall: TextStyle(color: Colors.black, fontSize: 11.sp),
            labelLarge: TextStyle(color: Colors.black, fontSize: 18.sp, fontWeight: FontWeight.bold),
            labelMedium: TextStyle(color: Colors.black, fontSize: 13.sp, fontWeight: FontWeight.bold),
            labelSmall: TextStyle(color: Colors.black, fontSize: 11.sp, fontWeight: FontWeight.bold),
          ),
          scaffoldBackgroundColor: Colors.white,
          fontFamily: "PoppinsRegular",
          primarySwatch: MaterialColor(0xFF3071FF, AppColors.mainMaterialColor),
        ),
        home: const SplashPage(),
      );
    });
  }
}
